# PacketPulse 2.0 — Product Guide: Vision, Requirements, Decisions & Project Context

**Consolidated release:** v7.0 · 27 November 2026  
**Source baseline:** Owner-supplied project documentation set dated 24 November 2026, reconciled against later 25–26 November source packages, Notion exports/records and Git main snapshot through 27 November 2026.  
**Document status:** Product/design specification and project handoff. Not evidence of production implementation, legal approval or repository validation.  
**Source precedence:** Current owner-approved decisions and dated Notion decision/change records supersede earlier proposal or historical token values. Dated releases remain immutable; see the source/lineage section at the end.  
**Working agreement:** Product behavior, user flows, edge cases, acceptance criteria and quality standards are defined here. Claude audits and implements in the actual application repository. Do not invent repository paths, replace working services, or claim tests/deployment without evidence.

**Current owner direction (27 Nov):** User-context-first design, ethical psychology, accessible and truthful UX. The approved visual foundation is Violet-led Palette 1 (`#615AB9`, `#16133E`, `#8B7FF7`, `#F1F5F9`) complemented by Forest `#156152`, Signal Lime `#C7FE53`, Soft Forest `#8BBBA5`, and balanced black/white neutrals. Detailed operational tokens, shade/state refinement within this foundation, scoped Payments blue and reusable logo completion are delegated to Claude; the foundation and product-policy boundary are fixed unless the owner changes them.

**Reading note:** The complete 26 Nov canonical source text is retained below for traceability and detail. The 24 Nov source set is the historical baseline you identified; later dated records supersede it only where explicitly approved. Its dated palette/token proposals and other historical states are not silently promoted; use this 27 Nov authority block and the explicit current-decision addenda for present-day decisions.

Version 5.5 · 26 November 2026 · Owner: product lead (to be named) · Supersedes the 17 October 2026 Product Guide v4.0 and consolidates the relevant product, decision and risk registers from the earlier document suite · Part of the current five-document set: 1 Product Guide, 2 Design System and UX Guide, 3 Users, Screens and Page Flows, 4 Delivery Plan and Developer Handoff, 5 Component Ecosystem, UI Patterns and Library Registry.

## 0. How to read this document

| Mark | Meaning |
| --- | --- |
| Confirmed | The owner agreed this, whether built or not |
| Planned | Approved and scheduled |
| Proposed | A suggestion not yet accepted into a build |
| Approved Prototype | Owner-approved for inclusion in the next prototype/review build; not production approval |
| Production Approved | Explicitly approved for real users, live data and production operations after release gates pass |
| Open / Discovery | A factual, repository, vendor, legal or operational item that still needs evidence; it does not block a safe prototype unless marked as a release gate |
| PV | Built and tested in the reference prototype only (a single-file demo), not in production |
| **[APPROVED PROTOTYPE]** | Owner approved for the next review build; feedback can lead to retain, refine, restrict or remove in a subsequent build |
| **Experiment candidate** | Included for controlled evaluation behind a feature flag; continuation is decided after a defined team review window |

IDs used across the set: PRD (requirement), DES (design rule), WF (workflow), SCR (screen), DB (data), API (service capability), TASK, TEST, DEC (decision), CON (contradiction), OPEN (open question), RISK. All five documents use the same IDs, so a requirement can be traced from here to its screen (Document 3), its design rules (Document 2) and its tasks and tests (Document 4).

The production codebase was not available when this set was written. Nothing here says a feature exists in production; the repository audit in Document 4 settles that.

## 1. What changed in this revision

| Change | Detail |
| --- | --- |
| Existing stack is fixed | Next.js for frontend and backend, a backend service that already exists, PostgreSQL (Supabase), Redis, hosted on Vercel and Render. No technology is replaced now (DEC-021 to DEC-023, DEC-032). A developer and an AI coding agent will handle code and versions in another workspace, so this set no longer carries code-level detail |
| Five canonical documents, with a dedicated component ecosystem guide | Product Guide (old A and F), Design System and UX Guide (old B), Users, Screens and Page Flows (old C), Delivery Plan and Developer Handoff (old D and E). Nothing valid was dropped; technical detail was reduced to what a developer needs to build the planned features |
| Questions now have answers | All previously open-for-approval product/design recommendations are approved for the next review build under DEC-048; true discovery and production gates remain explicit (section 10) |
| Focus on design, features and flows | More space for who the users are, what each screen does, how pages connect, and what the user sees when things go wrong |
| New proposals | Five earlier proposals remain; this revision adds community knowledge-network capabilities, dashboard layout families, design-system governance and controlled automated-verification experiments |
| Design evolution | Signal Grove now defines two layout families: Editorial Workspace and Analytical Workspace; Matte Black Edition is the preferred reference for analytics-heavy dashboards |
| Community strategy | Community expands from Q&A into structured technical knowledge, discovery, groups, events, mentoring and contribution identity, linked to learning and verification |
| Experiment policy | Automated skill verification remains eligible for controlled experiments; hiring and financial decisions remain separately governed |
| Media and recording experience | A reusable playback and file-preview layer is added for hosted recordings, HLS/DASH streams, provider embeds, PDFs and supported documents; Video.js 10.7.0 is the preferred React player candidate for the review build |
| Nested experience model | Parent/child pages, route-backed detail views, contextual drawers and nested settings/resources workflows receive a common navigation and state-preservation model |
| Brand pattern language | Original packet, route, node, wave, pulse, radar, security-layer and data-flow motifs are added as transparent reusable overlays; current backgrounds remain untouched |
| Creative latitude | Design principles are flexible starting points. Teams may explore colour combinations, pattern treatments, Pantone references, type, layout and motion; accessibility and meaning remain quality checks, not a narrow aesthetic ceiling |

## 2. Product identity

### 2.1 Mission, vision and tagline

PacketPulse is an engineering community and career platform. It connects learning, hands-on practice, verified skills, professional identity and opportunity in one product (DEC-001, DEC-002).

- **Mission:** help network, security and cloud engineers learn, prove what they can do, and be trusted for it.
- **Vision:** the place where an engineer's capability is visible, believable and connected to work, with a community that keeps people growing after they are hired.
- **Tagline, Connect, Learn & Grow Together:** Connect is the community and the bridge to employers; Learn and Practice are courses and labs; Grow is continued contribution, mentoring and new skills. Prove and Verify sit between them and make the connection credible.

### 2.2 Value proposition

| For | Value |
| --- | --- |
| Engineers | A credible, evidence-backed profile built through real practice, instead of a resume nobody can check |
| Recruiters | Pre-screened candidates with visible evidence through a trusted bridge, instead of a pile of resumes |
| The community | A technical Q&A culture that rewards usefulness over volume |
| Operations team | One place to review, moderate and audit, with every decision recorded |

What is different: skills carry visible evidence, practice is troubleshooting and not only multiple choice, and recruitment runs through PacketPulse's human review.

### 2.3 Users

About 2,000 members, 8 admins and 1 SuperAdmin today (reported by the owner, not checked against production data).

| User | Who | Main goals | Main frustrations (hypotheses to test) |
| --- | --- | --- | --- |
| Fresher member | Student or recent graduate in networking or security | Learn, practice, get a first role | Cannot show proof; unsure what to learn next |
| Experienced engineer | Working engineer, 2 or more years | Grow, change roles, be found | Resumes do not show depth; interviews repeat basics |
| Mentor or expert | Senior engineer | Share knowledge, build reputation | No structured way to help |
| Instructor | Trainer or content owner | Publish and review courses and labs | Manual review, scattered content |
| Recruiter or HR | Company hiring manager or agency | Find qualified candidates fast | Too many unfiltered resumes |
| Admin | Operations team member | Moderate, review, support | Manual queues, no audit trail |
| SuperAdmin | Platform owner | Control services, access and policy | No single control plane |

### 2.4 Product principles

1. **Every feature serves the loop:** Learn, Practice, Prove, Verify, Connect, Get hired, Grow (DEC-001). If it does not, it waits.
2. **Evidence over claims.** No verified label without an evidence record (PRD-012).
3. **Automation is a governed capability, not a blanket ban.** Manual, AI-assisted and automated skill-verification modes may be evaluated under PRD-062 and DEC-044. Decisions must be traceable, explainable, policy-versioned, appealable and reversible through controlled operations. Recruitment selection, forwarding, financial actions and sensitive account actions remain human-confirmed unless a separate decision explicitly authorises an experiment.
4. **Trust by design.** Say what is shared, with whom and why, before asking for consent. Technical content must help members avoid exposing secrets or customer data.
5. **One platform.** One account, one skill model, one permission model, shared tokens and reusable components (DEC-002).
6. **Accessible, spacious and emotionally considerate.** Plain language, intentional whitespace, visible next steps, calm feedback and no manipulative engagement patterns.
7. **Knowledge creates professional value.** Reward helpful contribution and reuse, not raw activity volume.

### 2.5 Role of the community

Community is the engineering knowledge network and the reason people return when they are not job hunting. It supports structured technical questions, production incidents, expert discussions, case studies, knowledge articles, events, groups and mentoring. Contributions become reusable knowledge; shared taxonomy connects that knowledge to courses, practice scenarios, assessments and evidence-backed skills. The intended loop is **Knowledge → Contribution → Reputation → Opportunity**. Community reputation remains distinct from verified skills, certifications and employment evidence.

## 3. Goals, non-goals and measures

### 3.1 Goals (targets are starting points to calibrate after a baseline) **[APPROVED PROTOTYPE]**

| Goal | Leading indicator | Lagging indicator | Starting target |
| --- | --- | --- | --- |
| Members reach a useful profile quickly | Email verified to required details complete | Profile-ready within 7 days | 60% |
| Skills become believable | Evidence submitted per active member | Members with at least one verified skill, 90 days after Release 2 | 30% |
| Recruitment is fast and fair | Time to first status update after forwarding | Application to first recruiter decision | 10 working days or less |
| Community answers questions | Questions answered within 48 hours | Accepted-answer rate | 60% answered, 40% accepted |
| Trust holds | Consent records complete | Data shared outside consent | Zero |
| Members come back | 7-day return after first action | 30-day return rate | Baseline first, then set |

Additional community and experience measures to baseline before setting targets:

| Area | Measure | Guardrail |
| --- | --- | --- |
| Helpfulness | Median time to first helpful answer; accepted-answer rate; helpful votes per answered question | Do not reward low-quality volume |
| Discovery | Search success, zero-result searches, related-content opens, saves | Track hides/mutes and recommendation feedback |
| Participation | Unique helpful contributors, returning contributors, contributor concentration | Detect over-reliance on a small expert group |
| Retention | First meaningful action, 7-day and 30-day return, return after solved question | No dark patterns or forced notifications |
| Trust | Report resolution time, repeat abuse, appeals, redaction warnings | Measure false positives and false negatives |
| Automated verification experiment | False approval/rejection, reviewer disagreement, appeal overturn rate, processing time, cost, cohort and confidence-band outcomes | Do not scale solely on speed or pass rate; check bias and subgroup effects |

### 3.2 Non-goals for the first releases

| Not now | Why |
| --- | --- |
| Real lab environments with a runtime | High cost and security risk (RISK-11); labs use written scenarios first |
| Unrestricted AI decisions in hiring, money or sensitive account workflows | Not allowed by default; any exception requires a separate decision, evidence, controls and review. Controlled automated skill-verification experiments are explicitly in scope under PRD-062 |
| Native mobile apps | The web product must work well on phones first |
| Video interviewing and calendar integrations | Start with scheduling details and reminders |
| Third-party course marketplace | Quality and rights are unresolved |
| Candidate-paid fees before joining | Fees only follow a successful joining (DEC-016) |
| Public member profiles on the open web | Privacy first (PRD-052) |

## 4. Strategy and growth

No research, analytics or support data were in the project materials, so each row is a hypothesis to test.

| Stage | Approach | Hypothesis to validate | Measure |
| --- | --- | --- | --- |
| Acquisition | Public site, community content, fees page, referrals through members | Technical content attracts engineers more than job listings | Visitors to registrations by source |
| Registration and onboarding | Email code, progressive profile, resume-assisted entry | Resume parsing cuts profile time | Code completion, time to profile-ready |
| Profile completion | Separate completeness and recruiter readiness | A visible checklist raises completion | Completion at day 7 |
| First meaningful action | Ask or answer a question, start a lab, or enroll | One quick win in 10 minutes predicts retention | Share of new members with a first action |
| Participation | Q&A modes, mentoring, reputation | Accepted answers matter more than volume | Answers per question, acceptance rate |
| Learning | Courses, labs, career paths | Paths beat a flat catalog | Course start and completion |
| Proof | Assessments, evidence review, badges | Verified skills raise recruiter response | Verified-skill rate, recruiter response |
| Careers | Jobs, applications, human review, offers | A reviewed shortlist beats open applications | Apply to interview to offer |
| Retention and reactivation | Notifications by preference; expiring badges as a reason to return | Renewal prompts bring members back | 30-day return rate |
| Referrals | Not yet designed | Satisfied members refer peers | Referral sign-ups (OPEN-17) |
| Trust and moderation | Moderation queue, audit, visible rules | Visible rules reduce abuse | Reports resolved, time to resolve |
| Monetization | Paid advanced courses and live labs; placement fee | Members accept fees shown up front | Conversion, refunds, complaints |

Measurement events: USER\_REGISTERED, EMAIL\_VERIFIED, PROFILE\_COMPLETED, RESUME\_UPLOADED, COURSE\_COMPLETED, LAB\_SUBMITTED, ASSESSMENT\_PASSED, BADGE\_EARNED, JOB\_APPLIED, APPLICATION\_SHORTLISTED, INTERVIEW\_SCHEDULED, OFFER\_RECEIVED, PAYMENT\_COMPLETED. Events carry no personal data such as names, emails or resume text.

## 5. Module inventory

| ID | Module | Purpose | Main users | Depends on | Prototype | Release |
| --- | --- | --- | --- | --- | --- | --- |
| M-01 | Brand site and fees page | Explain the product; publish fees plainly | Visitors | none | PV | 1 |
| M-02 | Identity and onboarding | Register, verify, collect required details, consent | Members | none | PV | 1 |
| M-03 | Profiles | Reusable identity, resumes, completeness, visibility preview | Members, recruiters | M-02, M-04 | PV | 1 |
| M-04 | Skill taxonomy | Standard Major, Minor, Micro skills with automatic suggestions | All | none | PV | 1 |
| M-05 | Community | Q&A, mentoring, reputation, moderation | Members, mentors, admins | M-02 | PV | 1 |
| M-06 | Notifications | In-app, email, WhatsApp opt-in, preferences, delivery log | All | M-02 | PV (in-app only) | 1 |
| M-07 | Learn | Courses, live sessions, career paths, progress, badges | Members, instructors | M-02, M-04 | PV | 2 |
| M-08 | Practice | Labs, submissions, rubric review | Members, instructors, mentors | M-07 | PV (no runtime) | 2 |
| M-09 | Assessments | Attempts, results | Members | M-04 | PV (limited) | 2 |
| M-10 | Verification | Evidence submission, review, appeals, expiry | Members, admins | M-04, M-09 | PV | 2 |
| M-11 | Jobs and recruitment | Positions, applications, screening, forwarding, interviews, offers | Members, recruiters, admins | M-03, M-10 | PV | 3 |
| M-12 | Payments and billing | Paid services, placement fee invoices, refunds | Members, admins | M-07, M-11 | PV (sandbox) | 3 |
| M-13 | Operations | Queues, moderation, feature controls, audit, analytics | Admins, SuperAdmin | all | PV | 1 to 3 |
| M-14 | Security and policies | Roles, permissions, visibility, AI policy, admin security | SuperAdmin | M-13 | PV | 1 |
| M-15 | Integrations and automation | ClickUp, n8n, calendar, AI-assisted drafting | Operations | M-11 | Not built | 4 |

## 6. Requirements and business rules

Each requirement can be tested. Numbers and policies approved as prototypes are defaults for the review build, not final production policy. Production values remain subject to legal, security, operational and owner sign-off.

### 6.1 Identity, onboarding and profiles

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-001 | A new member registers with email and a password or passkey and verifies the email with a 6-digit code. The code expires (10 minutes), allows limited attempts (5) and limited resends; the member can change the email | Confirmed (code), Approved Prototype (limits) |
| PRD-002 | The member chooses Fresher or Experienced; this decides which fields are required | Confirmed |
| PRD-003 | Required for everyone: name, date of birth, years of experience, domain or industry, current or target role, at least one skill, LinkedIn profile, verified email, WhatsApp number. Experienced members also give current company, current CTC and notice period. Applying is blocked until these are complete, and the screen lists what is missing | Confirmed (DEC-018) |
| PRD-004 | Members must be 18 or older; profiles for under-18s are not created | Approved Prototype (OPEN-20) |
| PRD-005 | LinkedIn must match linkedin.com/in/name; a link is not proof of skill or experience | Confirmed |
| PRD-006 | WhatsApp number is a valid 10-digit Indian mobile number (international formats later) | Proposed |
| PRD-007 | Resume upload accepts PDF, DOC and DOCX up to 5 MB; extracted values are shown for review; nothing is saved until confirmed; a parsing failure never blocks manual entry | Confirmed, PV |
| PRD-008 | Profile completeness and recruiter readiness are shown separately; readiness is never a hiring guarantee | Confirmed, PV |
| PRD-009 | Compensation fields are private by default and shared only under DEC-015 | Confirmed |
| PRD-010 | Consent is recorded with a timestamp for terms, resume sharing, recruitment sharing, alerts and visibility; withdrawing is as easy as giving | Confirmed |

### 6.2 Skills, verification and assessments

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-011 | Skills come from the taxonomy; unknown skills enter a suggestion queue; Admins add, merge or reject; clear matches with enough sightings (default 10) merge automatically | Confirmed (DEC-014), PV |
| PRD-012 | Labels: Self declared, Assessment verified, Experience verified, Certification verified, PP verified. A verified label exists only when an evidence record exists. Self declared is never styled as verified | Confirmed |
| PRD-013 | Certification evidence needs name, issuer and credential ID (optional link and expiry); experience evidence needs company, role, start month and a description of at least 20 characters (optional referee shown to reviewers only); an optional file is a PDF or image up to 5 MB; the member confirms accuracy | Confirmed, PV |
| PRD-014 | Only an Admin or SuperAdmin decides. Approval needs two checks ticked; asking for more evidence or rejecting needs a reason of at least 10 characters; the decision records who, when and which policy version | Confirmed (DEC-012), PV |
| PRD-015 | After a rejection the member can appeal once with a reason; an approved item can be revoked with a reason; an approval past its expiry becomes Expired and the label reverts | PV, Proposed |
| PRD-016 | Badge lifecycle: Earned, Displayed, Expiring (within 60 days), then Expired or Revoked, then Renewable | Proposed |
| PRD-017 | Each assessment defines category, level, version, attempts, pass criteria, retake gap, expiry and visibility (values in section 10, OPEN-05) | Confirmed (fields), Approved Prototype (values; production policy review required) |
| PRD-018 | A result records score, level, attempt, date, version and verification outcome; a pass does not create a verified label without an evidence record | Confirmed |

### 6.3 Learning, practice and content

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-019 | Shared learning states: Available, Enrolled, In progress, Completed, with Upcoming, Locked, Paused, Expired | Confirmed |
| PRD-020 | A lab submission has root cause, evidence, fix and optional prevention. A reviewer scores four areas from 0 to 4 and writes feedback of at least 10 characters. A pass needs every area at 2 or more and an average of 2.5 or more. A member has 3 attempts; a third Needs revision is final | PV, Approved Prototype (numbers) |
| PRD-021 | Content records owner, source, created, updated and review dates, status, visibility, topic, skill, difficulty and attribution; resources also need source and usage rights | Confirmed, PV |
| PRD-022 | Content moves Draft, In review, Published, Archived; a reviewer who requests changes gives a reason; unpublishing hides it from learners and keeps the record | PV |
| PRD-023 | Services are Free or Paid as in DEC-017; the price and GST are shown before purchase; some roles are for experienced members only | Confirmed (principle), Approved Prototype (price display; actual prices remain unset) |

### 6.4 Community

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-024 | Questions have a mode: Learning, Production issue or Expert design. A question needs a title of at least 8 characters, detail of at least 20 characters, and a confirmation that credentials and customer data were removed | Confirmed, PV |
| PRD-025 | Members can answer, vote answers useful, follow a question and report it; the asker accepts one answer; reports go to the moderation queue with a reason | Confirmed, PV |
| PRD-026 | Reputation rewards helpful and accepted answers, not raw activity | Confirmed |
| PRD-027 | A member can request a mentor with a topic and a goal of at least 20 characters; a mentor accepts or declines, and a decline needs a reason shown to the member | PV, Proposed |
| PRD-028 | Moderators dismiss or remove reported posts; every action is audited; the written policy and appeals path are in section 10 (OPEN-14) | PV, Approved Prototype |
| PRD-054 | A member accepts the community guidelines before the first post; the guidelines are one click away from every post form | Approved Prototype |

| PRD-055 | Community supports structured content types: Technical question, Discussion, Case study, Knowledge article, Event/AMA and Announcement; each type has fit-for-purpose fields, permissions and presentation | Proposed |
| PRD-056 | The discovery feed supports For you, Latest, Unanswered and Solved views; relevance uses followed topics, skills, freshness and usefulness, with member controls to mute, hide, save and follow topics | Proposed |
| PRD-057 | The technical composer supports Markdown, code/configuration blocks, attachments, previews, drafts, edit history and a pre-publish sensitive-data warning/redaction aid | Approved Prototype; safety validation required before production |
| PRD-058 | Community search covers questions, answers, articles, members, mentors, groups, events, technologies and related learning resources; results support type, tag, author, status and date filters | Proposed |
| PRD-059 | Curated groups and interest spaces support membership, posts, resources, moderators and optional events; event workflows support RSVP, time-zone-aware times, reminders and post-event resources | Approved Prototype; phased |
| PRD-060 | Community identity records contributions, saved resources, mentoring and topic expertise; public/member visibility is controlled separately from recruiter-facing profile visibility | Approved Prototype; privacy validation required before production |
| PRD-061 | Community reputation rewards accepted/useful answers, maintained knowledge, helpful edits, mentoring and stewardship; it is never a substitute for skill verification or certification | Proposed |
| PRD-062 | Skill verification may run in Manual, AI-assisted or Automated mode per verification program. Automated mode is an experiment candidate behind feature flags, with configurable rules/thresholds, evidence requirements, policy/model version, reason codes, audit, member notice, appeal/re-review and human fallback for configured cases | Experiment candidate; approved for controlled evaluation |
| PRD-063 | A knowledge graph links taxonomy skills and topics to discussions, accepted solutions, case studies, courses, lessons, labs, assessments, evidence and relevant opportunities; the same canonical skill taxonomy remains the source of truth | Approved Prototype; phased |
| PRD-064 | Community analytics measures meaningful outcomes including time to first helpful answer, answered-question rate, search success, useful contribution, returning contributors, knowledge reuse and contributor concentration | Proposed |
| PRD-065 | Feature experiments have an owner, hypothesis, target cohort, feature flag, success/safety measures, review window, feedback record and next-build decision: retain, refine, restrict or disable | Confirmed process direction |

| PRD-066 | Community Resources is a searchable, curated library for guides, documentation, tools, templates, cheat sheets, labs, repositories, videos, courses and articles. Discovery supports For you, Featured, Recent, Popular and Staff Picks plus category, format, technology, difficulty, audience and sort filters | Approved Prototype |
| PRD-067 | A resource detail view shows source, author/contributor, summary, type, topic/skill tags, difficulty, estimated time, version, last reviewed date, licence/usage rights, preview/open/download actions, related resources and community discussion | Approved Prototype |
| PRD-068 | Members can submit a resource by uploading a supported file, adding an external URL or writing an article. A guided Details → Content → Review & publish flow captures title, description, type, categories, technologies, intended audience, difficulty, source attribution and licence; drafts are recoverable | Approved Prototype; file/security and rights checks required before publication |
| PRD-069 | Members can save resources, organise them into named collections, track reading/learning state and resume from recently viewed or in-progress resources. Collections have explicit private/shared visibility | Approved Prototype |
| PRD-070 | Resource lifecycle supports Draft, Submitted, In review, Changes requested, Published, Hidden, Archived and Rejected. Review actions, version history, link health, malware scan results and takedown decisions are auditable | Approved Prototype; moderation and security gates apply |
| PRD-071 | Signup supports the existing email/password or passkey path, email verification and optional provider sign-in buttons (initial prototype may show Google/GitHub). Provider sign-in or account linking is enabled only when the repository, provider configuration and security review support it | Approved Prototype; provider integration may be simulated until configured |
| PRD-072 | Onboarding personalises discovery using role, interests and goals. Role options include Student, Engineer, Specialist, Mentor and Recruiter; interests use the canonical taxonomy; goals include Learn, Practice, Contribute, Mentor and Find opportunities. Optional steps can be skipped and changed later | Approved Prototype |
| PRD-073 | Member profile separates professional identity from account controls and includes overview, skills, verification labels, experience, education/certifications, contributions, learning, mentoring and achievements; visibility is scoped by audience and consent | Approved Prototype |
| PRD-074 | Members can preview their profile as themselves, as a community member and as a recruiter after forwarding. Preview must enforce the exact PRD-015 visibility rules and must never expose private fields through the preview | Approved Prototype; public web profile remains opt-in/later unless separately approved |
| PRD-075 | Account Control Centre groups personal information, profile visibility, notifications, security, sessions, connected accounts, privacy/data rights and billing where applicable. Sensitive changes require step-up authentication and an audit record | Approved Prototype |
| PRD-076 | An optional profile-completeness assistant may suggest missing high-value profile details without blocking access, forcing 100% completion or using shame/urgency. An optional identity timeline records meaningful milestones with member-controlled visibility | Approved Prototype |
| PRD-077 | Resource, course and community recordings support a consistent embedded video/audio experience with adaptive streaming where available, captions/subtitles, searchable transcripts, chapters, playback speed, fullscreen, picture-in-picture where supported, progress/resume, time markers, optional audio waveform and clear source/provider attribution | Approved Prototype |
| PRD-078 | Supported files open in an appropriate embedded preview: PDF, images, audio/video, text/Markdown/code and safe tabular previews. Office formats may use an isolated conversion/preview path or a separately licensed provider; unsupported types receive a clear download/fallback state | Approved Prototype; format/security matrix required |
| PRD-079 | Media and document uploads show a complete lifecycle: selection, validation, upload, pause/resume/retry/cancel, scanning, processing/transcoding, preview generation, moderation and publication. Interrupted uploads can resume where the transport supports it | Approved Prototype; storage and scanning implementation gated by repository/security audit |
| PRD-080 | External media embeds are resolved through an approved provider allow-list and secure embed wrapper. The platform validates URLs and provider IDs, applies CSP/frame policies, sandbox/permission attributes where applicable, consent rules and safe fallbacks; arbitrary iframe or HTML injection is not permitted | Approved Prototype; security gate |
| PRD-081 | Parent/child screens preserve parent context, URL/deep-link state, breadcrumbs, browser history, query filters, scroll position and keyboard focus. Child details may use a full route, contextual drawer or inline expansion according to task, content complexity and viewport | Approved Prototype |
| PRD-082 | PacketPulse maintains an adaptable brand-pattern library using packet routes, node constellations, signal waves, pulses, radar, secure layers, data flows, matrices and future motifs. Patterns are transparent/independent overlays and do not alter page/card backgrounds by themselves | Approved Prototype |
| PRD-083 | The visual system may explore the broader Signal Grove token palette, module accents, semantic colours and additional experimental colourways, gradients and Pantone references. Colour is not restricted to green; variants are reviewed for meaning, legibility, accessibility and brand fit | Approved Prototype |
| PRD-084 | Media playback, document viewing, resource detail and nested child workflows share consistent loading, empty, error, permission, offline, unavailable-provider, unsupported-format and recovery states | Approved Prototype |

### 6.5 Jobs and recruitment

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-029 | Application states: Received, Processing, Under review, Shortlisted, Ready to forward, Forwarded, Interview, Selected, Joined, plus Rejected, Withdrawn, Job closed. History is never erased | Confirmed |
| PRD-030 | Automation can recommend; an authorized person confirms shortlisting and forwarding; reviewer, time and notes are logged | Confirmed |
| PRD-031 | A position moves Draft, In review, Published, Paused, Closed (Fulfilled or Unfulfilled) and can be reopened. Reopening needs a future deadline and more openings than were filled. Each position keeps vacancies filled, dates and a hiring history | PV, Proposed |
| PRD-032 | Company recruiters see only candidates forwarded to their jobs, and only the fields allowed by DEC-015; date of birth is never shown to companies; every resume open is logged | Confirmed |
| PRD-033 | A recruiter review records a decision (Under review, Shortlisted, On hold, Rejected), a scorecard of four areas from 1 to 5, an interview recommendation and a next step. On hold and Rejected need a reason of at least 10 characters; On hold needs a future revisit date | PV, Proposed |
| PRD-034 | An interview records round, format, a named interviewer and a future time in IST; the candidate is notified and gets a reminder | PV |
| PRD-035 | An offer records CTC, a future joining date and a validity date before joining. The candidate accepts, or declines with a reason; a declined offer lowers the filled count | PV |
| PRD-036 | Roles marked experienced-only block freshers with an explanation | Confirmed (DEC-017), PV |
| PRD-050 | A member can hide their profile from named companies (for example a current employer). A hidden company never sees the profile in search or in forwarded lists | Approved Prototype |
| PRD-051 | After forwarding, a recruiter is reminded when a candidate has had no status update for 10 working days; the candidate sees the last update date and a plain note that no update has been made yet | Approved Prototype |
| PRD-052 | Profiles are visible only to PacketPulse staff and, after forwarding, to the recruiter. No public web profile and no search-engine indexing at launch; a public profile is a later opt-in decision | Approved Prototype |
| PRD-053 | Every candidate always sees a status for each application. A rejection shows a reason only when the recruiter chose to share one; the candidate can ask PacketPulse for general feedback | Approved Prototype |

### 6.6 Fees, payments and billing

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-037 | The placement fee applies only to roles that carry it and is shown on the role and on the public fees page. When applying, the candidate ticks a declaration and gives explicit permission; accepting an offer shows the exact amount and needs a second confirmation | Confirmed (DEC-016), PV |
| PRD-038 | The fee is a percentage of the annual offer (default 1%, configurable from 0.1% to 5%). The invoice is created only after the candidate joins and is due in 15 days; a declined offer or a withdrawn application owes nothing | Confirmed (default), Proposed (timing) |
| PRD-039 | Refunds need a reason; a refund requested by an Admin needs a SuperAdmin's approval | PV, Confirmed by delegation |
| PRD-040 | Payments use a provider-hosted checkout; no card data is stored; provider confirmations are verified and processed once | Proposed |

### 6.7 Notifications, privacy, security and AI

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-041 | A central notification service sends in-app messages, email and (opt-in) WhatsApp, respects preferences and quiet hours, logs delivery, and lets critical events (interviews, offers, security) through | Confirmed (service), values in section 10 (OPEN-04) |
| PRD-042 | Admin accounts meet DEC-020: required MFA, passkeys preferred, no SMS codes, no temporary passwords, session limits, step-up with reason and fresh code, lockout after repeated failures, break-glass with a second SuperAdmin, periodic access review | Confirmed by delegation |
| PRD-043 | The audit log is append-only and records actor, subject, reason and time for screening, moderation, settings, access, verification, practice, content and recruitment actions | Confirmed |
| PRD-044 | Only a SuperAdmin changes roles, permissions, visibility and AI policy; every change is audited | PV |
| PRD-045 | DPDP: plain notice, specific consent, easy withdrawal, export and erasure, a grievance contact, breach reporting within the required time, and processing agreements with every provider | Planned (DEC-026) |
| PRD-046 | Resumes and certificates are private, reached through short-lived links, and every open is logged | Confirmed |
| PRD-047 | AI assistance follows DEC-019 and DEC-044: drafts and recommendations are labelled; recruitment, financial and sensitive account actions remain human-confirmed by default; automated skill verification is permitted only under PRD-062 experiment controls | Updated 24 Nov 2026 |
| PRD-048 | English is the default; a Hindi switch is offered; dates and numbers follow the language | Approved Prototype, PV (partial) |
| PRD-049 | The product targets WCAG 2.2 AA in light and dark themes, with keyboard access, visible focus and status never shown by color alone | Confirmed |

## 7. Roles and permissions summary

| Capability | Member | Mentor | Instructor | Recruiter | Admin | SuperAdmin |
| --- | --- | --- | --- | --- | --- | --- |
| Own profile, learning, applications | Yes | Yes | Yes | No | Yes | Yes |
| Review lab submissions | No | Yes | Yes | No | Yes | Yes |
| Author content | No | No | Yes | No | Review and publish | Yes |
| See forwarded candidates | No | No | No | Own company only | Screening view | Screening view |
| Manage positions | No | No | No | Own company | Review and publish | Yes |
| Decide verification | No | No | No | No | Yes | Yes |
| Moderate community | No | No | No | No | Yes | Yes |
| Finance and refunds | No | No | No | No | Request refunds | Approve refunds |
| Users, roles, policies, security | No | No | No | No | Limited | Yes |

Every request is checked on the server for permission (DEC-010). Roles are additive on one account (DEC-009). A review-only Hiring manager role is recommended for company pilots but not built first (OPEN-11).

## 8. Release scope (Proposed)

| Release | Scope | Why this order |
| --- | --- | --- |
| 1 Foundation | Identity, onboarding, profiles, taxonomy, community, notifications, operations, security, privacy | Everything else depends on trusted identity and consent; the 2,000 existing members need a safe move |
| 2 Prove | Learn, practice, assessments, verification | Evidence must exist before recruiters can rely on it |
| 3 Careers | Jobs, recruitment, offers, billing, placement fee | Depends on profiles, evidence and payments |
| 4 Intelligence and ecosystem | AI drafting, integrations, deeper analytics, public API | Valuable only on stable data |

MVP release blockers: consent and erasure basics, server-side permissions on every route, private file handling, the audit log, backups with a tested restore, and a staged rollout with rollback.

## 9. Decision register

The single record of what was decided and what replaced what. When a decision changes, change it here first, then the other documents.

| ID | Decision | Status |
| --- | --- | --- |
| DEC-001 | Tagline Connect, Learn & Grow Together; the loop Learn, Practice, Prove, Verify, Connect, Get Hired, Grow is the test for every feature | Confirmed |
| DEC-002 | One platform: one account, one skill model, one permission model, shared components | Confirmed |
| DEC-003 | Signal Grove remains the core visual identity. Editorial Workspace stays light-first with a designed dark option; Analytical Workspace uses Matte Black Edition as its preferred dashboard reference, with light mode still supported (replaces Network Console, Moodboard v2 and Card System v1) | Confirmed; refined 24 Nov 2026 |
| DEC-004 | Inter for UI, JetBrains Mono for technical text, Noto Sans Devanagari as the Hindi fallback | Confirmed |
| DEC-005 | Module accents: Community forest, Learning indigo, Recruitment blue, Payments plum | Confirmed (blue by owner; plum by delegation) |
| DEC-006 | Information state is slate; Experience verified label uses recruitment blue | Confirmed by delegation |
| DEC-007 | Status is shown with text and a glyph, never color alone | Confirmed |
| DEC-008 | Breakpoints 640, 768, 1024, 1280, 1536 px | Confirmed |
| DEC-009 | Roles are additive on one account: Member, Mentor, Instructor, Recruiter, Admin, SuperAdmin | Confirmed |
| DEC-010 | Permissions are enforced on the server for every route, field and action; hidden screens are not security | Confirmed |
| DEC-011 | Candidate profile, job and application are separate records; job-specific status lives on the application | Confirmed |
| DEC-012 | Verification approvers: Admin or SuperAdmin | Confirmed |
| DEC-013 | Evidence model with five labels plus Pending; each decision records who, when, policy version, expiry; one appeal; revocation and expiry | Confirmed (labels), PV (appeal, revoke, expiry) |
| DEC-014 | Skill taxonomy Major, Minor, Micro owned by Admins; new skills arrive as suggestions; clear matches merge automatically | Confirmed |
| DEC-015 | Visibility: PacketPulse screening team sees the full profile before forwarding; company recruiters see the allowed fields after forwarding; date of birth stays hidden; SuperAdmin can adjust after-forwarding fields | Confirmed (principle), PV (table) |
| DEC-016 | Placement fee: candidate-paid, default 1% of annual offer, declaration and permission when applying and again when accepting, shown publicly | Confirmed (principle); safeguards in 10.5 **[APPROVED PROTOTYPE]** |
| DEC-017 | Free versus paid: advanced courses, live lab sessions and some placements are paid; some roles are experienced-only | Confirmed (principle); prices Open |
| DEC-018 | Required onboarding fields as in PRD-003 | Confirmed |
| DEC-019 | AI drafts and suggests; it cannot make recruitment selection/forwarding, financial, role/password, suspension/deletion or other sensitive account decisions by default. Skill verification is separately eligible for controlled experiments under DEC-044 and PRD-062 | Confirmed; clarified 24 Nov 2026 |
| DEC-020 | Admin security baseline: required MFA, passkeys preferred, no SMS, no temporary passwords for admins, session limits, step-up, lockout, second approval for Admin refunds, break-glass, access reviews | Confirmed by delegation |
| DEC-021 | Existing stack: Next.js for frontend and backend, an existing backend service, PostgreSQL (Supabase), Redis, hosted on Vercel and Render | Confirmed |
| DEC-022 | The system of record is PostgreSQL through Supabase | Confirmed |
| DEC-023 | No technology is replaced without a concrete requirement and owner approval | Confirmed |
| DEC-024 | New work is organised as modules with clear ownership inside the existing backend | Proposed |
| DEC-025 | The earlier proposals for a new authentication library, a new data-access library, a new job queue and a cloud move are withdrawn as defaults | Deprecated |
| DEC-026 | DPDP Act and Rules 2025 duties are product requirements; main duties apply from about 14 May 2027 | Planned |
| DEC-027 | The earlier six-document suite and ID scheme are kept as IDs | Confirmed |
| DEC-028 | English and Hindi language switch | Proposed (PV for navigation, titles, home) |
| DEC-029 | Sandbox checkout first; provider chosen later | Proposed |
| DEC-030 | ClickUp and n8n are an operations aid; the application database stays the source of truth | Planned; live status unknown |
| DEC-031 | Color guidance: thoughtful surface hierarchy, broad brand/module palette, expressive accents and gradients, amber warnings, red errors, both themes, adequate contrast, icons and labels with color | Confirmed |
| DEC-032 | Frontend and backend are both Next.js; the database is PostgreSQL; the stack stays as it is | Confirmed (owner, 17 Oct) |
| DEC-033 | The canonical documentation set is five documents; this set covers design, features, UX and flows, while code and versions are handled by a developer and an AI coding agent in another workspace | Confirmed (owner, 17 Oct) |
| DEC-034 | Open questions get a best-practice recommendation marked [APPROVED PROTOTYPE] and stay Open until the owner approves | Superseded by DEC-048 on 25 Nov 2026 |

| DEC-035 | Signal Grove uses two complementary layout families: Editorial Workspace for reading, community and member journeys; Analytical Workspace for operations, recruitment and data-heavy work | Confirmed direction |
| DEC-036 | Matte Black Edition is the preferred visual reference for analytical dashboards; near-black tokens are scoped to this workspace and do not replace the full light/dark theme system | Confirmed direction; exact tokens require contrast validation |
| DEC-037 | Intentional whitespace is a product-wide UX requirement. Density modes are Comfortable (default), Compact (data-heavy work) and Reading (long-form content) | Confirmed direction |
| DEC-038 | Emotional experience is a design requirement: screens should feel calm, welcoming, capable, clear and rewarding; avoid clutter, urgency tricks and engagement farming | Confirmed direction |
| DEC-039 | Dashboard pattern: role-aware grouped sidebar, clear page header, 4–5 meaningful KPIs, primary analytics area, collapsible contextual rail and detailed data/activity region | Confirmed direction; adapt per role |
| DEC-040 | Adopt a curated open-source UI strategy: shadcn/ui as the preferred source-owned component base; Ingot UI as an optional curated component source; inspect the existing app before choosing or migrating primitives | Recommended; repository audit required |
| DEC-041 | Tailwind CSS v4 is the styling standard. Tailwind Play CDN is for prototypes only; production Next.js must compile Tailwind during the build | Confirmed direction with production constraint |
| DEC-042 | Use a restrained motion system with Motion for React as the preferred animation library; microanimations must support feedback, orientation or comprehension and respect reduced motion | Recommended; dependency audit required |
| DEC-043 | Use curated media sources: Lucide for UI icons, Simple Icons for technology logos, Unsplash/Pexels for photography, unDraw for illustrations, and LottieFiles/Rive for selected motion assets; check asset terms individually | Recommended |
| DEC-044 | Automated skill-verification decisions remain in scope as controlled experiments, including approval, rejection or request-more-evidence outcomes under configured thresholds, audit, appeal, fallback and feature flags | Confirmed scope direction |
| DEC-045 | Every experimental feature has a defined review window and evidence-based decision for the next build: retain, refine, restrict or disable | Confirmed process direction |
| DEC-046 | Community evolves into an engineering knowledge network with structured content, discovery, search, contribution identity, curated groups/events and links to learning/practice/verification | Proposed product direction |
| DEC-047 | Organisation/private-community and white-label capabilities should be considered in the architecture, but full multi-tenancy, custom domains, SSO and billing are deferred until validated demand | Proposed; architecture-ready only |
| DEC-048 | All previously open-for-approval product/design recommendations are Approved Prototype for inclusion in the next review build; team review may Retain, Refine, Restrict or Remove them for the following build | Owner-confirmed, 25 Nov 2026 |
| DEC-049 | Explore logotype and display-type directions in the review build while retaining Inter as the interim product UI/wordmark treatment; do not let typography experiments block the build | Approved Prototype; final brand asset remains open |
| DEC-054 | Creative direction is intentionally open: Signal Grove is a shared foundation, not a fixed aesthetic ceiling or a rigid rulebook. Explore the existing token palette, new colour families, gradients, Pantone-referenced studies, expressive typography, spatial compositions, waves, pulses, packet/node/security motifs and other visual ideas when they improve usability, emotional quality or brand character. Keep contrast, status meaning and accessibility understandable; treat design principles as guidance to test rather than constraints to obey blindly | Owner-confirmed, 26 Nov 2026 |
| DEC-055 | Brand motifs are reusable transparent overlays (not replacement backgrounds). For the current pattern exercise, preserve existing page/card backgrounds and design overlays that can be layered, recoloured, cropped or omitted. A separate future surface redesign can be explored on its own merits | Owner-confirmed, 26 Nov 2026 |
| DEC-056 | Preferred review-build player foundation: Video.js 10 React package (`@videojs/react`), current researched release 10.7.0 as of 26 Nov 2026. Choose only the required source adapters; Shaka Player remains a specialist alternative for advanced adaptive/offline/DRM requirements. Explore WaveSurfer.js as an optional audio-only waveform and timestamp-navigation layer, with standard audio controls always available | Approved Prototype; repository, provider, codec and licence validation required |
| DEC-057 | Preferred review-build upload layer: Uppy React headless/hooks with Tus resumable upload where supported. A pre-composed Uppy dashboard may be used for prototypes, but PacketPulse styling should use headless/custom UI. Backend/storage integration remains subject to audit | Approved Prototype; repository/storage/security validation required |
| DEC-058 | PDF preview preference: React-PDF over PDF.js. Other office-document preview may use secure isolated conversion or a separately licensed provider; ONLYOFFICE Community Edition AGPL implications must be reviewed before use in a proprietary SaaS | Approved Prototype; licence/security review required |
| DEC-059 | Nested navigation is route-aware and context-preserving. Use page routes for substantial child workflows, drawers/sheets for contextual inspection, and inline expansion for lightweight details; avoid modal stacks and context loss | Approved Prototype |
| DEC-060 | Media embeds use known providers and safe, explicit rendering modes. Never render arbitrary member-supplied iframe/HTML as trusted content; enforce server-side validation, provider allow-list, CSP and source-specific handling | Approved Prototype; security gate |
| DEC-061 | Brand-pattern families are an open, expandable vocabulary, not an exhaustive mandatory list. The team may invent or evolve motifs and combine token colours when the visual result is useful, distinct and accessible | Owner-confirmed, 26 Nov 2026 |


**Decision-ID continuity note (25 November 2026):** The prior change log records that DEC-048 to DEC-053 were added. The available handoff text preserves DEC-048 (the review-build approval disposition) and a DEC-049 reference to typography exploration, but does not preserve descriptions for DEC-050 to DEC-053. Those four IDs are reserved for recovery from the original source discussion; no decisions have been invented and the IDs must not be reused.

### 9.1 Contradictions resolved

| ID | Conflict | Resolution |
| --- | --- | --- |
| CON-01, CON-13 | Dark-first Network Console versus light-first Signal Grove | Signal Grove (DEC-003) |
| CON-02 | Moodboard v2 and Card System v1 versus Signal Grove tokens | Signal Grove; old files are reference only |
| CON-03 | Instrument Sans, Neue Montreal, Therilo, Goodly versus Inter | Inter in the product; logotype open (OPEN-02) |
| CON-04 | Jobs orange and Payments teal versus recruitment blue and Payments plum | Latest decisions apply (DEC-005) |
| CON-05 | Information indigo equals Learning indigo | Slate for Information (DEC-006) |
| CON-06 | Forest versus blue primary actions; teal progress | Open (OPEN-01), recommendation in section 10 |
| CON-07 | Placement fee not to be hard-coded versus approved at about 1% | Owner decision applies; keep it configurable and under legal review |
| CON-08 | PP Verified and Assessment Verified overlap | Open (OPEN-03), definitions in 10.1 |
| CON-09 | Mandatory onboarding fields differ between documents | Owner's list (DEC-018) |
| CON-10 | MongoDB versus Supabase PostgreSQL | PostgreSQL (DEC-022) |
| CON-11 | New stack components proposed versus the stack that exists | Keep the stack (DEC-023, DEC-025) |
| CON-12 | Names: Education, Learning, Learn; HRMS, Operations, Recruitment | Community, Learn, Practice, Assessments, Verification, Jobs (member), Recruitment (recruiter), Operations (admin), Payments |
| CON-14 | Earlier checklist treats Terminal Green, Packet Cyan and Infrastructure Amber as status colors | The semantic table in Document 2 applies |

## 10. Approved prototype decisions and remaining discovery

Owner disposition, 25 November 2026: every product/design item previously marked open for approval is now **Approved Prototype** and must be represented in the next review build. This approval authorises a prototype or review-build experience, not production release, live payment processing, legally binding policy, or installation of an external dependency. The team will review it during the agreed review window and record **Retain, Refine, Restrict or Remove** for the following build. Sections 10.1 to 10.9 contain the approved prototype defaults. Legal, security, provider, repository and operational confirmations remain production gates where stated.

| ID | Question | Recommended answer **[APPROVED PROTOTYPE]** | Basis | Decider |
| --- | --- | --- | --- | --- |
| OPEN-01 | Primary action color; progress color | Use Forest as a familiar default, not a universal lock. Prototype context-aware primary actions using brand or module accents (including indigo, blue, plum, cyan, violet and suitable new colourways); let progress use the most meaningful contextual token. Keep semantic status states distinguishable | Test hierarchy, contrast, emotional feel and consistency in real screens. A colour may be right for one workflow and wrong for another; don't force every module or primary action to be green | Owner, design lead |
| OPEN-02 | Logotype typeface | Use the name in Inter semibold now; commission one logotype later and keep it separate from the UI font | Logotypes are brand assets; supply vector lockups, minimum size, clear space and a favicon | Design lead |
| OPEN-03 | PP Verified versus Assessment Verified | See 10.1 | Digital credential practice shows issuer, criteria, evidence and validity | Product lead |
| OPEN-04 | Notification channels, frequency, quiet hours | See 10.3 | Opt-in channels, separate transactional and marketing messages, critical events exempt | Product lead |
| OPEN-05 | Assessment rules | See 10.2 | Certification programs use limited attempts with waiting periods and expiry | Product lead |
| OPEN-06 | Data retention | See 10.7 | Keep personal data only as long as the purpose needs; legal minimums for tax records | Owner, counsel |
| OPEN-07 | Placement fee legal review and safeguards | See 10.5 | International fair-recruitment guidance says workers should not bear recruitment fees; if kept, charge only after joining with clear terms and a refund window | Owner, counsel |
| OPEN-08 | Payment provider and GST invoicing | Evaluate Razorpay first, with Cashfree as the comparison; hosted checkout; GST-inclusive prices shown | Common providers in India support UPI, cards and netbanking; hosted checkout keeps card data away from PacketPulse | Owner |
| OPEN-09 | Prices | The owner sets them; recommended method in 10.8 | Show the final price including GST before purchase | Owner |
| OPEN-10 | Company onboarding and verification | See 10.6 | Marketplaces verify the employer before the first listing | Product lead |
| OPEN-11 | Hiring-manager role | Add a review-only Hiring manager role after the first company pilots; not in Release 1 | Least privilege | Product lead |
| OPEN-12 | ClickUp and n8n scope | Decide after the audit; mirror IDs and statuses only; no resumes, contact details or compensation in ClickUp; application database stays the source of truth | Keep personal data in one controlled place | Operations lead |
| OPEN-13 | Authentication policy | See 10.9 | Follow current password guidance (length over complexity, no forced rotation, breach checks) and phishing-resistant MFA for staff | Tech lead |
| OPEN-14 | Moderation policy and appeals | See 10.4 | Clear rules, graded actions, a fast response and an appeal by a different person | Community lead |
| OPEN-15 | Which routes and screens exist today | A developer task, not a product decision (Document 4, TASK-001) | Documentation is not proof of a feature | Tech lead |
| OPEN-16 | Analytics provider and events | Keep the current tool; adopt the events in section 4; no personal data in events; ask consent for non-essential tracking | Privacy by design | Product lead |
| OPEN-17 | Referral and reactivation programs | Do not build before launch; test later with rewards after a referred member completes a real action, with caps | Avoids rewarding fake sign-ups | Product lead |
| OPEN-18 | Sender identity and WhatsApp provider | Use a dedicated sending domain with email authentication; keep transactional and marketing streams apart; set up a WhatsApp Business account with approved templates now because approvals take time | Deliverability and consent | Operations lead |
| OPEN-19 | Profile visibility default and public profiles | Private by default; visible to staff and, after forwarding, to the recruiter; no public profile or search-engine indexing at launch (PRD-052) | Privacy first; members can opt in later | Owner |
| OPEN-20 | Minimum age | 18 or older at registration, checked from date of birth (PRD-004) | Processing a child's data needs verifiable parental consent under DPDP; an adult-only rule is the simplest safe default; counsel to confirm | Owner, counsel |
| OPEN-21 | Candidate protections | Adopt PRD-050 (hide from named companies), PRD-051 (response reminders) and PRD-053 (status and feedback) | Job platforms commonly let members block current employers and expect timely updates | Product lead |

### 10.0.1 Owner disposition for the existing OPEN register (25 November 2026)

| ID range | Current disposition | Review-build treatment | Production gate |
|---|---|---|---|
| OPEN-01 to OPEN-14 | Approved Prototype, except where an item is a legal/security/provider condition | Prototype the recommended UI, states, configuration and realistic demo data | Counsels, payment provider, auth provider and security confirmations remain mandatory where relevant |
| OPEN-16 to OPEN-21 | Approved Prototype | Include the proposed analytics, referrals, visibility controls, age gate, candidate protections and notification/sender settings in reviewable prototype flows | Consent, legal age policy, provider approvals and privacy controls require production sign-off |
| OPEN-15 | Discovery required | Repository audit only; do not guess which routes or screens exist | Must be answered by TASK-001 before implementation claims |

**Interpretation:** “Approved Prototype” means build it for review. It does not mean the value, policy, vendor, package or legal position is final. Where an external dependency is unavailable, use an explicit simulated state or sandbox and label it as such. Do not process real payments, send real communications or expose private data merely to make a prototype appear functional.

### 10.1 Verification labels (OPEN-03) **[APPROVED PROTOTYPE]**

Every badge shows what was checked, who checked it, when, and when it expires. A public page called How verification works lists the criteria.

| Label | Meaning | Evidence needed |
| --- | --- | --- |
| Self declared | The member says they have the skill | None; shown as neutral, never as verified |
| Assessment verified | The member passed a PacketPulse assessment for that skill, within its validity | A passed result |
| Certification verified | PacketPulse checked the credential with its issuer name and credential ID | Certificate details and a reviewer decision |
| Experience verified | PacketPulse reviewed employment or project evidence | Evidence record and a reviewer decision |
| PP verified | A higher standard: at least two different evidence types for the skill, one of them reviewed by a person (for example a passed assessment plus a passed lab review, or an assessment plus verified experience) | Two evidence records and a reviewer decision |

### 10.2 Assessment rules (OPEN-05) **[APPROVED PROTOTYPE]**

| Rule | Recommended default |
| --- | --- |
| Attempts | 3 per assessment in any 90 days |
| Retake gap | 7 days after a failed attempt |
| Pass mark | 70%, adjustable per assessment between 60% and 80% |
| Time limit | Set per assessment and shown before starting |
| Question order | Randomized from a pool at least twice the size of one attempt |
| Result screen | Score, level and weak topics; correct answers are not revealed |
| Validity | 24 months; renewal by retake or newer evidence; a reminder 60 days before expiry |
| Honesty | The member accepts an honesty statement before starting; no outside help |
| Proctoring | None at launch; review the need if recruiters report cheating |
| Accessibility | Extra time on request, approved by an Admin |

### 10.3 Notification policy (OPEN-04) **[APPROVED PROTOTYPE]**

| Topic | Recommended rule |
| --- | --- |
| In-app | Every event |
| Email | Application status, interviews, offers, assessment results, security, billing; community replies as an optional daily or weekly digest |
| WhatsApp | Opt-in only, for interviews and offers, using approved templates |
| Marketing | A separate opt-in with an unsubscribe link in every message |
| Quiet hours | 21:00 to 08:00 IST for non-critical messages |
| Critical events (sent during quiet hours) | Security alerts, an interview within 24 hours, an offer expiring within 48 hours |
| Frequency cap | No more than 3 non-critical messages per member per day |
| Reminders | Interview reminders 24 hours and 1 hour before; badge expiry 60 and 14 days before |
| Privacy | No resume, compensation or private notes in previews or subject lines |

### 10.4 Moderation policy (OPEN-14) **[APPROVED PROTOTYPE]**

**Rules.** Be respectful. Never post passwords, keys, customer data or confidential network configurations. No job spam, solicitation or advertising in questions. Do not copy assessment answers. Credit sources. No harassment, doxxing or discrimination.

| Step | Action |
| --- | --- |
| 1 | Remove the post and tell the author the reason |
| 2 | Warning |
| 3 | Posting limit for 7 days |
| 4 | Posting limit for 30 days |
| 5 | Account suspension (needs two admins to agree) |

| Service level | Target |
| --- | --- |
| Reports acknowledged | Within 24 hours |
| Urgent reports (exposed credentials, harassment) | Within 4 hours |
| Appeals | Reviewed by a different Admin within 5 working days |

Reputation rises with accepted and useful answers and falls with removed posts. Reputation does not unlock sensitive tools at launch.

### 10.5 Placement fee safeguards (OPEN-07) **[APPROVED PROTOTYPE]**

The owner's decision (DEC-016) stands. Fair-recruitment guidance from the International Labour Organization says workers should not carry recruitment fees, so the following safeguards reduce risk if the fee is kept. Counsel confirms them for each region before the fee is switched on.

- Charge only after the candidate joins; never before an offer and never for screening or forwarding.
- Show the exact amount on the role, in the apply step and again when accepting the offer (already in PRD-037).
- Refund window: recommended full refund if employment ends within 30 days of joining and 50% within 90 days.
- The fee never changes screening, ranking or forwarding; staff must not see whether a candidate has agreed to a fee while screening.
- Offer employer-paid roles as the default listing type, and mark candidate-paid roles clearly.
- Cap the percentage (0.1% to 5%, already in PRD-038) and show a worked example on the fees page.
- Provide a dispute route with a reply in 5 working days and issue a GST invoice with every payment.

### 10.6 Company onboarding and verification (OPEN-10) **[APPROVED PROTOTYPE]**

1. The recruiter signs up with a work email; free email domains are held for review.
2. They enter the company name, website, size, contact person, and optionally the company registration or GST number and a LinkedIn company page.
3. An Admin reviews the company profile; the company stays in Pending until approved.
4. The first position is always reviewed before it is published; later positions need review only if flagged.
5. Companies that are rejected or later reported can be suspended; the reason and the reviewer are recorded.
6. Staffing agencies are labelled as agencies and must name the end client on each position.

### 10.7 Data retention (OPEN-06) **[APPROVED PROTOTYPE — COUNSEL GATE BEFORE PRODUCTION]**

| Data | Suggested keep period |
| --- | --- |
| Account and profile | While the account is active; erased within 30 days of an erasure request unless the law requires a longer record |
| Inactive accounts | Notice after 2 years of inactivity; personal data erased after 3 years (similar to a rule the DPDP Rules apply to some large platforms) |
| Resume copies shared with companies | Company access ends 90 days after the application closes |
| Verification evidence files | Delete files 12 months after the decision unless an appeal or expiry needs them; keep the decision record |
| Consent records | For the life of the account plus 3 years, as proof |
| Audit log | At least 3 years |
| Invoices and payment records | As required by Indian tax and company law (commonly 6 to 8 years); the accountant confirms |
| Community posts | Kept; the author's name is removed on erasure when others depend on the content |
| Notification and delivery logs | 12 months |
| Backups | Erased data leaves backups on the normal rotation and is never restored |

### 10.8 Payments and prices (OPEN-08, OPEN-09) **[APPROVED PROTOTYPE]**

- Use the provider's hosted checkout; confirm a payment from the provider's own notification, not from the browser returning to the site.
- Show prices including GST, then the breakdown on the receipt and invoice.
- Refund policy to publish: full refund within 7 days if less than 10% of a course was used; live sessions refundable up to 48 hours before the start.
- Method to set prices: list every paid item, check what comparable training sells for, start with a small number of paid items, test the price with early members, and change it only with notice. No prices are invented here.

### 10.9 Authentication and admin policy (OPEN-13) **[APPROVED PROTOTYPE]**

| Rule | Recommended default |
| --- | --- |
| Passwords | At least 12 characters, checked against known breached passwords, no complexity rules and no forced rotation; passkeys offered |
| Multi-factor | Required for Admin, SuperAdmin and Recruiter accounts; optional for members; authenticator app or passkey, never SMS |
| Sessions | Members: sign out after 30 days idle; staff: 30 minutes idle and 8 hours absolute |
| Sensitive actions | Ask for a reason and a fresh code (step-up) |
| Lockout | After 5 wrong codes, 15 minutes |
| Recovery | Members by email; staff only through a SuperAdmin with a second approver |
| LinkedIn | Optional sign-in with LinkedIn to prove the profile belongs to the member, using only the fields needed; otherwise syntax check only (PRD-005) |

## 11. Risk register

| ID | Risk | Impact | Likelihood | Mitigation |
| --- | --- | --- | --- | --- |
| RISK-01 | The production system differs from every assumption here | High | High | Repository audit before any build task |
| RISK-02 | DPDP duties (main phase about 14 May 2027) are missed | High | Medium | Consent, export, erasure and breach process in the first releases; counsel review |
| RISK-03 | The candidate-paid fee is restricted in some regions or draws complaints | High | Medium | Safeguards in 10.5; per-region switch; counsel review |
| RISK-04 | Permissions that exist only on screen expose data | High | Unknown | Audit; server checks on every route before new modules |
| RISK-05 | The move disrupts the 2,000 existing members | High | Medium | Additive changes, feature flags, staged rollout, tested rollback |
| RISK-06 | Hosting and database plan limits constrain growth | Medium | Medium | Review plans early; restore drill |
| RISK-07 | AI features add bias or errors to hiring | High | Medium | Draft-only policy; evaluation sets; audit trail |
| RISK-08 | Scope grows faster than the team | High | High | Fixed release order; exit criteria; feature flags |
| RISK-09 | Private documents (resumes, certificates) are exposed | High | Medium | Private storage, short-lived links, access logging, role tests |
| RISK-10 | Accessibility is untested with real assistive technology | Medium | High | Screen-reader and device checks each release |
| RISK-11 | Lab environments are costly or insecure | High | High | Written scenarios first; pilot small; cost caps |
| RISK-12 | Documents drift from the product | Medium | High | Update this decision register first; review documents with every release |
| RISK-13 | Automated verification produces false approvals, false rejections or inconsistent outcomes | High | Medium | Shadow/limited rollout, representative evaluation, confidence bands, appeal, reviewer fallback, audit and kill switch |
| RISK-14 | Community grows without enough helpful contributors or moderation capacity | High | Medium | Seed contributors, unanswered-question workflow, topic ownership, moderator capacity and contributor-concentration metrics |
| RISK-15 | External component or media libraries introduce incompatible dependencies, weak dark-mode support or licence obligations | Medium | Medium | Repository and licence audit, curated adoption, dependency ownership and token conformance |
| RISK-16 | Matte Black dashboards have insufficient contrast or excessive visual density | Medium | Medium | Validate all token pairs, data series, focus states, density and screen-reader summaries before release |
| RISK-17 | Embedded third-party media or uploaded files introduce malicious content, unsafe iframe behaviour, SSRF, privacy leakage or tracking | High | Medium | Provider allow-list, server-side URL validation, CSP, sandboxed preview/processing, malware scanning, MIME/signature checks, signed URLs and consent controls |
| RISK-18 | Player/provider/browser/codec differences cause unreliable playback or inaccessible recordings | Medium | Medium | Playback matrix, native fallback, captions/transcripts, provider fallback and error recovery tests |
| RISK-19 | Office-viewer licence terms conflict with PacketPulse SaaS/commercial model | High | Medium | Do not adopt AGPL service without legal review; compare conversion and commercial licensing options |
| RISK-20 | Nested screens lose parent context, query state, focus or browser history | Medium | Medium | Route-driven navigation, state restoration and keyboard/focus tests |
| RISK-21 | Decorative pattern/motion layers reduce legibility, performance or accessibility | Medium | Medium | Independent overlays, opacity/theme variants, reduced-motion, contrast and mobile-performance review |


## 12. Change log

| Date | Version | Change |
| --- | --- | --- |
| 26 Nov 2026 | Set 5.5 | Owner reaffirmed open-ended design exploration; clarified that current brand motifs are transparent overlays only and existing backgrounds remain unchanged; restored original REF-00..REF-06 source naming |
| 9 Oct 2026 | Handover 1.0 | Design and development handover issued |
| 13 to 15 Oct 2026 | Prototype 1.0 to 1.8 | Reference build, palette review, recruitment blue, evidence and lab review, decisions on fees, onboarding, visibility and security |
| 16 Oct 2026 | Suite 1.0 and 1.1 | Six documents A to F created; stack recorded; contradictions logged; developer-level questions added |
| 17 Oct 2026 | Set 4.0 | Five canonical documents replace six legacy documents; stack fixed (DEC-032); code-level detail removed; every open question has a recommended answer; PRD-050 to PRD-054 and OPEN-19 to OPEN-21 added; the two developer questions about framework version and where authorization runs moved to Document 4 (DEV-01, DEV-02) |
| 26 Nov 2026 | Set 5.4 | Reaffirmed open creative direction; added multi-colour/pantone exploration and transparent overlay clarification; expanded waveform and media pattern notes |
| 26 Nov 2026 | Set 5.3 | Expanded creative colour/pattern freedom; added media, recordings, nested UX and provider/file safety requirements; added DEC-054 to DEC-061; clarified Approved Prototype treatment and media security gates |
| 26 Nov 2026 | Set 5.2 | Added PRD-077 to PRD-084 for recording playback, document/file preview, resumable uploads, safe embeds, nested UX, reusable pattern overlays and open colour exploration; added DEC-054 to DEC-061 and media/security risks; broadened creative direction beyond green-only motifs |
| 25 Nov 2026 | Set 5.1 | Approved Prototype disposition for all previously open-for-approval product/design items; added Resources requirements PRD-066 to PRD-070; added signup/onboarding/profile/account requirements PRD-071 to PRD-076; added DEC-048 to DEC-053; confirmed creative experimentation authority |
| 24 Nov 2026 | Set 5.0 | Signal Grove refined into Editorial and Analytical workspace families; Matte Black dashboard direction; whitespace/emotional UX; open-source component and media ecosystem; Tailwind v4 delivery rule; microanimation language; Community knowledge-network expansion; automated skill-verification experiments retained under feature flags and review windows; new requirements PRD-055 to PRD-065 |

## 13. Related documents

Document 2: Design System and UX Guide. Document 3: Users, Screens and Page Flows. Document 4: Delivery Plan and Developer Handoff.


### Owner clarification: design freedom is intentional (26 Nov 2026)

Do not turn the design system into a rigid visual rulebook. Keep the system coherent through shared principles, tokens, components and accessibility checks, while allowing the team to explore new compositions, colours, Pantone-referenced studies, gradient combinations, display typography, waves, pulses, networking/security motifs, microinteractions and new component patterns. The current brand-pattern request is specifically for reusable transparent overlays; it does not ask to repaint existing page/card backgrounds. Pattern families are examples and can expand or be replaced as the product evolves.

### Design exploration policy (owner-confirmed, 26 Nov 2026)

Signal Grove creates continuity, not aesthetic boundaries. Designers and developers are encouraged to explore and improve the complete experience: new colourways, gradients, Pantone-referenced studies, typography, layout compositions, component patterns, waves, pulses, network/security motifs and microinteractions. Use examples as inspiration rather than fixed prescriptions. For the current pattern exercise, create transparent reusable overlays without changing existing backgrounds. Keep accessibility, semantic clarity, privacy, security, performance and licensing safeguards intact. Approved Prototype means include the experiment for review; team feedback determines the next-build disposition.

## 14. Recent discussion coverage (24–26 November 2026)

This revision consolidates the current PacketPulse project discussion and the review-build/document files available in the active workspace, including the 25 November Resources and Identity discussion and the current 26 November media, nested-navigation and brand-pattern discussion. No independent transcript/export for other separate chats in the 24–26 November window was available in this workspace. Do not infer or fabricate decisions from inaccessible conversations; append them later if their transcripts are supplied. Older project decisions remain in this guide as the existing product baseline, not as new discussions from this three-day window.

---

# Consolidated project update — 27 November 2026 (current authority)

## Product-wide experience principle

PacketPulse should be designed around the lived context and task of the person using it—not to impress an observer. Begin with the user's goal, uncertainty, emotional friction, trust needs, information and next action. Reduce cognitive burden, preserve autonomy, show meaningful evidence and progress, protect dignity and belonging, and avoid manipulative retention, false urgency, shame, fabricated status or unsupported certainty. This is an owner-confirmed direction and applies across product modules, screens, content, interactions and measurement.

## Product scope continuity

The platform remains a connected engineering community and career product: Community and knowledge contribution; Learn and resources; Practice/labs; Assessments; evidence-based Verification; member identity/profile; Jobs and Recruitment; Payments; notifications; and governed Operations/Admin. The product loop remains **Learn → Practice → Prove → Verify → Connect → Get hired → Grow**. Community contribution/reputation, self-declared skills, assessment evidence, verified skills, certifications and employment evidence are distinct concepts and must never be conflated.

## Notion product notes consolidated

- Product Guide v5.5 (26 Nov) is the source for requirements, goals, module inventory, release hypotheses, approved prototype defaults, risk/decision registers and product vocabulary.
- The Notion Product Guide companion records the product loop, evidence-before-label, governed automation, privacy/consent, shared account/skill/permission foundations and meaningful contribution—not activity volume. It is a structured summary, not a verbatim copy of the canonical source.
- Required Product Components & Capability Inventory is a living cross-product checklist, not an implementation audit. Each capability must be checked against repository evidence before being labelled implemented.
- Product measurement is to establish baselines first. Do not set retention or conversion targets without instrumentation definitions and guardrails; never optimize raw activity at the expense of helpfulness, trust or user autonomy.

## Project governance and approval boundary

“Approved Prototype” means include for review, followed by Retain / Refine / Restrict / Remove disposition. It does not mean production, legal, security, policy, provider or implementation approval. Hiring, payment, verification and sensitive account decisions require their stated human-review, audit, appeal, policy and release controls.

## Product identity

**PacketPulse — Connect, Learn & Grow Together.** The community is a technical knowledge network and a durable reason to return, not merely a jobs portal. Helpful questions, production incidents, expert discussions, case studies, resources, groups, events and mentoring connect to learning, practice and evidence.

## Notion references

- Product Guide v5.5 (26 Nov 2026): https://app.notion.com/p/424520a4e11381298e1bc37f1430bb11
- Required Product Components & Capability Inventory: https://app.notion.com/p/425520a4e11381039756de0a666184cd
- Decision Register & Governance: https://app.notion.com/p/424520a4e1138155bb1df7973fac71db
- Master Change Log & Discussion Lineage: https://app.notion.com/p/424520a4e1138147aa2fcdb127c5f274
- Documentation & Project Memory / quick navigation: https://app.notion.com/p/424520a4e1138113b48ce4e37596a2ef


## Community Strategy & Operations — Notion synthesis

PacketPulse's enduring purpose is practical networking knowledge made accessible and useful: a trusted place to learn, practise, share and connect professionally. The community audience spans CCNA/CCNP learners; freshers and early-career NOC, Network Support, SD-WAN and Network Engineer candidates; working engineers in firewall, cloud networking, security, automation and troubleshooting; and relevant recruiters/organisations.

**Operational content principles:** practical value before promotion; technical accuracy before publishing; distinguish concept, lab exercise and production experience; protect member privacy; no placement guarantees or exaggerated career claims. The content workflow is problem/audience → learning outcome → technical validation → draft/example → diagram only when helpful → terminology/security review → publish with level/topic tags → archive and maintain.

**Learning/resource taxonomy (historical community strategy):** Ethernet, switching, VLANs, trunking, routing, ACL/STP; static routing, OSPF, BGP, MPLS, VPN and SD-WAN; firewall, NAT, VPN and security operations; Cisco IOS/IOS-XE/NX-OS, PAN-OS, FortiGate and Linux; troubleshooting, packet capture, monitoring, documentation and change management.

**Lab note—historical, verify before reuse:** CCNA VLAN/inter-VLAN lab learning and a Palo Alto/Panorama weekday 8:30 PM initiative were recorded. Old cost notes were ~₹2,000/month server rent and ~₹2,000 one-time licenses. These are stale planning figures, not current prices or a current session commitment; confirm availability, licenses, schedule, support and costs before announcement.

**Opportunity-sharing workflow:** verify source/employer/recruiter and application route; confirm title, skills, experience, location, work mode, role type and deadline; remove unnecessary personal data; publish source and application instructions; correct/close stale listings. Never imply an admin is applying or promise interview/placement outcomes.

Ideas in the community strategy—assessments, skill-verified badges, labs/catalogue, recruiter workflows and member profile—are future directions unless separately approved and implemented. A personal finance/planning module was recorded as an idea only, not confirmed scope. Community measures should reflect returning participation, maintained resources, lab attendance/completion, questions resolved, verified opportunities and meaningful follow-up—not raw member count alone. The 1,740+ member figure recorded on 8 Sep 2026 is historical, not live.

Notion source: PacketPulse — Community Strategy & Operations (Git-captured Notion export; last updated 26 Nov 2026).


# Appendix — Canonical source changelog and prototype-review register

# PacketPulse 2.0 — Change Log

**Update set:** 5.7 — Open Creative Direction, Pattern Overlay Clarification and Source-Reference Alignment
**Issued:** 26 November 2026
**Supersedes:** Update set 5.6 for the current review-build handoff.

## 26 November 2026 — Update set 5.7

### Owner direction: design remains open and experimental

- Do not turn design guidance into a rigid aesthetic rulebook. Treat sample colours, named pattern families, libraries, component styles, layouts and motion recipes as starting points.
- Explore the full Signal Grove, module and semantic token system; green is not compulsory. New hue combinations, gradients, tonal treatments and Pantone-referenced studies are welcome where useful.
- Waves and pulses are explicitly included in the expandable brand-pattern vocabulary.
- Preserve existing page/card backgrounds for the current pattern exercise. Build optional transparent overlays that can be recoloured, cropped, scaled, animated or omitted.
- Keep product-quality checks—accessibility, readability, responsive behaviour, security, privacy, performance and licensing—while remaining creative about aesthetics.

### Documentation and reference corrections

- Re-aligned owner-supplied visual reference files and IDs to the original Nov 25 bundle: REF-00 through REF-06.
- Updated all five canonical documents to v5.5 / v4.5 / v3.6 / v4.6 / v1.7.
- Added a separate 26 Nov discussion record for open creative direction and pattern overlays.
- Added the latest owner clarification to the media/nested UX discussion record and Claude handoff.
- Preserved the Video.js 10 + Uppy/Tus + React-PDF media direction and optional WaveSurfer audio treatment; repository, compatibility, licence and security checks still precede package installation.

### Canonical document versions

| Document | Previous | New |
|---|---:|---:|
| 1. Product Guide | v5.4 | **v5.5** |
| 2. Design System and UX Guide | v4.4 | **v4.5** |
| 3. Users, Screens and Page Flows | v3.5 | **v3.6** |
| 4. Delivery Plan and Developer Handoff | v4.5 | **v4.6** |
| 5. Component Ecosystem, UI Patterns and Library Registry | v1.6 | **v1.7** |

---

## 26 November 2026 — Update set 5.6

### Owner clarification: creative freedom is intentional

Design guidance is not a rigid visual rulebook. Keep coherence through shared principles, tokens, reusable components, accessibility and product intent, while openly exploring new compositions, colours, gradients, Pantone-referenced studies, typography, waves, pulses, packet/network/security motifs, patterns and motion. Use the pattern families as a starting vocabulary, not an exhaustive or mandatory list. The present pattern work is specifically for transparent overlays; preserve existing page/card backgrounds.

### Media and nested experience refinements

- Video.js 10 (`@videojs/react`, 10.7.0 researched on 26 Nov) remains the preferred general React video/audio player candidate; validate current package, adapters and compatibility at implementation.
- WaveSurfer.js 8.1.0 (BSD-3-Clause) is an optional audio waveform/timeline layer, not the general player. Use pre-decoded peaks for large/streamed recordings and keep ordinary audio controls available.
- Uppy headless/hooks + Tus remains the preferred resumable upload candidate; React-PDF/PDF.js for PDF; isolated conversion or separately licensed viewer for Office files; safe provider-specific embedded playback.
- Expand parent/child routes, contextual drawers, split/master-detail and mobile child views based on the task; retain route, scroll, selection and focus context where possible.
- Brand patterns use the wider Signal Grove and experimental palette; Forest is an option, not a compulsory colour. Pantone references are not invented; verify any selected official swatch and digital conversion.

### Canonical document versions

| Document | Previous | New |
|---|---:|---:|
| 1. Product Guide | v5.3 | **v5.4** |
| 2. Design System and UX Guide | v4.3 | **v4.4** |
| 3. Users, Screens and Page Flows | v3.4 | **v3.5** |
| 4. Delivery Plan and Developer Handoff | v4.4 | **v4.5** |
| 5. Component Ecosystem, UI Patterns and Library Registry | v1.5 | **v1.6** |

## 26 November 2026 — Update set 5.5

### Owner direction: open, creative and experimental

The owner clarified that design guidance should not become rigid rules. Explore beyond the listed colours, components, patterns and motion ideas. Existing backgrounds stay unchanged unless separately redesigned; motifs are optional transparent overlays. The palette includes brand/module tokens plus experimental accents, gradients and Pantone references.

- Design principles are flexible guidance, not rigid aesthetic constraints.
- Explore the full Signal Grove token palette, module colours, semantic colours, gradients, Pantone references, new combinations, typography, composition and motion where useful.
- Preserve existing backgrounds. The brand-pattern system is an independent transparent overlay layer; it does not repaint surfaces.
- Pattern families are a starting vocabulary, not exhaustive: packet routes, node constellations, signal waves, pulse trails, radar echoes, secure layers, data flows and packet matrices.

### Media and recordings architecture

- Preferred React video/audio player candidate: Video.js 10 (`@videojs/react`), researched at 10.7.0 on 26 Nov 2026; v10 GA on 1 Oct 2026.
- Shaka Player is a specialist alternative for needs that specifically require its advanced adaptive/offline/EME capabilities, not a second default player.
- Preferred upload layer: Uppy React headless/hooks; Tus resumable transport where supported.
- Preferred PDF viewer: React-PDF/PDF.js. Office file preview requires isolated conversion or a separately licensed service; ONLYOFFICE Community AGPLv3 implications must be assessed.
- FFmpeg may be evaluated for server-side metadata/thumbnails/transcoding; build flags, codecs, LGPL/GPL and patent implications require review.
- External embeds are provider-allow-listed, canonicalised and governed by CSP, sandbox/permissions, origin checks and SSRF controls.

- Restored Resource/Identity API IDs 061–068 and their data entities in the developer handoff; media APIs now use 069–077 so the registries no longer collide.
- Added optional WaveSurfer.js audio waveform layer with bounded/pre-decoded peaks and a familiar audio-control fallback.

### Parent-child and nested UX

- Added shared route/context patterns for parent pages, child routes, route-backed drawers, inline expansion and mobile full-screen child flows.
- Preserve URL, browser history, breadcrumbs/back path, filters, selection, scroll and focus where feasible.
- Avoid modal stacks and context loss.

### Documentation versions

| Document | Previous | New |
|---|---:|---:|
| 1. Product Guide | v5.2 | **v5.3** | PRD-077 to PRD-084; DEC-054 to DEC-061; media/security risks; flexible creative direction |
| 2. Design System and UX Guide | v4.2 | **v4.3** | Flexible principles; pattern overlays; expanded colour exploration; nested UX and media design |
| 3. Users, Screens and Page Flows | v3.3 | **v3.4** | Corrected API mapping for Resources/Identity; added media/nested traceability and optional audio waveform workflow |
| 4. Delivery Plan and Developer Handoff | v4.2 | **v4.4** | Restored DB-041 to DB-050 and API-061 to API-068; added DB-051 to DB-056, API-069 to API-077, WaveSurfer, TASK-081 and TEST-084 |
| 5. Component Ecosystem, UI Patterns and Library Registry | v1.3 | **v1.5** | Open creative design guidance, media stack including optional WaveSurfer, nested components and eight expandable pattern families |

### New files and assets

- `PacketPulse 2.0 — Discussion Record — Media, Nested UX and Brand Patterns — 26 November 2026.md`
- `APPROVED_PROTOTYPE_REVIEW_REGISTER.md`
- `references/brand-patterns/` — eight transparent SVG starter motifs
- `references/design-inspiration/` — existing design concepts retained
- `TECHNICAL_SOURCE_REGISTER.md` — current official source links and research notes
- `PacketPulse_2.0_Design_Color_System_v3.pdf` and `PacketPulse_2.0_Media_Nested_UX_and_Brand_Pattern_Reference_v2.pdf` — refreshed visual and technical reference guides

## Recent-chat coverage window

The requested scan window is 24–26 November 2026. This package uses the current PacketPulse project conversation and the 24–25 November project files present in the active workspace. Separate transcripts for other independent chats in this date window were not available in the workspace; their content has not been fabricated or inferred. Add them in a later update if supplied.

## Status policy

| Status | Meaning |
|---|---|
| Approved Prototype | Owner-approved for inclusion in the next review build; reversible after team review |
| In Prototype | Being assembled as a reviewable experience |
| Ready for Review | Core flow/states represented and awaiting evaluation |
| Retain / Refine / Restrict / Remove | Team disposition for the next build |
| Production Approved | Separate go-live approval after technical, legal, security, accessibility and operational gates |
| Implemented | Present in repository and verified against acceptance tests; documentation alone never grants it |
| Discovery Required | A factual technical/vendor/legal detail still needs evidence; use safe mock/sandbox states meanwhile |

## Related files

- Documents 1–5 (canonical updated references)
- Discussion Record — Resources and Identity Experiences (25 Nov 2026)
- Discussion Record — Media, Nested UX and Brand Patterns (26 Nov 2026)
- Discussion Record — Visual Inspiration and Component Ecosystem (25 Nov 2026)
- Claude handoffs, review register, technical source register, references and SVG patterns


# Approved Prototype Review Register — 26 November 2026

**Build:** PacketPulse 2.0 Review Build 5.7  
**Owner direction:** Open, creative and experimental. Approved Prototype means include in the review build, then evaluate. It does not mean production approved.

| Area | Review-build scope | Primary review question | Next-build decision |
|---|---|---|---|
| Resources | Library, detail/reader, share wizard, saved collections, moderation | Can members find, trust, contribute and reuse resources? | Retain / Refine / Restrict / Remove |
| Signup/onboarding | Signup, email verification, provider sign-in prototype, Role → Interests → Goals | Is signup welcoming, clear and low-friction? | Retain / Refine / Restrict / Remove |
| Profile and identity | Profile, verification-aware skills, contributions, visibility preview, optional completeness/timeline | Does identity feel useful and privacy-safe rather than like a forced CV? | Retain / Refine / Restrict / Remove |
| Account control | Personal info, visibility, notifications, security, sessions, connections, privacy/data rights, billing where applicable | Can users find and complete account tasks safely? | Retain / Refine / Restrict / Remove |
| Recordings/media | Video.js 10 player, captions/transcript/chapters, embedded providers, resume progress, optional WaveSurfer audio waveform | Does media work reliably and feel native to PacketPulse? | Retain / Refine / Restrict / Remove |
| File preview/upload | React-PDF/PDF.js, supported file preview, Uppy/Tus path, upload lifecycle | Are large files and interrupted uploads recoverable and safe? | Retain / Refine / Restrict / Remove |
| Nested workflows | Parent/child routes, contextual drawers, mobile child pages, state restoration | Do users maintain orientation and context? | Retain / Refine / Restrict / Remove |
| Brand patterns | Transparent packet/node/wave/pulse/radar/security/data motifs; broad palette variants and new family experiments | Do patterns improve recognisability and emotion without competing with content? | Retain / Refine / Restrict / Remove |
| Creative colour / pattern studies | Token shades, module accents, gradients, Pantone-referenced explorations and new motif colourways | Which combinations improve character, clarity, and mood? | Retain / Refine / Restrict / Remove |
| Audio waveform | Optional WaveSurfer.js waveform, timeline, regions and transcript jumps | Does a waveform help the audio use case more than a conventional player? | Retain / Refine / Restrict / Remove |
| Open creative pattern exploration | Expandable packet/network/security motifs, waves/pulses, full-token colour explorations and transparent overlays; do not change existing backgrounds | Do the patterns feel distinctive, adaptable and non-intrusive? | Retain / Refine / Restrict / Remove |
| Creative visual experiments | Layout, cards, typography, broad colour combinations, gradients, transparent motifs, wave/pulse treatments, motion and Pantone exploration | Which variants improve usability, vibe and distinctiveness? | Retain / Refine / Restrict / Remove |

## Production gates (separate from prototype approval)

- Repository, dependency, version and licence audit.
- Media provider and storage configuration; browser/codec/device test matrix.
- Server-side permission checks, signed URLs, upload scanning, embed allow-list, CSP and SSRF protection.
- Contrast, keyboard, screen-reader, reduced-motion and mobile review.
- Legal review for AGPL/commercial editor options, FFmpeg builds/codecs, provider terms and asset licences.
- Explicit production release approval.

## Review notes template

For each experiment record: user/task; variant; hypothesis; screenshots/recording; what worked; what confused users; accessibility/performance/security findings; quantitative evidence where available; team/member feedback; decision (Retain / Refine / Restrict / Remove); owner; next build.

| Pattern and colour exploration | New waves, pulses, packet/node/security motifs, token combinations and Pantone-referenced studies as optional transparent overlays; existing backgrounds stay intact | Does the pattern add character without competing with content? | Retain / Refine / Restrict / Remove |


Owner design clarification (26 Nov): Be creative and experimental; use the wider token palette and explore new colourways. Waves and pulses are welcome. For the current pattern work, keep existing backgrounds unchanged and use optional transparent overlays.


## Latest owner clarification

The list of pattern families and colourways is not exhaustive. Explore broad Signal Grove, module, semantic and experimental colour combinations, waves, pulses and new visual motifs. For the current pattern exercise, use transparent overlays only and preserve the existing page/card background. All explorations remain Approved Prototype and are reviewed before the next build.


# Consolidation provenance, source precedence and integrity

## Primary source packages and version lineage (24 Nov baseline; later updates reconciled)

- `PacketPulse_2.0_Update_2026-11-24.zip` (preserved in Git history; user-identified attached baseline) — four core guides, change/update summaries, Claude handoff, colour-system PDF and references.
- `PacketPulse_2.0_Approved_Prototype_Review_Build_2026-11-26.zip` — current 26 Nov canonical five-doc suite, changelog, update summary, review register, technical source register, Claude handoffs, discussion records and reference assets.
- `PacketPulse_2.0_Discussion_2026-11-25.zip` — prior discussion update set and design/component source context.
- `PacketPulse_2.0_Recovery_Pages_Design_System_Package.zip` — recovery pages and earlier design-system history.
- `PacketPulse_2.0_Team_Documentation_v1.3_2026-10-24.zip` — immutable earlier team documentation and design assets.
- `PacketPulse_Visual_Identity_Foundation_v1.0.zip` and `PacketPulse_Visual_Identity_Exploration_v0.1.zip` — identity explorations and owner-approved foundation artifact.
- `SCR-003_Frontend_Implementation_Starter.zip` — separate screen implementation starter; not integrated into the application repository by this documentation rebuild.

## User-identified source baseline — 24 November 2026

The owner noted that the attached source files represent the 24 Nov update set. Git history preserves this as `history/releases/2026-11-24-update-set/PacketPulse_2.0_Update_2026-11-24/`, including the four core guides, `CHANGELOG.md`, `UPDATE_SUMMARY.md`, `CLAUDE_UPDATE_HANDOFF.md`, the design colour-system PDF and its reference asset. The 24 Nov baseline is retained as historical source—not treated as the latest state.

## Later source sets reconciled

- 25 Nov discussion and review-build packages (discussion records, expanded core guides and component ecosystem).
- 26 Nov Approved Prototype Review Build (canonical five-document set, changelog, review register, technical source register, component additions, handoffs and visual/reference assets).
- 27 Nov owner decisions and Notion notes (user-psychology-first design; finalized Violet-led foundation; Claude token/logo delegation; SCR-004 and SCR-005 screen specifications; capability inventory and updated change lineage).

## Git repository snapshot inspected

- Repository: `kartik-binzade/packetpulse-community-2.0` (public documentation/history companion repository; not established as the live application source repository).
- Branch: `main`.
- Observed HEAD commit: `cca0a25576d65a9da2892c2f676a3efe9df481ec`.
- Commit message: `PacketPulse-Notion-Docs-latest(27Nov.7Pm)`; commit timestamp in Git metadata: `2026-11-27T14:21:04Z`.
- Tree includes `PacketPulse_Documentation_History/`, immutable `history/releases/` and `history/source-packages/`, `Notion's Doc/PacketPulse-Notion-Docs-latest(27Nov.7Pm)/`, governance, current documents, approved identity assets, token CSS, brand patterns, SCR-003 screen spec and a separate SCR-003 implementation starter.
- Git tree includes the 24 Nov update archive and later 25/26 Nov source packages. Latest Notion companion export includes Product Guide v5.5, Design System & UX Guide updated 27 Nov 7:41 PM (Notion metadata), Master Change Log/Decision Register, capability inventory, SCR-004 and SCR-005.
- The Git repository is a documentation/archive workspace and contains prototype/spec assets; this does not prove the production app repo has been inspected, the app integrated, or deployment/test status.
- The README within the history workspace described a standalone docs workspace and an earlier intended push destination; current repository metadata and HEAD above are the observed later state. Do not repeat the old setup instruction as current without owner confirmation.

## Notion pages consulted / cross-checked

Documentation & Project Memory; Product Guide v5.5; Design System & UX Guide (27 Nov); Users, Screens & Page Flows; Delivery Plan & Developer Handoff; Component Ecosystem & Library Registry; Decision Register & Governance; Master Change Log & Discussion Lineage; Source Index & Archive Manifest; Design Token & Theme History; Brand & Visual Design System; Required Product Components & Capability Inventory; SCR-003, SCR-004 and SCR-005 screen specifications; SCR-003 engineering handoff; 26 Nov Discussion Handoff. Notion companion pages explicitly identify themselves as structured summaries/navigation rather than verbatim imports.

## Source limitations

- Notion canonical companion pages are not full verbatim copies of all source documents. This rebuild uses the complete local Markdown source set for the 26 Nov review build and the available Notion page content/notes for later updates.
- Some Notion pages or discussion summaries may have been updated after the 26 Nov source ZIP; only specific retrieved current notes are merged. Unknown content is not inferred.
- The 205-file documentation-history archive referenced by Notion is a prior archive manifest; this four-file output is a new consolidated release, not a replacement or reconstruction of every archived binary.
- The application repository was not inspected as part of this document-generation task. No implementation, test, deployment or Git publish status is upgraded by these documents.

## Status vocabulary and versioning

Confirmed / Planned / Proposed / Approved Prototype / Production Approved / Open / Discovery / Historical / Delegated / Repository validation pending retain their source meanings. Never treat a prototype as production approval. New owner decisions supersede current guidance; historical source files stay immutable and are linked, not silently rewritten.
