# PacketPulse 2.0 — Design System, UX, Brand & Component Ecosystem

**Consolidated release:** v7.0 · 27 November 2026  
**Source baseline:** Owner-supplied project documentation set dated 24 November 2026, reconciled against later 25–26 November source packages, Notion exports/records and Git main snapshot through 27 November 2026.  
**Document status:** Product/design specification and project handoff. Not evidence of production implementation, legal approval or repository validation.  
**Source precedence:** Current owner-approved decisions and dated Notion decision/change records supersede earlier proposal or historical token values. Dated releases remain immutable; see the source/lineage section at the end.  
**Working agreement:** Product behavior, user flows, edge cases, acceptance criteria and quality standards are defined here. Claude audits and implements in the actual application repository. Do not invent repository paths, replace working services, or claim tests/deployment without evidence.

**Current owner direction (27 Nov):** User-context-first design, ethical psychology, accessible and truthful UX. The approved visual foundation is Violet-led Palette 1 (`#615AB9`, `#16133E`, `#8B7FF7`, `#F1F5F9`) complemented by Forest `#156152`, Signal Lime `#C7FE53`, Soft Forest `#8BBBA5`, and balanced black/white neutrals. Detailed operational tokens, shade/state refinement within this foundation, scoped Payments blue and reusable logo completion are delegated to Claude; the foundation and product-policy boundary are fixed unless the owner changes them.

**Reading note:** The complete 26 Nov canonical source text is retained below for traceability and detail. The 24 Nov source set is the historical baseline you identified; later dated records supersede it only where explicitly approved. Its dated palette/token proposals and other historical states are not silently promoted; use this 27 Nov authority block and the explicit current-decision addenda for present-day decisions.

Version 4.5 · 26 November 2026 · Owner: design lead (to be named) · Supersedes the 17 October 2026 Design System and UX Guide v3.0. Decisions are cited as DEC, CON, OPEN in Document 1; screens and flows are in Document 3; build tasks are in Document 4. **[APPROVED PROTOTYPE]** marks owner-approved direction for the next review build; it is not final production approval. PV means built and tested in the reference prototype only. This revision introduces owner-directed visual changes plus recommended libraries; dependency choices remain subject to the repository audit.

## 1. Philosophy and UX rules

The design system is a living design language: it creates coherence while leaving room for discovery. Principles are useful starting points and shared quality checks, not hard walls. Teams may depart from a pattern when a better experience emerges; capture the intent, test the result and share what was learned. IDs help with traceability, not to police creativity. The principles below are prompts and quality checks, not hard aesthetic constraints. Designers may propose a better route, combine patterns, experiment with wider palettes or invent new component families; record the reason and review the result.

**Owner clarification — open creative direction (26 November 2026):** Do not treat this guide as a rigid visual rulebook. Signal Grove provides continuity, not an aesthetic ceiling. The listed palettes, patterns, components, layout archetypes and motion recipes are examples, not an exhaustive list. Explore new compositions, combinations, gradients, type, waves, pulses, network/security motifs and interaction patterns where they improve the product. Distinguish essential experience and safety checks (accessibility, readable contrast, semantic states, privacy, security, licensing and performance) from flexible aesthetic preferences. For the current brand-pattern work, create optional transparent overlays and keep existing page/card backgrounds unchanged.


| ID | Rule | Consequence |
| --- | --- | --- |
| DES-001 | A polished screen is not a usable flow. Every flow defines its entry, next step, recovery path, and its empty and error states before visual polish | No screen ships without loading, empty, error and success states |
| DES-002 | Principles are adaptable guidance. Explore beyond the default when it improves the experience; explain and evaluate meaningful departures | Fewer late debates |
| DES-003 | Automation is explainable and governed. AI outputs are labelled; automated skill-verification experiments may decide under a versioned policy, explicit evidence rules, thresholds, audit, appeal/re-review, feature flags and human fallback. Recruitment, payment and sensitive account decisions remain human-confirmed by default | No opaque or unreviewable automated decisions; no extension to hiring or money without a separate DEC |
| DES-004 | Accessibility is a speed feature. Contrast, keyboard flow and clear labels reduce errors for everyone | WCAG 2.2 AA is the release bar |
| DES-005 | Coherence scales through shared tokens and components, while bespoke compositions remain welcome when they solve a real design problem | A new screen is built from existing parts first |
| DES-006 | Light and dark themes are both designed and tested (DEC-003) | Dark is not an inversion of light |
| DES-007 | Semantic status colours carry meaning and must include text/glyphs; expressive brand colours and decorative pattern colourways are also welcome when they remain legible and do not impersonate status | No color-only states |
| DES-008 | Make the action hierarchy easy to read. A clear leading action is often helpful, but use the number and weight of actions that fit the real task | Users can see their options without being artificially constrained |
| DES-009 | Always show where the user is, what changed, and what to do next | No dead ends; every empty state offers an action |
| DES-010 | Plain language, short sentences, no jargon for its own sake | Fewer support questions |
| DES-011 | Ask for information only when it is needed, and say why for sensitive fields | Higher completion, more trust |
| DES-012 | Work is recoverable: save and resume, warn before losing changes, confirm destructive actions by naming their effect | Fewer abandoned flows |
| DES-013 | Whitespace is intentional. Use visual rhythm, readable line lengths and generous separation; density is chosen by task, not by screen size alone | Calm hierarchy and lower perceived effort |
| DES-014 | Design for emotional quality: calm, capable, welcoming, credible and quietly rewarding; avoid manipulative urgency and decoration that undermines the task; expressive visual moments are welcome when they add value | Users should feel oriented and confident, not pressured |
| DES-015 | Start with Editorial and Analytical workspace archetypes, but evolve or combine layouts when the content and user journey call for it | Different tasks receive the right information architecture |
| DES-016 | Matte Black Edition is a preferred reference for analytics-heavy workspaces, not a required treatment or a forced global theme | Strong analytical focus while preserving user choice |
| DES-017 | Motion must communicate feedback, orientation or state change; decorative motion is optional and reduced-motion behavior is mandatory | Interfaces feel responsive without distraction |
| DES-018 | Build from a curated component ecosystem and PacketPulse-owned wrappers; external library styles never define brand identity | Faster delivery with consistent product character |
| DES-019 | Media assets follow visual, accessibility, performance and licensing rules; do not use imagery merely to fill space | Coherent and trustworthy visual language |
| DES-020 | Components support Comfortable, Compact or Reading density where the task warrants it; Comfortable is the default | Control information density without sacrificing whitespace |
| DES-021 | Analytical dashboards often benefit from a few meaningful metrics, a strong analysis area and a contextual rail; composition can vary by task and user | Better scan paths and usable data workspaces |
| DES-022 | Creative exploration is part of the system: adapt, combine or invent visual patterns, layouts, typography, colourways and interactions when they improve the experience | A recognisable product can still feel fresh and expressive |
| DES-023 | Colour is a flexible design material. Explore the full token palette, module accents, semantic colours, tonal ramps, gradients and new combinations; use semantic meanings as guidance, not as a limit on decorative colour | More expressive yet coherent product experiences |
| DES-024 | Brand motifs are independent visual layers. Pattern overlays should work with existing surfaces and may be removed, recoloured, cropped or combined without changing the underlying page/card background | Reusable identity without forcing a new surface treatment |
| DES-025 | Pattern and motion families are open-ended. Waves, pulses, packet paths, nodes, radar, security geometry and future motifs may evolve with product needs | Distinctive visual language that can grow with the product |
| DES-026 | Parent/child and nested experiences preserve orientation and user context across routes, drawers, sheets, tabs and inline details; choose the composition that best fits the task and viewport | Fewer dead ends and less context loss |
| DES-027 | Media and recordings are first-class content. Select appropriate players/viewers for video, audio, documents and embedded providers; design captions, transcripts, chapters, resume and recovery as part of the experience | Accessible, integrated resource consumption |
| DES-028 | External component libraries are sources of ideas and implementation building blocks, not authorities over the PacketPulse visual language; curate, adapt, replace or create components as evidence suggests | Better quality without library-driven sameness |
| DES-029 | Design experiments are reviewable. Approved Prototype means the experience belongs in the review build; capture feedback and decide Retain, Refine, Restrict or Remove for the next build | Creative work can be evaluated and improved deliberately |
| DES-030 | Design assets and component sources remain traceable without constraining the design: record origin, version, licence, owner and adaptations; review new sources as the ecosystem evolves | Reuse stays responsible and maintainable |
| DES-031 | The design language is deliberately open-ended. Treat examples, tokens, pattern families, library choices, layout archetypes and motion recipes as starting points; invent or evolve them when it improves the experience. Current brand-pattern work remains optional transparent overlays that preserve existing backgrounds | A coherent system that continues to evolve rather than hardening into a visual rulebook |

## 2. Color psychology applied

| UX principle | Implementation | Why it helps | Status |
| --- | --- | --- | --- |
| Reduce cognitive load | Thoughtful surface hierarchy with enough colour and contrast to support the story | Less visual competition | Confirmed |
| Establish hierarchy | Give important actions clear visual priority; allow the screen to have several peer actions when the workflow calls for them | Choices feel clear without forcing an artificial one-action layout | Confirmed |
| Build trust | Consistent branding, explicit transaction states | Predictable behavior | Confirmed |
| Encourage progress | Visible milestones and progress in the active module's accent | Progress is easy to read | Confirmed; the color is OPEN-01 |
| Prevent mistakes | Amber warnings, red errors, descriptive messages | Important states stand out | Confirmed |
| Improve accessibility | Contrast, icons, labels and text with every status | Works for different visual abilities | Confirmed |

**OPEN-01 — Approved Prototype disposition.** Forest is an established brand option, not a universal mandatory action colour. Explore Forest, Learning Indigo, Recruitment Blue, Payments Plum, cyan, azure, violet, coral, amber and thoughtful multi-colour or gradient treatments in context. A module accent can become the leading action or progress colour when it helps people understand the current task. Keep success/warning/danger/information states legible and distinct from decorative colour. Test the complete screen rather than selecting colours in isolation.

The current module associations are a useful starting language, not a closed colour system. Colour psychology is contextual: test palette, contrast, user expectations, culture, hierarchy and emotional tone together. New colour combinations are welcome when they improve the experience.

## 3. Brand

Name: PacketPulse. Tagline: Connect, Learn & Grow Together. Voice: plain, direct, encouraging, technical without jargon for its own sake, never urgent or manipulative. Use Inter Semibold as the interim product wordmark and UI baseline. Explore logotype and display-font directions in the review build (OPEN-02 / DEC-049); expressive type experiments may appear in marketing, campaign and editorial moments without forcing a wholesale UI-font change. The mark is a lime dot with a forest ring (PV).

## 4. Color system

### 4.1 Tokens (light and dark)

| Token | Light | Dark | Use |
| --- | --- | --- | --- |
| Page background | #F5F8F6 | #001D21 | App background |
| Surface | #FFFFFF | #002631 | Cards, forms, dialogs |
| Surface subtle | #E8F4EF | #0C3437 | Selected rows, active navigation, tints |
| Text primary | #152025 | #F5F8F6 | Headings and body |
| Text secondary | #52615B | #B7C9C2 | Supporting text |
| Border | #DCE5DF | #33514F | Dividers and card outlines (decorative) |
| Control border | #738279 | #7D9A95 | Inputs, switches, checkboxes (3:1 required) |
| Brand / action family | #156152 is an established option; explore compatible token ramps and module-aware action treatments | Adapt to theme and context | Brand actions, selected controls, links and navigation; choose the most legible and emotionally appropriate treatment for the screen |
| Focus ring | #156152 | #96D294 | 3 px outline, 2 px offset as a starting treatment; adapt shape/contrast while keeping focus unmistakable |
| Signal lime | #C7FE53 | #C7FE53 | Expressive highlight, achievement, emphasis or action when it suits the context; pair with accessible foregrounds |
| Deep teal | #001D21, #002631 | same | Dark panels and hero backgrounds |

### 4.2 Module identities

| Module | Light | Dark | Soft background (light, dark) | Role |
| --- | --- | --- | --- | --- |
| Community and brand | #156152 | #96D294 | #E8F4EF, #0C3437 | Welcoming, credible |
| Learning | #635BCA | #B1ACFE | #F0EFFF, #26235A | Focus |
| Recruitment | #1D4F86 (accent #2563A6, deep #163B5C) | #8DB8E8 | #E8F0FA, #12304D | Reliability |
| Payments | #6F2A5F | #E4A8D8 | #F7EBF4, #3A1F36 | Value, care |

Module associations are useful starting points, not fences. A module may lead with its accent, share a gradient, borrow a complementary colourway or use a more expressive surface treatment when that improves the task and brand experience. Preserve clear semantic states and legibility; the shared tokens and interaction language maintain coherence even when a screen explores a bolder visual composition. A whole-page colour treatment is not prohibited by default; judge it by usability, contrast, tone and hierarchy.

### 4.3 Semantic and verification colors

| State | Strong (text) light, dark | Soft background light, dark | Glyph | Meaning |
| --- | --- | --- | --- | --- |
| Success | #176B35, #7FDC98 | #EAF7EE, #0F3A22 | check | Completed, saved, passed, verified |
| Warning or pending | #94620D, #F0C264 | #FFF4D6, #3D3010 | exclamation | Needs attention, in review |
| Danger | #B42332, #FF8A93 | #FEE4E2, #4A1A20 | cross | Failed, invalid, destructive |
| Information | #3D455C, #B4BED6 | #EDF0F5, #252B3A | info | Neutral guidance |

Verification labels: Self declared (neutral), Assessment verified and PP verified (forest), Experience verified (recruitment blue), Certification verified (indigo), Verification pending (amber), unsuccessful (red). Each label has its own wording and a detail view (DEC-013, Document 1 section 10.1).

### 4.4 Quality results

- Every text pair above is at least 4.5:1 (lowest 4.65:1); control borders are 4.04:1 on white and 5.24:1 in dark.
- Under color-blindness simulation two pairs are weak and accepted with a rule: Community green versus Success green, and Community versus Recruitment. Rule: status has text and a glyph; modules also have an icon and a name.
- Plum Payments is clearly distinct from every other module and state color under all four vision types.
- Hero gradients keep text off the pale eucalyptus end (it measured 2.1:1).
- Rule for new colors: two colors that must be told apart need a clear difference under all four vision simulations, or a label or icon with them.

### 4.5 Matte Black Edition (Analytical Workspace)

Matte Black Edition is the preferred visual reference for Operations, Recruitment analytics, Community analytics and other data-heavy dashboards inspired by the supplied Vantage Admin reference. It does not replace Signal Grove, module accents or the light theme.

| Token | Draft value | Use |
| --- | --- | --- |
| Analytics canvas | #0B0D0C | Main dashboard background |
| Analytics surface | #171A18 | KPI panels, tables and work regions |
| Analytics raised | #222724 | Menus, selected panels and raised surfaces |
| Analytics border | #303631 | Subtle structural separators |
| Analytics text | #F2F5F2 | Main text |
| Analytics muted | #A8B2AC | Supporting text; validate small-text contrast |
| Brand action | #156152 | Primary actions; retain semantic text and focus states |
| Signal emphasis | #C7FE53 | Rare emphasis and meaningful milestones; pair with dark text |
| Optional chart series | #A78BFA | Secondary data series only, never a status or brand replacement |

These are starting tokens proposed from the visual reference and prior discussion, not a closed palette or a verified accessibility palette. Explore other token combinations, tonal ramps, accent gradients and complementary hues in the prototype. Matte Black is a visual option for suitable analytical workspaces, not an instruction to use a single accent everywhere. Before production, calculate contrast for every text/control pair, check chart-series distinction in color-vision simulations, and adjust values as needed. Do not assume all muted text is accessible simply because the screen looks high-contrast.

### 4.6 Exploratory colour and Pantone workflow

Signal Grove tokens are a starting vocabulary that creates familiarity across the product. They are not a limit on experimentation. The review build may explore broader colour families, tonal ramps, gradients and multi-hue combinations, for example:

- Grove: forest, eucalyptus, lime and deep teal.
- Aurora: cyan, azure, indigo, violet and cool blue.
- Spectrum: blue, cyan, lime, amber and coral.
- Ember: plum, coral, amber and warm neutral tones.
- Night signal: matte black/ink surfaces with violet, cyan, electric blue or warm accents.
- Editorial colour studies: restrained pastel/tonal combinations, richer saturated accents or monochrome compositions where content and audience call for them.

These are exploratory colour stories, not mandatory module mappings. New combinations are welcome. Select colours for hierarchy, mood, distinction, readability and cultural context; don't force every module, card or brand moment into the same green treatment. Semantic success, warning, danger and information states should remain recognisable in meaning, but decorative artwork can use a much wider palette.

Pantone may be explored as a physical/print colour reference. Do not invent PMS identifiers or claim an exact Pantone match from a HEX value. Record the official swatch/reference and licensing source if a Pantone reference is adopted, then document the actual digital HEX/RGB/CMYK conversion used for screens or print. Treat Pantone-inspired digital colour exploration as a concept until the official reference is verified.

For brand patterns, use transparent overlays and CSS/SVG variables. The current pattern exercise does not change existing page/card backgrounds. Test the overlay on multiple light, dark and Matte Black surfaces, then keep, adapt or omit it based on readability and composition.

## 5. Typography

| Role | Value |
| --- | --- |
| UI and body | Inter, with Noto Sans Devanagari for Hindi, then system fonts |
| Technical text and numbers | JetBrains Mono, sparingly (counts, IDs, code, ledger values) |
| Body | 16 px / 24 px, weight 400 |
| Small | 14 px / 20 px |
| Section heading | 24 px / 32 px, weight 600 |
| Card heading | 17 px / 24 px, weight 600 |
| Page heading | 30 to 48 px, weight 700, fluid |
| Metric value | JetBrains Mono, 30 px / 36 px, weight 600 |

Use sentence case, tabular numerals for money and counts, and balanced wrapping for headings. Avoid all caps and light weights for small text. Reading lines around 60–75 characters are a useful starting point, adjusted for content, device and typography. Hindi text benefits from generous line-height (around 1.6 as a starting point). Display typefaces may be explored for expressive moments while the dense UI remains easy to read.

## 6. Spacing, shape, elevation and states

| Aspect | Rule |
| --- | --- |
| Spacing | 4 px base rhythm is a useful shared starting point: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64; compositions may diverge when a better rhythm is justified |
| Radius | 6 tags, 10 buttons and inputs, 14 cards and dialogs, 20 feature panels, pill for chips |
| Elevation | Borders first. Shadows only for real layers: overlay shadow 0 14px 40px at 18% deep teal; scrim 55% deep teal |
| Surface levels | Page, surface (card), raised (menu, popover), overlay (dialog, toast) |
| Hover | Subtle tint of the surface or a darker brand shade; never a layout shift |
| Focus | 3 px outline, 2 px offset, always visible; never removed |
| Active or pressed | Darker shade and a 1 px downward nudge |
| Selected | Subtle tint plus a marker (inset bar, check or filled chip), never color alone |
| Disabled | 50% opacity, not focusable, with a reason shown nearby when it blocks a task |

### 6.1 Whitespace and density

Whitespace is a functional part of hierarchy, emotional tone and readability. Do not compress a layout merely to fit more widgets above the fold. Preserve the 4 px base rhythm and use these density modes:

| Mode | Default use | Guidance |
| --- | --- | --- |
| Comfortable | Member dashboard, discovery feeds, profile, forms, standard cards | Default mode; generous separation and touch-friendly controls |
| Compact | Operations queues, recruiter comparison, dense tables, advanced filters | Reduce row and vertical spacing selectively; never reduce legibility or target size |
| Reading | Articles, technical answers, learning content and documentation | Narrow measure, clear heading rhythm, generous paragraph/code separation |

Recommended spacing: page title to description 8–12 px; description to first content section 24–32 px; major section separation 40–64 px on desktop; standard card padding 20–24 px and 16 px on narrow mobile; form-field groups 20–24 px. These are starting tokens; screen reviews may adjust by context.


Button shades: primary #156152, hover #0F4D41, pressed #0B3D33; lime hover #B5EE3F, pressed #A8DE33; destructive #B42332, hover #9A1C2A, pressed #85161F.

## 7. Layout, navigation and placement

| Element | Rule | Reason |
| --- | --- | --- |
| Page container | Content up to 1160 px (1320 px at 1536 px and up); padding 16, 24, then 32 to 40 px at 1280 px and up | Readable lines; dashboards can use width, reading pages cannot |
| Grid | 12 columns, spans of 3, 4, 6, 8, 12; one column below 768 px; quarter cards two across below 768 px and one below 640 px | Hierarchy by span, not decoration |
| Breakpoints | 640, 768, 1024, 1280, 1536 | DEC-008 |
| Sidebar | Persistent left navigation 232 px from 1024 px; filtered by role; active item has a marker | Frequent destinations always visible |
| Mobile navigation | Bottom bar below 1024 px, horizontally scrollable, icon above label | Thumb reach |
| Header | Sticky; workspace label, search (Ctrl or Command K), language, theme, notifications, account | Utilities do not compete with content |
| Page header | Icon tile, one H1, short description, at most one primary action on the right | One obvious task per page |
| Breadcrumbs | On pages deeper than two levels (position detail, candidate, thread, review) | Orientation and a quick way back |
| Primary and secondary actions | Primary bottom-right in forms and dialogs, secondary to its left, destructive named by outcome | Matches reading order |
| Footer | Fees, privacy, terms, contact; not repeated inside the app | Trust links without clutter |
| Safe areas | Respect device insets for the sticky header and bottom bar | Notched phones |
| Tables on small screens | Below 768 px a table becomes stacked cards, with the key fact first | Tables do not fit phones |

### 7.1 Layout families

**Editorial Workspace** is used for Community discovery, questions, articles, learning, profiles and member-facing journeys. It prioritises reading comfort, human context, clear content hierarchy and whitespace. Long-form reading columns target approximately 60–75 characters per line; secondary panels are optional rather than permanent.

**Analytical Workspace** is used for Operations, Recruitment dashboards, Community analytics, moderation queues and data-heavy administration. It takes inspiration from the supplied Vantage Admin reference: grouped persistent sidebar, breadcrumb/header, page title and context controls, a strip of 4–5 meaningful KPIs, a primary analytics region, a collapsible contextual right rail, and a detailed table/activity region. Use an approximate 70:30 main-area/right-rail split where it improves the task. Let analytical pages use available viewport width (often 1440–1600 px or fluid) instead of forcing the editorial reading width.

The right rail must be task-specific: filters, assumptions, alerts, suggested next actions or related information. It must not become a dumping ground for unrelated widgets. On tablet it collapses; on mobile it becomes a drawer or inline section. KPI cards show a definition, period and comparison where relevant. Avoid vanity metrics and excessive chart colors.

The two families share the same app shell, semantic tokens, typography, interaction rules and components. Do not force every screen into a dashboard or a card grid.

## 8. Cards and surfaces

Common anatomy: surface background, 1 px border, 14 px radius, 20 px padding (16 on mobile), 10 to 12 px gap, title first, supporting text, then actions. Informational cards are not clickable and have no hover state. Interactive cards have a hover tint, a visible focus ring, one main link, and nested controls that do not conflict.

| Card | Content order | Actions | Notes |
| --- | --- | --- | --- |
| Profile card | Avatar, name, role and location, verified skills, completeness | View, message | Never shows compensation or contact details |
| Member and community card | Avatar, name, reputation, expertise | Follow, mentor request |  |
| Post (question) card | Title, mode chip, author and time, replies and useful count, status | Open | Status chip carries text and glyph |
| Job card | Title, company, location and mode, experience, required and preferred skills, fee and experienced-only chips | Apply | Fee shown before the action |
| Candidate card or row | Name, role, experience, decision and stage chips, score, waiting time | Review, compare | Date of birth never shown to companies |
| Assessment and learning card | Title, level, state chip, progress, price chip | Start, continue, buy | Locked states say how to unlock |
| Verification and achievement badge | Label, glyph, skill; evidence detail on click | Open detail | Detail shows who decided, date, expiry |
| Notification item | Title, message, time, unread marker | Open record | No sensitive data in previews |
| Stats or metric card | Label, mono value, context or period | Drill in | Every number has a definition |
| Form section | Heading, why-we-ask text, fields, errors, save | Save, cancel | Sensitive fields explain visibility |
| Dialog | Title, short body, fields, actions | Confirm, cancel | Full page for long tasks; destructive dialogs name the effect |
| Empty and error panels | Reason, one next action, retry with filters kept | Retry, clear filter, create | Never a blank screen |

## 9. Icons, imagery and placeholders

- **Icons:** one outline style (Lucide-compatible), 24 px grid, 1.8 px stroke, round caps, drawn in the current text color; 20 px in navigation, 18 px in the header, 22 px in page tiles. Functional icons have an accessible name or visible text; decorative icons are hidden from assistive technology. Do not use an icon where a clear label would do.
- **Semantic glyphs:** check, exclamation, cross and info on chips and alerts.
- **Illustration:** subtle network lines, nodes and routing paths in low-opacity eucalyptus or mint; never behind dense text or forms.
- **Avatars:** initials on a soft module tint when there is no photo; 1:1 crop; the accessible name is the person's name.
- **Skeletons:** match the final layout; static under reduced motion; announced to assistive technology with a hidden label.
- **Empty-state graphics:** at most one small line illustration plus text and one action.


### 9.1 Curated component, icon and media ecosystem

| Purpose | Preferred source | Adoption rule |
| --- | --- | --- |
| Primary shared UI source | shadcn/ui | Source-owned components; adapt to Signal Grove tokens; never leave stock styling unreviewed |
| Supplementary dashboard/product components | Ingot UI | Curate individual registry items only; inspect dependencies, licence, accessibility and dark-mode coverage; current docs report light mode at launch and dark mode as a later update |
| Primitive layer for new shadcn projects | Base UI by default; Radix remains supported | First inspect existing dependencies. Do not migrate a stable existing primitive library just to follow a new default; do not mix Base UI and Radix arbitrarily |
| Styling | Tailwind CSS v4 | One styling system and one token bridge; production builds compile CSS |
| UI icons | Lucide | Default outline UI icon family |
| Technology / vendor marks | Simple Icons | Use only for recognised product/vendor identities; follow brand and trademark constraints |
| Photography / video | Unsplash, Pexels | Use selectively; verify asset and API terms, releases, attribution and hotlink requirements per use |
| Illustrations | unDraw or PacketPulse-owned SVGs | Keep one coherent illustration style; favour custom PacketPulse assets for core brand moments |
| Animation assets | LottieFiles, Rive | Use only for meaningful empty states, onboarding or achievement moments; review each asset licence and performance |
| Charts | Recharts (candidate) | Use semantic chart colors, labels, text summaries and data-table alternatives |
| Tables | TanStack Table (candidate) | Use when complex sorting, filtering and column behavior justify it |
| Rich text | Tiptap (candidate) | Review editor accessibility, extensions, sanitisation and content storage before adoption |
| Toasts | Sonner (candidate) | Toasts are supplemental; important outcomes also persist on the page |

**Primary recommendation:** shadcn/ui is the foundation; Ingot UI is a curated supplement, not a second competing design system. Chakra UI is not the primary choice while Tailwind v4 is the styling standard, because it would introduce a separate styling/theming approach. This is a stack recommendation, not permission to add packages before the repository audit.

**Tailwind CDN rule:** Tailwind Play CDN may be used for standalone mockups, quick experiments and static prototypes. The official documentation states it is development-only and not intended for production. The production Next.js application must compile Tailwind CSS v4 through the project's build integration. Do not depend on the browser CDN for production styling.

**Licensing and provenance:** Record source URL, creator/author where available, licence/terms checked date, attribution requirement, model/property release status where relevant, and local asset owner. Do not scrape or bulk-copy asset catalogues. Prefer optimised, locally managed or approved CDN assets with responsive sizes and lazy loading.

## 10. Interaction patterns

| Component | Behavior |
| --- | --- |
| Buttons | Explore primary, secondary, quiet, expressive, module-toned and destructive treatments as the task requires. States: default, hover, focus, pressed, disabled, loading (label stays, repeat clicks blocked). Start around 40 px on desktop and 44 px on touch devices, then validate real touch, keyboard and density needs |
| Forms | Label above the field, always visible; hint text; validate when the user leaves the field or submits; errors under the field, linked to it and announced; entered data is never cleared on error; long forms show an error summary at the top |
| Multi-step flows | Step indicator with step names; save and continue later; a Back button that keeps entries; the final step shows a review before submit |
| Menus, tabs, tooltips | Keyboard operable; tooltips never hold essential information |
| Dialogs | Labelled by their title; focus moves in and returns to the trigger; Escape and outside click close non-destructive dialogs; background scroll locked; one dialog open at a time |
| Toasts | About 2.6 seconds; never the only place for required information |
| Banners and inline alerts | For persistent states; errors use an alert role |
| Tables and lists | Sortable columns with the sort stated in text; filters shown as removable chips with a Clear all; pagination states the total count; the filter state is kept when returning from a detail page |
| Charts | Title, unit, a text summary, direct labels or a legend, and a data table alternative; never color alone; series colors come from module accents, not status colors |
| States | Loading skeleton, empty with one action, error with retry, success shown on the page for high-impact changes, disabled with a reason |
| Motion | Start around 150–250 ms for common state changes, then tune to purpose, device and motion character; celebratory or ambient motion may be explored where it feels meaningful; reduced-motion alternatives preserve information |
| Keyboard | Command palette (Ctrl or Command K); roving focus in menus; skip link; focus moves to the page heading on route change |

### 10.1 Motion language and microanimations

Motion may acknowledge an action, explain a state change, help orientation, clarify spatial relationships or contribute to the brand's atmosphere. Explore interaction feedback, ambient waves/pulses and expressive transitions where they improve the experience; adjust intensity to the context rather than enforcing one motion style. Preferred implementation library: Motion for React, subject to dependency audit. Use CSS transitions for simple hover/focus states where a runtime library adds no value.

| Pattern | Target duration | Notes |
| --- | --- | --- |
| Button press, bookmark, checkbox and toggle | 120–180 ms | Subtle scale/opacity/colour feedback; no layout shift |
| Tabs, tooltip, menu, toast and small popover | 150–250 ms | Quick, predictable; preserve focus behavior |
| Side panel, expandable section and layout transition | 240–350 ms | Use transform/opacity where possible; avoid expensive layout animation |
| Achievement or verification moment | 350–700 ms | Brief and restrained; one meaningful celebration, not repeated reward loops |
| Loading | As needed | Skeletons match final layout; no shimmer when reduced motion is active |

Respect `prefers-reduced-motion` and provide a reduced-motion mode. Tune or remove movement that makes reading, focus, chart interpretation or task completion harder. Keep useful state changes and feedback understandable without requiring motion.

## 11. UX writing and content rules

### 11.1 Voice and patterns

| Pattern | Rule | Example |
| --- | --- | --- |
| Buttons | Start with a verb; say the outcome | Submit application, Save changes, Start assessment |
| Errors | What happened, why, how to fix it; no blame | Code expired. Codes last 10 minutes. Request a new code. |
| Empty states | What this is, why it is empty, how to start | No applications yet. Apply to a job and its progress will appear here. |
| Confirmations | Name the action and the effect; buttons repeat the action | Withdraw this application? The recruiter will be told. Buttons: Withdraw application, Keep application |
| Loading | Say what is happening if it takes more than 2 seconds | Reading your resume... |
| Success | Short and calm; no exclamation marks except real milestones | Skill verified |
| Sensitive fields | Say why and who sees it | Current CTC. Only recruiters you are forwarded to can see this. |
| Tooltips | Short, never obvious |  |

Tone by context: success is warm but not loud; errors are kind and specific; warnings are clear and actionable; neutral text is informative and short. Never use urgency or scarcity tricks.

### 11.2 Product vocabulary (use these words everywhere)

| Use | Not |
| --- | --- |
| Member | User, candidate (candidate is used only in recruiter screens) |
| Jobs (member) and Positions (recruiter) | Openings, requisitions |
| Application | Submission (a lab submission is a Submission) |
| Forwarded | Sent, shared |
| Verified skill | Certified skill (certification is its own label) |
| Evidence | Proof, documents |
| Placement fee | Commission, charge |

### 11.3 Formats and limits **\[REVIEW\]**

| Item | Rule |
| --- | --- |
| Dates and times | 17 Oct 2026, 3:30 pm IST; the zone is always shown on interview times |
| Money | Rupee sign with Indian digit grouping, for example 12,50,000; annual pay also as lakhs per annum (12.5 LPA) |
| Numbers | Tabular figures; large counts shortened (1.2k) with the full value on hover or focus |
| Names and titles | Names up to 60 characters; question titles 8 to 120; position titles up to 80; skill chips up to 40 |
| Truncation | Card titles stop at 2 lines; long text ends with an ellipsis and a Show more control; truncated text is available in full to assistive technology |
| Sensitive data | Masked by default in lists (for example the last 4 digits of a phone number); shown in full only where DEC-015 allows |

## 12. Edge cases every screen handles

| Case | Behavior |
| --- | --- |
| Very long names, titles and skill lists | Wrap or truncate as above; never push layout sideways |
| Hindi and longer text | Allow about 30% more length; no fixed-width buttons; Devanagari line height 1.6 |
| Slow connection | Skeletons within 100 ms; a retry message after 10 seconds; uploads show progress and can be retried |
| Missing data | Show a dash with a reason where helpful (for example Not provided), never a fake zero |
| Zero results | Say what was searched and offer Clear filters |
| No permission | Explain in plain words and give a valid destination; never a blank screen |
| Offline or failed save | Keep entries on screen; say that it was not saved; retry button |
| Session ended | Return to the same page after sign-in; keep unsent form entries where possible |
| Large lists | Paginate or load more with a count; never load everything at once |
| Duplicate actions | Disable the button while working; a second click does nothing |

## 13. Accessibility standards

Target WCAG 2.2 AA in both themes (DEC-007, PRD-049).

| Area | Standard | Test |
| --- | --- | --- |
| Contrast | Text 4.5:1; large text and controls 3:1 | Computed per token pair; automated scans |
| Keyboard | Everything operable; logical order; visible focus | Keyboard-only journeys |
| Structure | Landmarks, one H1, no skipped levels | Automated scan and manual review |
| Names and forms | Every control named; errors announced and linked | Scan plus screen reader pass |
| Targets | At least 40 px for buttons and inputs; 24 px minimum anywhere | Visual review |
| Status | Text and glyph with every color | Review checklist |
| Zoom and reflow | Usable at 200% and 320 px wide with no sideways page scroll | Manual and automated |
| Motion | Respect reduced motion | Emulated setting test |
| Real assistive technology | A screen reader pass on onboarding, apply, assessment, verification and recruiter review each release | Manual, notes kept |

The prototype's automated scans found no violations, but they cannot measure contrast or layout, and no real screen reader testing has been done (RISK-10).

## 14. Governance and use by developers

- **One source of values.** Color, type, spacing, radius, elevation and motion are defined once in the token file that came with the reference prototype. Components use token names only; raw values appear nowhere else.
- **New tokens and components.** A new token needs a reason, a light and dark value, a contrast result and a change-log entry. A new component is proposed with its states, accessibility notes and a visual example of every state; an existing component changes only through a reviewed change that lists what else it affects.
- **Versioning.** The design system has version numbers (major for a visual or behavior break). Every release is listed in Document 1's change log.
- **Decisions.** A color, type or component decision is recorded as a DEC before it is built.
- **How to build from it.** Developers map these tokens to the existing styling setup; exact files are found in the repository audit (Document 4). Design specifications describe what should exist; only items marked PV were built, and only in the prototype.

- **Component registry.** Create a PacketPulse-owned shared component layer: base primitives (`ui`), cross-product components (`shared`) and module compositions (`community`, `learning`, `recruitment`, `payments`, `operations`). Use wrappers and variants so external library updates do not dictate the product API. A component is added once and reused; module-specific components must still consume common semantic tokens.
- **Component documentation.** Maintain a live component catalogue (Storybook or an equivalent already present in the repository), showing variants, responsive states, loading/empty/error/disabled states, keyboard behavior, light and dark themes, and copyable usage examples. Add screenshot/visual regression coverage for critical shared components.
- **Primitive choice.** For a new shadcn/ui project, Base UI is currently the documented default; Radix is still supported. For an existing app, inspect `package.json`, lockfile and actual components first. Do not perform a wholesale primitive migration without a concrete benefit and an approved task.
- **Production styling.** Tailwind Play CDN is prototype-only. Production Next.js uses compiled Tailwind v4 via the project's build pipeline. Keep tokens in CSS variables and expose them as semantic Tailwind utilities; no page-level raw colors.
- **External dependency review.** Before adoption, record package version, licence, maintenance state, accessibility behavior, bundle/runtime impact, React/Next compatibility, theme support and migration path. Keep a component-source register.
- **Experimental controls.** New motion, automated verification, recommendation and AI-assisted experiences may be included behind feature flags with telemetry and a defined review window. The review outcome must be recorded in Document 1 and the next-build change log.


## 14.1 Resources experience design rules

The Resources area is a first-class Community knowledge library, not a generic file dump. Use a calm, curated discovery surface with clear search, category/format/technology/difficulty filters, featured collections and resource cards that communicate type, topic, author, difficulty, estimated time, update/review date and save state. A card must explain why a resource is useful before asking a member to open it.

The resource-detail view is a reading/work surface: document or media preview is primary; table of contents and resource metadata are secondary rails; source, author, attribution, licence, version and review date are visible; related resources and discussion are discoverable without competing with the main content. The right rail can collapse. For long documents, preserve reading position and keyboard navigation.

Resource submission uses a three-step wizard: **Details → Content → Review & publish**. Accept upload, external URL or authored article. Show the real file lifecycle (queued, uploading, paused, processing/scanning, complete, failed, canceled, rejected); never fake progress. Capture author/source/attribution and usage rights before publishing. New external or uploaded resources may enter review; show the submitter the status and any changes required.

Saved resources combine an all-saved list, reading list, custom collections, recently viewed and continue-reading panel. Collections must have explicit private/shared visibility. Avoid making the user maintain duplicate lists when a simple bookmark is enough.

## 14.2 Signup, onboarding, profile and account rules

**Signup should feel like a welcome, not an application form.** Use a split layout on wide screens: a brand/story panel with an understated engineering-network visual and a compact form panel. On mobile, collapse to a single focused form. Offer email and password/passkey as the reliable baseline; Google/GitHub options may appear in the prototype, but must be configured and security-reviewed before real authentication is enabled. Explain why email verification is needed and keep recovery visible.

Onboarding is progressive and skippable for optional steps. Use a visible stepper for Role → Interests → Goals. Role choices include Student, Engineer, Specialist, Mentor and Recruiter; interests use the canonical skill taxonomy; goals include Learn, Practice, Contribute, Mentor and Find opportunities. Recommendations must be editable later. Do not ask for a resume or all employment details before the member understands the value of joining unless a protected workflow requires them.

**Profile and Account are separate destinations.** Profile is the member's professional and community identity. Account is the member's control centre for personal data, privacy, notifications, security, sessions, linked accounts, data rights and billing. A profile preview offers self, community-member and recruiter-after-forwarding perspectives; it must apply the real field-level visibility rules. Public web visibility remains opt-in/later and is off by default.

Profile layout: identity hero with avatar/name/headline/location, a clear edit action, audience-aware verification indicators and tabs for Overview, Skills, Contributions, Experience, Learning/Certifications, Activity and Achievements where available. Separate self-declared, assessment-verified, experience-verified, certification-verified and PP-verified states; never let colour alone communicate verification. Optional profile-completeness prompts are supportive, dismissible and never block functionality or shame users. An optional identity timeline records meaningful milestones only, with visibility controls.

Account settings use spacious grouped cards and dedicated detail pages: Personal information; Profile visibility; Notifications; Login & security; Sessions; Connected accounts; Privacy & data rights; Billing & payments (where applicable). Destructive actions sit in a clearly separated danger zone, explain consequences and require re-authentication/step-up where appropriate.

## 14.3 Experimental visual and colour freedom

The owner has explicitly approved creative experimentation with patterns, components, colour, imagery, typography and interaction treatment in the review build (DEC-049). Designers may explore alternative module accents, featured-resource treatments, profile identity motifs and hero compositions. Use A/B or side-by-side concepts where a choice is uncertain. Record each variant and its design hypothesis.

This freedom does not remove semantic meaning or accessibility. Text/background and control contrast must be checked; status labels still require text and glyph; module colours must not impersonate success/warning/error; colour must not be the only differentiator. The production palette is selected after the review evidence, not merely because a prototype looks striking.

## 14.4 Creative design freedom and flexible visual exploration

The owner explicitly directs the design team to be open, creative and experimental. Signal Grove unifies the product; it does not prescribe one colour, one motif, one layout, one radius, one card style or one animation language for every screen. The team may explore brand and module token combinations, tonal ramps, gradients, Pantone-inspired references, editorial display typography, layered illustrations, geometric patterns, waves, pulses, data lines, node meshes, security motifs, and new compositions. Explore ideas that have not been listed here when they create a clearer, more useful or more memorable experience.

The current Signal Grove tokens, module accents and semantic colours are a palette to work from, not an exclusive colour cage. Forest/teal/lime remain important brand options, while indigo, blue, plum, violet, cyan, amber, coral and future palette explorations may be used where they fit the content and mood. Status meanings remain clear and accessible; decorative colour is not a status indicator. Pantone references may be explored during brand/print work, then mapped to tested digital HEX/RGB values. Do not claim a Pantone match until an actual swatch/guide selection has been verified.

### Pattern overlays, not replacement backgrounds

Brand patterns should be designed as independent visual layers that can sit on top of existing page/card surfaces. Do not alter or replace the underlying background merely to apply a motif. Patterns may be inline SVG, CSS, masks or carefully optimised raster assets; prefer scalable, theme-aware, recolourable and crop-friendly sources. Pattern families are suggestions, not a closed inventory: packet routes, node constellations, signal waves, pulse trails, radar echoes, secure layers, data flows and packet matrices are starting points. New families and combinations are welcome.

Patterns can be subtle, expressive, cropped, partial, animated or static. Their colours may draw from brand, module, semantic and experimental tokens. Use them where they strengthen recognition or atmosphere: card corners, card headers, hero overlays, section dividers, profile covers, resource features, empty states, analytics headers and branded moments. Keep important text and controls readable; allow the pattern to disappear when it competes with the task.

### Design exploration loop

For meaningful alternatives, create two or more visual directions when useful; present a compact concept board; state the experience hypothesis; compare with real content and responsive layouts; gather team feedback in the agreed review window; and decide Retain, Refine, Restrict or Remove for the next build. Do not reject an idea only because it is not already in the token catalogue. Do not keep a design only because it is visually striking.

## 14.5 Parent-child and nested-screen experience

Treat a complex section as a navigable workspace, not a pile of modals. Preserve the parent context while a user enters a child workflow. Use the URL as the durable location for substantial pages and shareable detail; use a contextual drawer/sheet for quick inspection; use inline expansion for small supplementary detail. A route-backed drawer is appropriate when the child should be deep-linkable. Avoid stacked dialogs and nested modals.

Keep breadcrumbs, local section navigation, a visible parent return path and clear page titles. Preserve filters, search terms, selected row, scroll position and keyboard focus when returning to the parent where feasible. Browser Back/Forward must match the visible hierarchy. On mobile, child workflows generally become a full-screen route with an obvious back action; the user should not need to understand a desktop split pane. Make panel transitions responsive to the task, not an arbitrary maximum nesting depth.

## 14.6 Media, recordings and embedded-resource experience

Treat media as a first-class resource type. The player should feel native to PacketPulse while making the actual source clear. Design for direct video/audio files, adaptive streams, and approved external providers. Support play/pause, seek, volume, playback speed, quality where available, captions/subtitles, chapters, transcript access, fullscreen, keyboard operation, playback progress/resume and provider errors. Picture-in-picture and casting may appear where the browser/device/provider supports them. Do not present unavailable controls as working.

A recording detail may combine the player with a transcript, chapter list, resource metadata, notes, related resources and discussion. Let the user choose a focused/theater reading mode and preserve the resource's parent context. A recording card can show duration, provider/source, caption availability, progress and a meaningful thumbnail. No autoplay with sound. Respect reduced motion, data-saving and privacy choices.

File previews should be type-aware, not one generic embedded object. PDF, image, audio/video, text/Markdown/code and CSV previews can use suitable viewers. Office files should use an isolated preview/conversion process or a separately licensed editor; unsupported or unsafe files should offer clear download/recovery options. Never silently render arbitrary HTML, macros or user-provided iframe code.

### Sources

- Video.js 10.7.0 changelog (24 Nov 2026): https://videojs.org/changelog
- Video.js 10 React install: https://videojs.org/docs/guides/installation/react
- Uppy React integration: https://uppy.io/docs/react/
- Uppy Tus uploader: https://uppy.io/docs/tus/
- React-PDF: https://github.com/wojtekmaj/react-pdf
- Shaka Player: https://github.com/shaka-project/shaka-player
- ONLYOFFICE licensing FAQ: https://helpcenter.onlyoffice.com/docs/installation/community/faq

These are preferred review-build directions, not evidence that packages are installed. Check source repository, versions, licenses, provider policies, browser support and security requirements before production adoption.

## 15. Revision history

| Date | Version | Change |
|---|---:|---|
| 26 Nov 2026 | 4.5 | Owner clarified open creative exploration; added DES-031 and distinguished flexible aesthetic preferences from essential experience/safety checks; preserved existing backgrounds for transparent pattern overlays |
| 26 Nov 2026 | 4.4 | Added DES-022 to DES-030; expanded colour, pattern, layout, typography and motion exploration; refined nested UX, media and component-library guidance |
| 25 Nov 2026 | 4.1 | Added Resources, Signup, Profile and Account design rules; audience-aware profile previews and Approved Prototype status semantics |
| 24 Nov 2026 | 4.0 | Added DES-013 to DES-021; Matte Black analytical reference; Editorial/Analytical workspaces; whitespace and density modes; curated component/media ecosystem; Tailwind v4 production rule; microanimation guidance |
| 17 Oct 2026 | 3.0 | Signal Grove baseline: palette, module accents, typography, spacing, interaction patterns, accessibility and governance |

---

# Current design authority — 27 November 2026

## Approved colour foundation (owner-finalized)

The approved primary foundation is **Palette 1 — Violet-led**, complemented by Signal Grove. This supersedes prior global palette proposals and any earlier exploratory three-palette comparison. It is the foundation—not a finished operational token map.

| Foundation role | Approved value | Status / guardrail |
|---|---:|---|
| Primary Violet | `#615AB9` | Dominant brand signal |
| Deep Violet / Ink | `#16133E` | Deep brand anchor |
| Secondary Violet | `#8B7FF7` | Supporting brand hue |
| Light Background | `#F1F5F9` | Cool, light neutral foundation |
| Forest | `#156152` | Complementary Signal Grove accent |
| Signal Lime | `#C7FE53` | High-attention accent; use sparingly |
| Soft Forest | `#8BBBA5` | Supporting softer green |
| Black / near-black and white | neutral family | Theme, contrast and balance |

Violet is dominant; Forest and Lime are strategic complements, not co-equal primary colours. Build coordinated light and dark themes; dark is not a simple inversion. Payments blue is scoped to the Payments module. Do not globally restore older teal/forest-led or Palette 2/3 proposals.

## Delegation to Claude — approved, no shade-by-shade approval loop

The owner delegates to Claude the detailed operational design work: primitive and neutral ramps; semantic tokens and theme mappings; module aliases and component tokens; exact shade/hierarchy refinement within the foundation; light/dark states (hover, pressed, focus, selected, disabled, loading, validation); Forest/Soft Forest/Lime refinement and optional restrained glow; scoped Payments blue family; and reusable logo completion/variations (geometry, horizontal/compact/stacked/symbol-only, monochrome/reversed, clearspace, minimum size and favicon/app-icon adaptations). Claude must document rationale, preserve source assets/history, maintain one canonical token source, validate WCAG 2.2 AA in real states and proceed without asking for owner approval for each detailed design choice.

**Fixed boundary:** Claude may not replace the approved foundation without owner approval. Delegation is limited to design-system and logo completion. Product scope, workflows, privacy, permissions and consequential user-facing policy remain owner-governed unless separately delegated.

## User-centred design and responsible psychology

For each screen/artifact, state: user/context; task/outcome; psychological friction or need; required information/action; what must not be implied/disclosed; visual meaning and hierarchy; interaction/state/failure/recovery; accessibility/responsive/performance/reduced-motion; and validation evidence. Use design hypotheses and usability evidence; decide **Retain / Refine / Restrict / Remove**.

- Reduce competing signals and unnecessary decisions; reveal detail progressively.
- Guide attention without hijacking it; keep a clear primary purpose/action.
- Preserve skip/back/edit/dismiss/privacy controls where appropriate.
- Show only real, explainable progress, evidence, verification and recommendation confidence.
- Support confidence, dignity, belonging and competence; avoid shaming activity contests.
- Notifications, badges and motion must correspond to useful events; no false urgency or variable-reward loops for retention.
- No generic AI/fintech decoration: neural spheres, meaningless HUD labels, random glowing nodes, purposeless glass or perpetual ambient animation. A network motif must express actual people, knowledge, evidence, opportunity, routes or system connectivity.
- Dark/OLED is contextual, not universal.

## Motion principles

Motion is feedback/orientation, not decoration. Use short, purposeful, non-looping transitions for meaningful state changes; never imply live data where it is static/delayed. Keep status text and semantic cues independent of colour/motion. Respect `prefers-reduced-motion`; avoid parallax, flashing, large zooms, persistent animation and GPU-heavy 3D on ordinary screens. Pause nonessential off-screen effects, keep actions interruptible, use CSS/SVG for simple effects and measure mobile performance.

## Logo and asset governance

The concept direction is connected fiber-like paths, nodes and router/switch/gateway-inspired junctions—recognizable at small sizes and meaningful rather than generic circuitry. Claude finalizes the reusable artwork and variants. Keep editable vector masters, create new versioned assets (never overwrite history), test flat monochrome and 16/24/32 px silhouette, contrast, clearspace, minimum size and responsive lockups.

## Current Notion notes and source precedence

The 27 Nov Design System & UX Guide companion was updated with the user-centred design brief, animation rules, foundation/delegation and owner boundaries. The Brand & Visual Design System page records Isometric Network Modules / Network Landscape as creative exploration—not a locked template or token approval. The Design Token & Theme History page preserves older values and explicitly records that the 27 Nov palette decision does not erase history.

- Design System & UX Guide: https://app.notion.com/p/424520a4e11381d1a6ffd3757d2fb3a2
- Brand & Visual Design System: https://app.notion.com/p/424520a4e11381c795c9f84a3cc48fc6
- Design Token & Theme History: https://app.notion.com/p/424520a4e11381ddb78ae706abf797d2
- Component Ecosystem & Library Registry: https://app.notion.com/p/424520a4e1138153bd1eeea46aba3fcf

## Integrated component ecosystem and library registry

The full 26 Nov component ecosystem specification is incorporated below as an appendix so this four-file handoff remains self-contained. Its component recommendations are candidates, not installation or repository-validation claims. Where older appendix palette references conflict with the owner-finalized 27 Nov foundation above, the current foundation and Claude delegation take precedence; retain older values only as historical/source context.


---

# Appendix A — Full Component Ecosystem, UI Patterns & Library Registry (26 Nov source)

**Inclusion note:** This annex preserves the detailed 26 November component guide as a complete source appendix within the consolidated design file. The current 27 November owner-approved foundation and delegation above are authoritative where colour/token guidance differs. Historical entries remain available for lineage, not as current final colour approvals.

# PacketPulse 2.0 — 5. Component Ecosystem, UI Patterns and Library Registry

**Consolidated release:** v7.0 · 27 November 2026  
**Source baseline:** Owner-supplied project documentation set dated 24 November 2026, reconciled against later 25–26 November source packages, Notion exports/records and Git main snapshot through 27 November 2026.  
**Document status:** Product/design specification and project handoff. Not evidence of production implementation, legal approval or repository validation.  
**Source precedence:** Current owner-approved decisions and dated Notion decision/change records supersede earlier proposal or historical token values. Dated releases remain immutable; see the source/lineage section at the end.  
**Working agreement:** Product behavior, user flows, edge cases, acceptance criteria and quality standards are defined here. Claude audits and implements in the actual application repository. Do not invent repository paths, replace working services, or claim tests/deployment without evidence.

**Current owner direction (27 Nov):** User-context-first design, ethical psychology, accessible and truthful UX. The approved visual foundation is Violet-led Palette 1 (`#615AB9`, `#16133E`, `#8B7FF7`, `#F1F5F9`) complemented by Forest `#156152`, Signal Lime `#C7FE53`, Soft Forest `#8BBBA5`, and balanced black/white neutrals. Detailed operational tokens, shade/state refinement within this foundation, scoped Payments blue and reusable logo completion are delegated to Claude; the foundation and product-policy boundary are fixed unless the owner changes them.

**Reading note:** The complete 26 Nov canonical source text is retained below for traceability and detail. The 24 Nov source set is the historical baseline you identified; later dated records supersede it only where explicitly approved. Its dated palette/token proposals and other historical states are not silently promoted; use this 27 Nov authority block and the explicit current-decision addenda for present-day decisions.

**Version:** 1.7  
**Issued:** 26 November 2026  
**Revision:** Added Resources, Signup, Profile and Account component systems; promoted open concepts to Approved Prototype for review build  
**Owner:** Product / Design Lead (to be named)  
**Status:** Owner-directed design specification; implementation candidates require repository audit and component review  
**Companion documents:** Product Guide v5.5; Design System and UX Guide v4.5; Users, Screens and Page Flows v3.6; Delivery Plan and Developer Handoff v4.6  
**Purpose:** Turn the visual references and UI resources supplied by the product owner into an actionable design and implementation specification for PacketPulse's shared component system.

> **Core instruction:** Do not copy reference screens literally. Extract the useful visual and interaction patterns, adapt them to Signal Grove, validate them against real PacketPulse workflows, and implement them once as reusable, documented components.

---

## 0. How to use this document

This is the fifth canonical PacketPulse 2.0 reference document. It extends, rather than replaces, the existing Design System and UX Guide.

- Document 1 defines product vision, requirements and decisions.
- Document 2 defines the brand, design tokens, accessibility, layout and UX rules.
- Document 3 defines users, screens and page flows.
- Document 4 defines delivery tasks, developer handoff and acceptance tests.
- **Document 5 defines the component ecosystem, reusable UI patterns, source-library registry and the detailed implementation requirements for the owner-supplied visual references REF-00 through REF-06 and later PacketPulse design concepts.**

When two documents appear to conflict, use the newer owner-approved decision recorded in `CHANGELOG.md`. An owner-approved prototype may be built and reviewed in the next review build. A package may be evaluated/adapted in prototype; production dependency adoption still requires DEV-11, version/licence audit and technical approval. Prototype approval is not production approval.

### Status vocabulary

| Status | Meaning |
|---|---|
| Owner-directed | The product owner explicitly asked for this direction or supplied the reference. |
| Approved Prototype | Owner approved the pattern/component concept for the next review build; feedback can remove or refine it in a later build. |
| Production Approved | Approved for production adoption after repository, accessibility, security, licence and operational gates. |
| Recommended | A technical/design recommendation not yet owner-approved. |
| Candidate | A source/package may be explored in prototype; not yet selected as a production dependency. |
| Approved pattern | The pattern is approved for PacketPulse adaptation; exact code may still need implementation. |
| Implemented | Present in the repository and verified against its acceptance criteria. |
| Deprecated | Do not use in new work; replace through a documented migration. |

**Documentation is not evidence of implementation.** Developers must inspect the repository and record current state before changing packages or routes.

## 0.1 Owner direction: Be open, creative and experimental

The product owner explicitly directs the team to **be open, creative and experimental**. Treat this as a design and product-development principle, not as a request to abandon consistency or quality.

- Do not reject a visual idea, interaction, component, library, or capability solely because it is unfamiliar, unconventional, or outside the current component set.
- Explore the idea in the context of a real PacketPulse user need. Ask what it improves: clarity, confidence, belonging, delight, task completion, discovery, credibility, or development speed.
- When the right approach is uncertain, create a lightweight prototype or side-by-side variants instead of debating in the abstract. A useful default is to explore two or three materially different treatments for high-impact or uncertain experiences.
- Allow controlled visual experiments beyond the current palette or layout conventions in the exploration stage. Before promotion into a shared production component, map the winning treatment to Signal Grove semantic tokens and document any deliberate exception.
- Use feature flags, limited cohorts, reversible configuration, or isolated routes for behavioural experiments where appropriate. Keep experiments observable and reversible.
- Define a team review window for significant experiments. Collect member feedback, usability findings, accessibility results, performance, error rates and relevant product outcomes. At review, retain, refine, restrict, pause or remove the experiment based on evidence.
- Do not mistake novelty for value. Experimental work must still respect privacy, security, accessibility, performance, licensing and operational constraints.
- Avoid prematurely freezing the design system. It should provide a coherent foundation while leaving room for new patterns and better ideas.

### Experiment maturity states

| State | Meaning | Expected evidence before promotion |
|---|---|---|
| Spark | An idea worth exploring; no implementation commitment | User/problem hypothesis and inspiration/source note |
| Prototype | A quick, reversible demonstration | Visual/interaction comparison and feasibility notes |
| Pilot | Limited real use, cohort or feature-flag rollout | Defined review window, owner, success measures and safeguards |
| Approved | Team/product review supports continued use | Feedback summary, accessibility and technical review |
| Standard | Adopted into the shared PacketPulse system | Documentation, component API, tests, maintenance owner |
| Retired | Removed or replaced after review | Reason, migration or replacement note where applicable |

An experiment can be valuable even when it is not promoted. Record what was learned so the team does not repeat the same exploration without new evidence.

## 0.2 Experience principle: Make the product feel good to use

Whitespace, visual rhythm and emotional tone are product requirements. The interface should feel calm, capable, welcoming, credible and quietly rewarding. Do not fill available space with widgets merely because the viewport can hold them. Prefer a clear visual path, a meaningful focal point, and enough breathing room for users to understand what matters.

Use microanimations where they acknowledge an action, explain a state change, establish spatial relationships or make progress understandable. Do not add motion only for decoration. Preserve reduced-motion behaviour and keep all information understandable without animation.

---

# 1. Design direction from the supplied references

The six supplied images are grouped into four reusable design patterns. They show distinct jobs and should not be flattened into one visual style.

| Reference | File | Observed pattern | PacketPulse interpretation |
|---|---|---|---|
| REF-00 | `references/ui-inspiration/REF-00-matte-black-analytical-dashboard.jpg` | Matte-black enterprise dashboard; grouped sidebar; KPI strip; large central analytical chart; contextual right rail; detailed data table | Analytical Workspace inspiration for Operations, Recruitment and data-heavy Community views. |
| REF-01 | `references/ui-inspiration/REF-01-spacious-people-analytics-dashboard.jpg` | Light people/operations dashboard; utility bar; KPI panels; large analytic area; calendar; explanatory tiles; participant cards; green/lime accents | Soft Signal Light inspiration for people, community participation, scheduling and member overviews. |
| REF-02 | `references/ui-inspiration/REF-02-file-upload-in-progress.jpg` | Horizontal file card; file-type icon; filename; upload percentage and transferred/total size; pause and cancel controls; progress rail | Uploading state of the shared File Transfer component. |
| REF-03 | `references/ui-inspiration/REF-03-file-upload-complete-compact.jpg` | Compact completed file row; file icon; success glyph; completed status; file size; removal action | Compact successful state of the shared File Transfer component. |
| REF-04 | `references/ui-inspiration/REF-04-file-upload-complete-actions.jpg` | Completed file card; status and file size; secondary Change action; strong Download action | Expanded completed state with context-appropriate next-step actions. |
| REF-05 | `references/ui-inspiration/REF-05-perspective-card-carousel.jpg` | Horizontal image-led gallery; active centre card; partially visible side cards; perspective depth and metadata | Optional featured content, mentor, expert, event or project-showcase carousel. |
| REF-06 | `references/ui-inspiration/REF-06-numbered-feature-cards.jpg` | Tall numbered cards; large numerals; varied visual panels; clear title/copy and directional affordance | Editorial feature tiles, onboarding steps, learning pathways and product storytelling cards. |

## 1.1 What these references have in common

- Whitespace separates the interface into understandable groups.
- Large, clear primary content is supported by quieter secondary information.
- Cards have a recognisable silhouette without relying on heavy shadows.
- Status and progress are visible without opening a separate detail page.
- Colour is used with intent: a small number of strong accents against calm neutral surfaces.
- Repeated patterns can become reusable components instead of one-off page compositions.

### Supplied visual references

The seven owner-supplied visual references are included in `references/ui-inspiration/`: REF-00 is the matte-black dashboard; REF-01 is the spacious people/operations dashboard; REF-02 to REF-04 show the upload lifecycle; REF-05 is the perspective-led carousel; REF-06 is the numbered feature-card treatment. Keep these reference IDs and filenames stable across the handoff.

| Reference | Preview |
|---|---|
| REF-00 Matte Black Analytical Dashboard | ![Matte Black dashboard](references/ui-inspiration/REF-00-matte-black-analytical-dashboard.jpg) |
| REF-01 Spacious People Analytics Dashboard | ![Spacious people analytics dashboard](references/ui-inspiration/REF-01-spacious-people-analytics-dashboard.jpg) |
| REF-02 File Upload In Progress | ![File upload in progress](references/ui-inspiration/REF-02-file-upload-in-progress.jpg) |
| REF-03 File Upload Complete — Compact | ![File upload compact completed](references/ui-inspiration/REF-03-file-upload-complete-compact.jpg) |
| REF-04 File Upload Complete — Actions | ![File upload completed actions](references/ui-inspiration/REF-04-file-upload-complete-actions.jpg) |
| REF-05 Perspective Card Carousel | ![Perspective card carousel](references/ui-inspiration/REF-05-perspective-card-carousel.jpg) |
| REF-06 Numbered Feature Cards | ![Numbered feature cards](references/ui-inspiration/REF-06-numbered-feature-cards.jpg) |

## 1.2 What must not be copied literally

- Do not reuse the reference's sample names, people, dates, company data, percentages or metrics as PacketPulse data.
- Treat reference colours as inspiration, not restrictions. Explore the full Signal Grove palette, module accents, experimental hues, tonal ramps, multi-colour gradients and Pantone-referenced studies; record and test the chosen digital values.
- Treat 3D/perspective carousels as an expressive option for curated feature/collection discovery where they add value; also prototype calmer or simpler carousel variants and compare. Avoid making a high-motion 3D carousel the default for dense feeds, tables or task-critical lists unless research shows it helps.
- Do not use the numbered feature cards as the default treatment for all dashboard cards; explore them where storytelling, onboarding or structured navigation benefits.
- Let whitespace and hierarchy guide density; don't compress a screen simply to fit more widgets into the first viewport.
- Do not treat visual similarity as proof of accessibility, responsive behaviour, code quality or licence permission.

---

# 2. Signal Grove visual language for these patterns

## 2.1 One design system, multiple workspace moods

PacketPulse uses one Signal Grove token system with two layout families and deliberate theme variants:

1. **Editorial Workspace:** Community discussions, technical articles, learning content, profiles, mentoring and discovery. It prioritises reading comfort, content hierarchy, human identity and whitespace.
2. **Analytical Workspace:** Operations, recruitment analytics, community analytics, administrative queues and performance workspaces. It prioritises scanning, comparison, data clarity and drill-down.

The Analytical Workspace has two intentional appearances:

- **Matte Black Edition:** Preferred reference for data-heavy administrative and analytical workspaces, based on the owner's positive response to the matte-black dashboard reference.
- **Soft Signal Light:** Light counterpart inspired by REF-01. Particularly suitable for people/participation summaries, scheduling, community overviews and users who prefer light mode.

Both themes use the same component API, semantic tokens, information hierarchy and interaction rules. Theme choice must not change the meaning of data or the available actions. Respect the member's saved preference when a screen supports personal theme selection; organisation policy may set a default but should not silently remove the user's choice unless a separate product requirement approves that behaviour.

## 2.2 Theme tokens

Existing Document 2 tokens remain the source of truth. This table repeats the values needed by the new patterns; it does not create a second palette.

### Signal Grove light / Soft Signal Light

| Token | Value | Usage |
|---|---|---|
| Canvas | `#F5F8F6` | Main application background |
| Surface | `#FFFFFF` | Main cards, panels and forms |
| Surface subtle | `#E8F4EF` | Selected rows, soft panels and contextual highlights |
| Text primary | `#152025` | Headings, labels and body text |
| Text secondary | `#52615B` | Supporting text; validate at actual font size |
| Border | `#DCE5DF` | Low-emphasis structural boundaries |
| Control border | `#738279` | Input boundaries and controls |
| Brand forest | `#156152` | Brand actions and navigation |
| Forest hover | `#0F4D41` | Hover state |
| Signal lime | `#C7FE53` | Rare milestone/reward emphasis; use dark text on it |

### Matte Black Edition

| Token | Value | Usage |
|---|---|---|
| Analytics canvas | `#0B0D0C` | Main dashboard background |
| Analytics surface | `#171A18` | KPI panels, tables and workspace sections |
| Analytics raised | `#222724` | Raised panels, menus and selected surfaces |
| Analytics border | `#303631` | Subtle separators |
| Analytics text | `#F2F5F2` | Primary text |
| Analytics muted | `#A8B2AC` | Secondary text; contrast must be checked at actual size |
| Brand action | `#156152` | Primary actions; maintain visible label and focus state |
| Signal emphasis | `#C7FE53` | Rare emphasis and meaningful milestones |
| Secondary chart series | `#A78BFA` | Optional data series only; not a brand or status colour |

**Validation required:** Matte Black draft values must be contrast-tested for every foreground/background pair, border/control state, disabled state, chart series and focus ring before production. A visually attractive muted grey is not automatically readable at 12–14px.

## 2.3 Module accents

Use the existing module identities from Document 2:

- Community / Brand: Forest.
- Learning: Indigo.
- Recruitment: Blue.
- Payments: Plum.
- Operations: neutral/brand shell, with semantic state colours.

A component may accept a `tone` or `module` variant, but it must use semantic tokens rather than raw page-level hex values. Success, warning, danger and information always retain their semantic meaning. A module accent must never impersonate a success or verification state.

## 2.4 Whitespace and density

Whitespace is a deliberate UX tool. It establishes grouping, lowers perceived effort, improves scan paths and creates a calm product atmosphere. It is not unused space to be filled with widgets.

| Context | Default spacing guidance |
|---|---|
| Page edge | 24–40px desktop; 16–20px mobile |
| H1 to description | 8–12px |
| Description to first section | 24–32px |
| Major section separation | 40–64px desktop; 28–40px mobile |
| Standard card padding | 20–24px desktop; 16px mobile |
| Small status card padding | 12–16px |
| Form field groups | 20–24px |
| Reading line length | Aim for 60–75 characters |
| Dashboard grid gap | 16–24px, selected by density and viewport |

Density modes:

- **Comfortable:** Default for member dashboard, feed, cards, people panels and forms.
- **Compact:** Use for high-volume tables, review queues, candidate comparison and admin lists. Keep text readable and touch targets accessible.
- **Reading:** Use for article, question/answer, documentation and technical content.

Do not create empty space by hiding useful information; create it by grouping, prioritising and progressively disclosing secondary detail.

## 2.5 Shape, border and elevation

- Standard cards: 14–18px radius; larger feature panels may use 20–24px.
- File upload cards: 16–20px radius; compact rows may use 12–14px.
- Feature tiles: 20–24px radius, with clear internal padding.
- Inputs and buttons: follow the existing 10px radius token; pill shapes are reserved for chips and selected compact controls.
- Prefer a subtle 1px border and tonal surface separation over heavy shadows.
- Shadows are reserved for actual floating layers (menus, popovers, dialogs), not every card.
- Hover must not cause surrounding layout shift.

---

# 3. Reference pattern specifications

## 3.1 PP-DASH-001 — Spacious People & Community Analytics Dashboard

**Source inspiration:** REF-01.  
**Workspace:** Analytical Workspace, Soft Signal Light variant; compatible with Matte Black tokens.  
**Primary use:** Community overview, member participation, people/mentor operations, learning engagement and other dashboards that mix metrics with schedules or people.

### Layout anatomy

1. **Top utility bar**
   - Global search on the left with a visible keyboard hint (e.g. `⌘ K` / `Ctrl K`).
   - Optional AI/help assistant entry point, if the feature is enabled for that role.
   - Notifications with unread count.
   - Member avatar and account menu on the right.
   - Utility controls must remain compact and must not compete with the page title.

2. **Page header**
   - Breadcrumb where depth requires it.
   - One clear H1 and concise description.
   - Date range, workspace selector or primary action aligned to the right.
   - On mobile, selectors may move into a filter sheet.

3. **KPI strip**
   - Usually 3–5 cards. Four is a good starting arrangement for REF-01-style dashboards.
   - One featured metric may use a deeper forest surface with a high-contrast number and a small sparkline.
   - Remaining KPI cards use neutral surfaces, clear label/value/period comparison and a restrained mini-visual where useful.
   - Each metric must define its period, unit and comparison baseline. A number without a definition is not an approved KPI.
   - Avoid decorative mini charts if the data cannot be interpreted or if they duplicate the main chart.

4. **Primary analysis area**
   - Use a clear 8/4 or 7/5 grid depending on the right rail content.
   - Main panel may include chart, distribution, percentage breakdown or activity analysis.
   - Show a title, metric unit, period selector, legend and direct labels or tooltip details.
   - A tooltip can reveal detail but must not contain the only explanation of a metric.
   - Pattern fills/hatching may support series differentiation, but colour alone must never be the only distinction.

5. **Contextual calendar / schedule panel**
   - Month and date navigation.
   - Selected day, today, event day and disabled date must be visually distinct and keyboard operable.
   - Below the calendar, show a concise agenda list for the selected day.
   - Mobile: calendar collapses to a compact date strip or opens in a sheet; agenda remains a readable list.

6. **Supporting insight panels**
   - Use a two-column arrangement for short explanation, happiness/health signal, next action, or overview text.
   - One panel may have a slightly stronger background or accent; do not give every panel a different colour.
   - Each panel has a clear title, short explanatory copy and at most one obvious action.

7. **People / contributor panels**
   - Member avatar, display name, area/skill, relevant tags, participation context and one appropriate action.
   - Avatar groups can show a small set of additional participants, with a `+N` overflow label.
   - Do not show follower counts or vanity scores as the primary credibility signal.
   - Keep privacy and profile visibility settings intact.

### Visual hierarchy

- KPI value is the strongest element inside a metric card; metric label and comparison follow.
- Use tabular numerals for counts, dates and percentages.
- One featured KPI is enough; all cards should not compete for hero treatment.
- Chart occupies the largest visual area because it answers the dashboard's primary question.
- Calendar and people panels are secondary context, not equal-weight competitors.
- Use a restrained green/lime accent; lime is for selected days, key milestone or one meaningful emphasis, not all chart bars.

### Responsive behaviour

| Viewport | Behaviour |
|---|---|
| ≥1280px | Full KPI strip; main analysis and contextual rail side-by-side; supporting panels below |
| 1024–1279px | KPI grid may wrap; right rail may narrow or collapse |
| 768–1023px | Two-column KPI cards; calendar and people context move below chart or into collapsible panel |
| <768px | Single-column flow; no horizontal page overflow; compact utility bar; calendar uses sheet/date strip |
| <640px | KPI cards may use 2 columns only if labels and values remain clear; otherwise stacked list |

### States and interactions

- Loading: skeletons preserve the final layout dimensions; avoid flashing empty cards.
- Empty: explain why there is no data and provide a next action (e.g. invite members, select period, create event).
- Error: show what failed, keep selected filters, provide retry.
- Metric drill-down: clicking a KPI should navigate or open a meaningful detail view; do not make numbers look clickable if they are not.
- Chart hover/focus: keyboard-accessible inspection and text-equivalent summaries.
- Calendar date selection: visibly update agenda panel and announce selection accessibly.

### Build notes

Use the shared `AnalyticalWorkspaceShell`, `MetricCard`, `ChartPanel`, `CalendarPanel`, `PeopleListCard` and `InsightPanel`. The page must not be implemented as one monolithic dashboard component.

---

## 3.2 PP-UPLOAD-001 — File Transfer / Upload Card

**Source inspiration:** REF-02, REF-03 and REF-04.  
**Use:** Community technical questions, learning submissions, resumes, certifications, verification evidence, profile media and administrative attachments.

The three images represent related states of one component, not three unrelated designs.

### Component anatomy

- File-type icon or thumbnail.
- Filename (truncate only after a useful visible portion; full name available to screen readers and detail tooltip).
- File size and optional file type.
- Status label and, when uploading, progress percentage and transferred/total bytes.
- Progress rail with accessible text value.
- State-dependent controls: pause, resume, cancel, retry, remove, change file and download.
- Optional security/validation status (e.g. scanning, file type rejected, sensitive-data warning).

### Required state model

| State | Visual treatment | Available action |
|---|---|---|
| Idle / empty | Drop zone or browse button; accepted formats and max size stated | Choose file / drag and drop |
| Selected / queued | File icon, name, size and queued label | Start, remove |
| Uploading | Progress rail, percentage, transferred/total size | Pause, cancel |
| Paused | Frozen progress, explicit Paused label | Resume, cancel |
| Processing / scanning | Indeterminate progress or staged status; do not fake percentage | View status, cancel only if supported |
| Completed | Success glyph, Completed text, file size | Change, download, remove if permitted |
| Failed | Error glyph, concise reason, retained filename | Retry, change, remove |
| Canceled | Canceled label, no success semantics | Retry or remove |
| Rejected | Policy reason (format, size, malware or policy) | Change file, view guidance |

### Reference states

- **REF-02 Uploading:** Place filename and file identity on the first line. Show percentage and bytes transferred on the second line. Progress rail spans most of the card width. Pause and cancel remain clearly separate controls.
- **REF-03 Completed compact:** Use a single-row version for completed lists. Show file icon, success glyph, status and file size; removal action is visually separated and labelled accessibly.
- **REF-04 Completed actions:** Use an expanded footer with secondary `Change` and primary `Download` buttons when the next task requires the file. If download is not relevant (e.g. uploaded evidence), replace it with the appropriate approved next action.

### Progress behaviour

- Progress value must come from actual transfer events, not a decorative timer.
- Show a numerical percentage when reliable. If the upload is indeterminate, use an indeterminate progress state and explanatory label.
- Pause/resume is shown only if supported by the upload transport/provider. Do not show a fake pause button.
- Cancel is not the same as delete. Cancel stops an active transfer; remove deletes a queued/completed item from the current form according to the product's storage rules.
- Completion state must be stable; do not auto-dismiss a file needed for the next step.
- If a file is replaced, clarify whether the old file is removed immediately or after the replacement succeeds.

### Validation and safety

- Display accepted formats and maximum size before upload.
- Validate size and extension client-side for fast feedback and server-side for enforcement.
- Verify file content/type server-side; extension alone is not trusted.
- Scan files and quarantine unsafe attachments before making them accessible.
- For technical uploads, add sensitive-data warning/redaction guidance where applicable.
- Never expose an attachment to other users until the server-side access policy permits it.
- For long/resumable uploads, select a transport that actually supports pause/resume and recovery. Evaluate the existing backend first; Uppy or a provider-native resumable approach is a candidate, not a default dependency.

### Accessibility

- Progress uses `role="progressbar"` or the appropriate native element with accessible name, `aria-valuenow`, `aria-valuemin`, `aria-valuemax` where determinate.
- Announce state changes (uploading, paused, completed, failed) without announcing every percent tick.
- Buttons have explicit names (`Pause upload`, `Cancel upload`, `Remove file`, `Download file`).
- Do not rely on green/red alone; show icon and text.
- Preserve keyboard navigation and visible focus.

### Responsive behaviour

On mobile, stack metadata and actions naturally. Keep primary status visible; place secondary actions in an overflow menu only when necessary. Do not make the progress rail too thin to perceive or tap its controls too small.

### Component API direction (illustrative, not final code)

```tsx
<FileTransfer
  file={file}
  status="uploading"
  progress={65}
  transferredBytes={1_400_000}
  totalBytes={2_300_000}
  onPause={pauseUpload}
  onCancel={cancelUpload}
  onRetry={retryUpload}
  onRemove={removeFile}
  onDownload={downloadFile}
  onReplace={replaceFile}
  density="comfortable"
/>
```

The API must not expose unsupported actions. Use controlled state from the upload service; do not have the visual component invent or simulate upload completion.

---

## 3.3 PP-CAROUSEL-001 — Perspective Featured Card Carousel

**Source inspiration:** REF-05.  
**Use:** Featured mentors, expert contributors, upcoming events, curated learning resources, community projects and selected case studies.

### Visual style

- Horizontal track with one clearly active centre card and adjacent cards partially visible.
- Active card may be slightly larger or sharper; adjacent cards may be scaled down or subtly angled.
- Use restrained perspective (`perspective` / `rotateY`) as a progressive enhancement, never as a requirement for understanding content.
- Active content includes image/portrait, title/name, category or role, and a small set of useful metadata.
- A separate metadata strip may show relevant facts (e.g. availability, skill area, reading time, event date), not arbitrary vanity values.
- Keep surrounding canvas calm; no glowing neon rails or continuous auto-motion.

### Interaction

- Support drag/swipe, previous/next controls and keyboard navigation.
- Make active index visible via dots, count or selected card semantics where appropriate.
- Do not auto-advance by default. If auto-advance is introduced, provide pause/stop controls and a respectful interval; avoid auto-advancing content that users are reading.
- Clicking a card opens its detail page or performs a clearly indicated action.
- Ensure partially visible cards do not trap focus or hide essential controls.

### Responsive behaviour

- Desktop: show active centre card plus partial neighbours.
- Tablet: reduce side peek and perspective; allow drag/swipe.
- Mobile: use a single-card swipe layout with visible next-card hint; keep navigation buttons accessible.
- Reduced motion: remove 3D rotation and animated scale; use a simple horizontal scroll/instant active state.

### Appropriate PacketPulse uses

- Featured mentors/expert contributors.
- Upcoming AMAs or technical events.
- Curated courses, labs or learning paths.
- Member project/case-study showcases.
- Featured community spaces.

### Do not use for

- Primary question feed.
- Long lists, tables or search results.
- Important alerts or transactional controls.
- Interfaces where users must compare many items precisely.

---

## 3.4 PP-FEATURE-TILE-001 — Numbered Editorial Feature Cards

**Source inspiration:** REF-06.  
**Use:** Product marketing, community onboarding, learning pathways, step-by-step setup, value proposition sections and curated feature explanation.

### Visual anatomy

1. A tall portrait-oriented card with a large number or sequence marker (`01`, `02`, `03`).
2. A visual zone in the upper/central area: illustration, abstract pattern, product screenshot crop or restrained gradient.
3. A clear heading and short description near the lower section.
4. A small directional affordance (arrow) showing that the card can be opened or explored.
5. A layered panel or inset surface that gives the card visual depth without excessive shadow.

### Style rules

- Use a coherent family of surfaces: one forest/teal card, one neutral/light card, one dark/raised card where the story benefits from variation.
- Numbering must be consistent in position, size and visual meaning.
- Keep the title concise; description should normally be 1–3 short lines.
- A card should have one clear destination/action.
- Use a single shared card layout, not three unrelated designs.
- The card's visual zone must not be a decorative placeholder without meaning. Prefer custom illustrations or real product imagery.
- In Matte Black mode, use tonal surface separation and a restrained accent; do not simply invert the reference's bright gradient.

### Interaction

- Whole card is clickable only if it leads to a single destination; otherwise keep a clear button/link.
- Hover may raise the card by 1–2px, move the arrow by 2–4px or reveal a subtle border/gradient change.
- Focus state must be as visible as hover.
- No auto-playing video or continuous gradient animation.
- Reduced-motion users receive a static card with the same hierarchy.

### Appropriate PacketPulse uses

- `Learn → Practice → Prove` pathway.
- Community onboarding: discover, ask, contribute.
- Product capability storytelling.
- How verification works.
- Getting-started guides for organisations.

### Do not use for

- Repeated dashboard KPI cards.
- Dense admin lists.
- Transaction status or verification decision details.
- Long explanatory text.

---

# 4. Shared component design catalogue

The following catalogue converts the references and previously researched component sources into PacketPulse-owned components. `PP-*` identifiers are stable registry IDs. The owner has approved this catalogue as the **review-build component scope**. Components are Approved Prototype until implementation and review; source packages remain subject to repository/licence audit before production adoption.

## 4.1 Foundations and shell

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-FND-001 | Design tokens & theme bridge | Light, Matte Black, module accents, semantic states, typography, spacing and motion | Existing Signal Grove tokens; Tailwind CSS v4 | P0 |
| PP-SHELL-001 | Application shell | Shared app frame, route content, theme and role context | shadcn patterns; custom PacketPulse wrapper | P0 |
| PP-SHELL-002 | Workspace sidebar | Grouped, role-aware, collapsible nav | Component Gallery, BoardUI, Bencho | P0 |
| PP-SHELL-003 | Utility header | Search, assistant entry point, notifications, theme and account | REF-00, REF-01; custom wrapper | P0 |
| PP-SHELL-004 | Page header | Breadcrumb, H1, description, action and filters | Beautiful UI, BoardUI, shadcn | P0 |
| PP-SHELL-005 | Contextual rail | Collapsible task-specific side panel | REF-00; BoardUI; Base UI / Radix primitive | P1 |

## 4.2 Navigation, discovery and overlays

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-NAV-001 | Breadcrumbs | Deep-page orientation | Component Gallery, BoardUI, shadcn | P0 |
| PP-NAV-002 | Tabs / segmented control | Switch view or period | Component Gallery, BoardUI, Transitions | P0 |
| PP-NAV-003 | Global command/search palette | Search and action discovery | Bencho, Beautiful UI, shadcn | P1 |
| PP-NAV-004 | Filter bar | Visible filters, removable chips, clear all | BoardUI, TanStack patterns | P0 |
| PP-NAV-005 | Combobox / autocomplete | Select taxonomy, skills, members and entities | Bencho, BoardUI, Beautiful UI | P0 |
| PP-OVL-001 | Dialog | Confirm, edit or focused task | shadcn + existing primitive choice | P0 |
| PP-OVL-002 | Drawer / sheet | Detail preview and contextual editing | BoardUI, Beautiful UI | P0 |
| PP-OVL-003 | Popover / tooltip | Supplementary context and compact controls | Component Gallery, Bencho | P0 |
| PP-OVL-004 | Calendar / date picker | Event, assessment and schedule selection | BoardUI; existing primitive | P1 |

## 4.3 Analytics and data

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-DATA-001 | Metric / KPI card | Label, value, period, comparison, optional sparkline | REF-00, REF-01, BoardUI, Ingot UI | P0 |
| PP-DATA-002 | Featured KPI card | One priority metric on a stronger brand surface | REF-00/REF-01 adapted to Signal Grove | P0 |
| PP-DATA-003 | Chart panel | Chart title, description, period control, legend and text summary | BoardUI, Beautiful UI, Recharts candidate | P0 |
| PP-DATA-004 | Data table | Sorting, filters, visibility, selection, pagination and empty/error states | TanStack Table candidate; BoardUI patterns | P0 |
| PP-DATA-005 | Activity timeline | Audits, status changes and chronological activity | Component Gallery, Bencho | P1 |
| PP-DATA-006 | Calendar panel | Month grid with selected-day agenda | REF-01, BoardUI | P1 |
| PP-DATA-007 | Insight panel | Short insight, supporting context and one action | REF-01 | P1 |

## 4.4 File and technical content

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-FILE-001 | File transfer card | Queued/uploading/paused/processing/completed/failed/rejected states | REF-02 to REF-04; custom PacketPulse component | P0 |
| PP-FILE-002 | Dropzone | Browse and drag/drop entry | Bencho, BoardUI; evaluate react-dropzone/Uppy only if needed | P0 |
| PP-FILE-003 | File preview | Safe preview of images, PDFs and supported evidence | Custom wrapper; existing preview package audit | P1 |
| PP-CONT-001 | Rich content editor | Markdown/rich text with preview and sanitisation | Tiptap candidate; existing editor audit | P0 |
| PP-CONT-002 | Code block | Syntax highlight, copy, language label and overflow handling | Custom styling; existing highlighter audit | P0 |
| PP-CONT-003 | Technical redaction notice | Warn about secrets and sensitive values | Custom UI; detection service separate | P0 |
| PP-CONT-004 | Revision history | Display edits and compare revisions | Custom timeline/diff composition | P1 |

## 4.5 Community, identity and contribution

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-COM-001 | Question card | Question summary, tags, status, answer count and activity | Component Gallery, Bencho, custom wrapper | P0 |
| PP-COM-002 | Answer card | Answer body, author, useful vote, accepted/reviewed distinction | Component Gallery; custom wrapper | P0 |
| PP-COM-003 | Discussion / article card | Structured content feed | Component Gallery, REF-06 for featured treatment only | P0 |
| PP-COM-004 | Member identity card | Name, role/interests, skills and contribution context | Bencho, REF-05 | P0 |
| PP-COM-005 | Avatar group | Participants and reviewer groups | Bencho, Transitions | P1 |
| PP-COM-006 | Featured carousel | Selected mentors, events, knowledge and case studies | REF-05; Bencho/BoardUI patterns | P1 |
| PP-COM-007 | Numbered feature tile | Onboarding and editorial explanation | REF-06; custom wrapper | P1 |
| PP-COM-008 | Saved item / bookmark | Save and manage useful knowledge | Custom wrapper | P0 |
| PP-COM-009 | Reputation summary | Contribution quality, separate from formal verification | Custom wrapper | P1 |

## 4.6 Feedback, state and progression

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-FB-001 | Toast | Brief action feedback | Sonner candidate; Transitions recipes | P0 |
| PP-FB-002 | Banner / inline alert | Persistent or contextual system status | BoardUI, Beautiful UI | P0 |
| PP-FB-003 | Empty state | Explain absence and provide next action | unDraw/custom illustration | P0 |
| PP-FB-004 | Skeleton | Layout-matched loading | Transitions, custom CSS | P0 |
| PP-FB-005 | Progress indicator | Multi-step flow and learning/verification progress | BoardUI, Bencho, Transitions | P0 |
| PP-FB-006 | Status badge | Semantic states with icon and label | Component Gallery, shadcn | P0 |
| PP-FB-007 | Confirmation action | Destructive or high-impact confirmation | Beautiful UI, shadcn | P0 |

---

# 5. Component ecosystem and library registry

## 5.1 Adoption architecture

PacketPulse must own the final component API and visual behaviour. External libraries are sources and foundations, not competing product design systems.

Recommended layers:

1. **Foundation:** Tailwind CSS v4, CSS variables, semantic tokens, typography, spacing and motion tokens.
2. **Accessible primitives:** Use the primitive family already present in the repository. New shadcn projects currently default to Base UI; Radix remains supported. Do not mix both arbitrarily or migrate a stable app without a clear technical reason.
3. **Source-owned components:** shadcn/ui is the preferred base where appropriate; components are copied into the repo and adapted.
4. **Curated registries:** Ingot UI, BoardUI, Beautiful UI and Bencho may supply specific components after a code, licence, accessibility and theme audit.
5. **PacketPulse wrappers:** `PPButton`, `PPDialog`, `PPDataTable`, `PPFileTransfer`, etc. expose stable product-specific APIs and Signal Grove tokens.
6. **Product compositions:** Analytical Workspace, Community Composer, Verification Review Panel and other screen-level assemblies.

External code should be imported into a controlled location, reviewed, and then adapted behind the PacketPulse component API. Do not allow a library's default design tokens, font, colours or icon style to become global product defaults.

## 5.2 UI component/source registry

Counts and pricing/licence terms can change. The entries below are a snapshot of source research dated 25 November 2026; recheck the official page and licence before copying a component or installing a paid item.

| Source | Type | PacketPulse use | Adoption decision | Key checks |
|---|---|---|---|---|
| [Component Gallery](https://component.gallery/) | Component/design-system reference catalogue | Compare patterns for navigation, forms, tables, cards, feedback, calendars and upload patterns | Essential research reference; not a dependency | Study original design-system guidance, accessibility and implementation context |
| [shadcn/ui](https://ui.shadcn.com/) | Source-owned component foundation and registry | Common controls, dialogs, menus, forms, navigation and accessible compositions | Preferred primary foundation | Inspect current primitive family, project React/Tailwind versions and existing packages |
| [Base UI](https://base-ui.com/) | Unstyled accessible component primitives | New shadcn-compatible primitive layer where it fits the existing app | Candidate / current shadcn default for new projects | Do not migrate existing Radix stack only to follow a default |
| [Radix UI](https://www.radix-ui.com/primitives) | Accessible unstyled primitives | Existing or selected dialog, menu, popover, tabs and select behaviours | Retain if already established; avoid arbitrary mixing | Check component coverage and compatibility |
| [Ingot UI](https://ingotui.com/) | Dashboard design-system/component registry | KPI cards, chart panels, admin and analytical patterns | Approved prototype source for selective adaptation; production dependency requires audit | Official docs currently describe React 19 + Tailwind v4 + Base UI; light mode ships and dark mode is listed as a later update. Check current status; verify plan-specific licence and mobile fit |
| [BoardUI](https://www.boardui.com/) | React/Tailwind dashboard component library | Data tables, calendars, charts, KPI cards, sidebars and dashboard blocks | Approved prototype source for selective adaptation; production dependency requires audit for Analytical Workspace | Official site currently advertises React 19.2, Tailwind v4, 104 components and 19 charts; check each component's installability, terms and responsive behaviour |
| [Beautiful UI / Notchset](https://beautiful-ui.dev/) | shadcn-compatible React component and chart registry | Specialised controls, data visualisations, action rails and dashboard blocks | Approved prototype source for selective adaptation; production dependency requires audit | Official docs describe React 19 and Tailwind v4, Base UI and Radix builds; 150 items, including free and Pro tiers. Check item-level licence and primitive match |
| [Bencho](https://bencho.dev/) | Interactive React component and microinteraction library | Resizable panels, autocomplete, avatar groups, network/graph patterns, sliders and interaction ideas | Approved prototype source for selective adaptation; production dependency requires audit and inspiration source | Site states live-tunable blocks; free blocks MIT and Pro source/MCP. Verify individual block licence and dependencies |
| [Transitions](https://transitions.dev/) | Motion recipes, component builder and agent workflow | Card resize, progress, notifications, tabs, modal/panel, skeleton reveal and icon transitions | Approved motion reference/workflow; not a second runtime animation framework | Check free/Pro recipe terms, MCP/skill plan, generated code and performance; use PacketPulse motion tokens |
| [Beautiful UI charts](https://beautiful-ui.dev/components) | Chart examples within registry | Chart patterns and controls | Approved for prototype pattern exploration; standardise chart renderer separately | Ensure accessible labels, series colours, table alternative and data definitions |
| [TanStack Table](https://tanstack.com/table/latest) | Headless table logic | Complex operations, recruiter and moderation data tables | Approved prototype behaviour layer; adopt if existing table stack is insufficient | Use only if existing table layer is insufficient; PacketPulse owns styling |
| [Recharts](https://recharts.org/) | React charting library | Standard bar, line, area and composition charts | Approved prototype renderer candidate; use existing renderer if available | Audit bundle cost, accessibility limitations and current chart dependency before adoption |
| [Motion for React](https://motion.dev/) | Runtime animation library | Layout transitions, gestures and meaningful component motion | Approved prototype runtime candidate from Document 2; verify repository compatibility before installation | Inspect package state and current React/Next compatibility; use CSS for simple transitions |
| [Tiptap](https://tiptap.dev/) | Rich-text editor framework | Community technical composer and knowledge articles | Approved prototype editor candidate; compare against existing editor before adopting | Evaluate schema, extensions, sanitisation, accessibility, collaboration needs and licence |
| [Sonner](https://sonner.emilkowal.ski/) | Toast notification library | Non-blocking save/copy/submit feedback | Candidate | Toasts must not be sole record of high-impact outcomes |
| [Lucide](https://lucide.dev/) | UI icon library | Default interface iconography | Preferred default | Consistent stroke, accessible labels and tree-shaking |
| [Simple Icons](https://simpleicons.org/) | Brand/product logo collection | Technology tags, integrations and vendor identities | Use selectively | Check brand usage and individual trademark terms; never replace generic UI icons |
| [Uppy](https://uppy.io/) | File upload framework | Resumable/large uploads where the upload infrastructure needs it | Candidate only if required | Audit storage, transport, security, server integration and bundle cost |
| [react-dropzone](https://react-dropzone.js.org/) | File selection/dropzone utility | Simple browser drag/drop and file input handling | Lightweight candidate | Does not by itself provide resumable upload transport or server-side validation |

## 5.3 Discovery, inspiration and learning registry

| Source | Type | Use | Status / guardrail |
|---|---|---|---|
| [Browsable](https://browsable.dev/) | Plain-language component search (as supplied by owner) | Discover components by describing a need in natural language | Approved for design research; no runtime dependency; validate availability and exact capabilities |
| [UI Feed](https://ui-feed.dev/) | Live interface inspiration gallery | Observe new interaction and visual ideas; copy patterns only after adapting them | Approved for design research; inspiration, not implementation authority |
| [Polymode Sans](https://polymodesans.com/) | Variable display typeface | Campaign graphics, selected editorial headlines and brand experiments | Approved for prototype typography experiments only; confirm early-access licence, font format and performance before production use. Do not replace Inter for dense application UI |
| [Deimos](https://deimos.evilrabbit.com/) | Design encyclopedia / designer reference | Improve design vocabulary, visual research and team learning | Learning reference, not a component library |
| [Component Gallery design systems](https://component.gallery/design-systems/) | Design-system directory and reference catalogue | Study mature systems such as Polaris, Carbon, Fluent and others | Use original documentation and accessibility guidance, not just screenshots |

## 5.4 Media and asset registry

| Source | Asset type | PacketPulse use | Guardrail |
|---|---|---|---|
| [Unsplash](https://unsplash.com/) | Photography | Campaign, event and selected editorial imagery | Follow Unsplash licence/API conditions, attribution requirements where applicable, hotlink and caching rules |
| [Pexels](https://www.pexels.com/) | Photography and video | Events, community/editorial sections and marketing | Verify licence, API requirements, model/property releases and content suitability |
| [unDraw](https://undraw.co/) | SVG illustrations | Empty states, onboarding and explainers | Follow current licence and avoid distributing the collection as a competing asset library |
| [LottieFiles](https://lottiefiles.com/) | Lottie animations | Selected empty states, onboarding and achievements | Review exact animation licence, attribution and runtime cost |
| [Rive](https://rive.app/) | Interactive vector animation | High-value interactive brand moments and selected illustrations | Review asset/runtime licence, accessibility and performance |
| [Lucide](https://lucide.dev/) | Functional icons | Buttons, navigation, status and controls | Default icon family; do not mix icon families without a reason |
| [Simple Icons](https://simpleicons.org/) | Technology logos | Skills, technology stacks and integrations | Logos are brand assets, not generic pictograms |
| PacketPulse-owned SVGs | Brand illustration and diagrams | Product-specific onboarding, network/architecture diagrams and empty states | Preferred for recognisable core brand moments; record author/source |

### Asset provenance fields

Every non-trivial image, illustration, logo or animation should have a record with:

- Asset ID and local path or managed asset URL.
- Source page and creator/author if known.
- Licence/terms and date checked.
- Attribution requirement.
- Model/property release review where people/property are depicted and the licence requires it.
- Usage scope (marketing, in-app, community, paid tier, etc.).
- Dimensions, format, compression and fallback.
- Owner and replacement/deprecation status.

Do not scrape, bulk-copy or redistribute a provider's asset catalogue. Do not ship user-supplied or third-party assets without confirming the right to use them.

---

# 6. Motion and microinteraction patterns

Motion must make state changes understandable, acknowledge input or clarify spatial relationships. It must not be an attention trap or make a task slower.

## 6.1 Runtime and workflow

- Preferred runtime candidate: Motion for React, subject to repository/dependency audit.
- Use CSS transitions for simple hover, focus and colour changes; do not add JavaScript animation for a simple CSS job.
- Transitions.dev may provide recipes, audit guidance or an AI-agent skill/MCP workflow. It is not automatically a second runtime library.
- Bencho and UI Feed may inform interaction ideas. Copying an effect requires source/licence review and adaptation to the PacketPulse motion tokens.

## 6.2 Motion tokens

| Token | Starting duration | Use |
|---|---:|---|
| `--motion-instant` | 100–120ms | Immediate pressed/selected feedback |
| `--motion-quick` | 120–180ms | Button, bookmark, toggle, check and icon feedback |
| `--motion-standard` | 160–240ms | Tabs, tooltip, toast, dropdown and small overlays |
| `--motion-emphasis` | 240–350ms | Drawers, expandable panels and card layout changes |
| `--motion-milestone` | 350–700ms | A meaningful achievement, assessment result or verification milestone |

Durations are starting values, not an excuse to animate everything. Prefer opacity and transform. Avoid `transition: all`; animate named properties. Do not animate expensive filters, large blur layers or continuously repainting backgrounds.

## 6.3 Approved interaction candidates

| Pattern | PacketPulse use | Guidance |
|---|---|---|
| Number subtle change / pop-in | KPI updates | Use for changed values, not every page load; keep data legible |
| Progress rail fill | File transfer, assessments and onboarding | Reflect real progress; do not fake completion |
| Spinner-to-check / success check | Save or verification completion | Use only after server confirms success |
| Skeleton-to-content crossfade | Dashboard/feed loading | Keep layout stable; no shimmer under reduced motion |
| Panel reveal | Contextual rail, drawer and details | Preserve focus and reading order |
| Sliding tabs | Feed views and analytics periods | Active state must remain understandable without motion |
| Avatar group hover | Participant preview | Desktop enhancement; mobile gets tap/click equivalent |
| Card resize | Expandable insight and dashboard panels | Do not reflow unrelated content abruptly |
| Toast open/close | Low-impact operation feedback | High-impact outcomes must persist on the page or in history |
| Error state | Form or upload failure | Use clear inline explanation; avoid aggressive shake |
| Feature tile hover | Editorial feature cards | Small lift/arrow shift; not 3D on every tile |

## 6.4 Reduced motion and accessible interaction

- Respect `prefers-reduced-motion: reduce` throughout the app.
- Under reduced motion, remove 3D rotation, parallax, shimmer, animated number drums, large scale transitions and decorative entry effects.
- Retain state changes, completion icons, progress values and status text.
- Never communicate state solely through animation.
- Do not auto-advance the featured carousel by default.
- Do not cause vestibular discomfort through pointer-driven 3D tilt or fast perspective movement.

---

# 7. Responsive and accessibility requirements

## 7.1 Responsive layout

- Use existing breakpoints from Document 2: 640, 768, 1024, 1280 and 1536px.
- Analytical Workspace: full sidebar and contextual rail at wide desktop; collapse the rail on smaller desktop/tablet; one-column layout on mobile.
- KPI strips wrap predictably; do not make users horizontally scroll to discover the first key metrics.
- Tables may become stacked records on small screens; keep essential fields and actions visible.
- File upload actions may wrap/stack; filename and status must remain visible.
- Carousels become swipeable horizontal tracks with a clear active item; no compulsory perspective effect.
- Numbered feature cards stack vertically on small screens; maintain sequence ordering.

## 7.2 Accessibility release checks

- WCAG 2.2 AA remains the release target.
- Keyboard access for every interactive control and composite widget.
- Visible focus indicator and logical focus order.
- Text labels accompany semantic colours and icons.
- Chart data has a text summary and table/list alternative.
- File progress and state updates are announced accessibly.
- Carousel supports keyboard, touch and reduced motion; avoid unexpected focus movement.
- Feature cards use semantic headings and links/buttons, not clickable generic containers without keyboard semantics.
- Calendar uses an accessible grid or equivalent date selection pattern and announces selected date.
- Test 200% zoom, narrow viewport, high contrast and screen-reader navigation.

---

# 8. Implementation guidance for Claude and developers

## 8.1 Repository-first rule

Before implementation, record:

- Next.js and React versions.
- Tailwind version and integration mode.
- Current shadcn `components.json` style and primitive family.
- Existing Radix/Base UI packages and component usage.
- Current chart, table, editor, upload, icon and motion dependencies.
- Existing component folders and aliases.
- Current light/dark theme implementation.
- Build, lint, typecheck, test and storybook/catalogue commands.

Do not install all candidate libraries. Choose one source for each required behaviour after this audit. Preserve existing working dependencies unless replacement is justified by a documented need.

## 8.2 Tailwind rule

Tailwind CSS v4 is the styling standard.

- Tailwind Play CDN may be used for throwaway prototypes, isolated demos or exploration.
- Do not use the browser Play CDN in production Next.js.
- Production uses compiled Tailwind CSS v4 through the app's build integration.
- Keep theme values in CSS variables / semantic theme tokens and map them to Tailwind utilities.
- Do not place raw hex values in page components or individual copied library components.

## 8.3 Suggested package decision matrix

| Need | First choice | Alternative / candidate | Install rule |
|---|---|---|---|
| Shared primitives | Existing shadcn setup | Base UI or Radix, according to repo | No primitive migration without audit |
| Dashboard ready-made blocks | BoardUI or Ingot UI | Beautiful UI | Use small selected components; verify licence and dark theme |
| Specialised component | shadcn registry | Bencho / Beautiful UI | Copy and review source into repo |
| Table behaviour | TanStack Table | Existing table package | Adopt only for advanced behaviour |
| Chart rendering | Existing chart package | Recharts | Use one chart renderer, not several |
| Animation | Motion for React | CSS transitions | One runtime motion engine; CSS for simple states |
| Motion recipes | Transitions.dev | Bencho examples | Guidance/source only; no duplicate runtime |
| Rich editor | Existing editor | Tiptap | Audit schema, security, collaboration and accessibility |
| Simple drag/drop | Native input / react-dropzone | Uppy | Uppy only for resumable/complex upload needs |
| Icons | Lucide | Simple Icons for vendor marks | Keep UI icon family consistent |
| Toasts | Existing toast system | Sonner | Avoid duplicate toast providers |

## 8.4 Component acceptance definition

A component is **Approved** only when:

1. It serves a named PacketPulse use case.
2. The source, licence and attribution conditions are recorded.
3. Dependencies are justified and compatible with the repository.
4. It uses Signal Grove semantic tokens in both supported themes.
5. Comfortable/Compact/Reading density is defined where applicable.
6. Loading, empty, success, disabled and error states are documented where relevant.
7. Keyboard, focus and screen-reader behaviour are tested.
8. Mobile/tablet behaviour is reviewed.
9. Reduced-motion behaviour is tested for animated components.
10. Visual regression and functional tests cover important states.
11. It has a stable PP component ID and catalogue page.
12. The owning module and maintainer are identified.

## 8.5 Suggested component folder structure

Adapt this to the existing repository; do not restructure it blindly.

```text
src/
  components/
    ui/                    # primitive controls and wrappers
    shared/                # cross-product PacketPulse components
    workspace/             # analytical/editorial layout compositions
    community/
    learning/
    recruitment/
    payments/
    operations/
  styles/
    tokens.css
    themes.css
    motion.css
  lib/
    component-utils/
    asset-provenance/
```

A component sourced from another registry should be reviewed, adapted and placed under a PacketPulse-owned name and API. Keep a source reference in the registry; do not leave product pages coupled directly to a third-party registry import if it would make future replacement difficult.

---

# 9. Delivery sequence

## Phase 0 — Audit and setup

- Complete repository/library audit.
- Confirm theme tokens and contrast results for Soft Signal Light and Matte Black.
- Confirm primitive family and Tailwind v4 integration.
- Set up or reuse the component catalogue (Storybook or equivalent).
- Create a source/licence review checklist and asset provenance register.

## Phase 1 — Shared foundation (P0)

Build/test:

- Application shell, sidebar, utility header and page header.
- Buttons, inputs, tabs, dropdowns, popovers, dialogs, drawers and toasts.
- Metric card, featured metric, chart panel, table and filter bar.
- Status badge, alerts, empty state, skeleton and progress indicator.
- File transfer and dropzone.
- Member card, question card, answer card and code block.

Deliver one representative Analytical Workspace page and one Editorial Workspace page using the shared components.

## Phase 2 — Supplied reference compositions (P1)

- PP-DASH-001 dashboard composition (Soft Signal Light and Matte Black variants).
- Calendar + agenda panel.
- People/contributor cards and avatar groups.
- Perspective featured carousel.
- Numbered editorial feature tiles.
- Rich technical composer and file preview.

## Phase 3 — Product-specific advanced patterns

- Verification Review Panel (manual, AI-assisted and automated experiment modes with evidence, reason, audit and appeal/re-review pathways).
- Community Health Panel.
- Knowledge Explorer/tree/graph.
- Recruitment candidate pipeline and review drawer.
- Learning pathway and assessment progress compositions.

## Phase 4 — Quality, feedback and expansion

- Run accessibility, responsive, performance and visual regression checks.
- Collect member/team feedback during the agreed review window.
- Record retain/refine/restrict/disable decisions in the next build log.
- Review component reuse, duplicate patterns, licences and bundle impact.

---

# 10. Acceptance checklist for the six visual references

## REF-01 Dashboard

- [ ] Four-card KPI strip or an appropriately sized 3–5 metric set.
- [ ] One featured KPI only where the data warrants emphasis.
- [ ] Clear page header and top utility controls.
- [ ] Main analytic panel has title, period, labels, summary and accessible data alternative.
- [ ] Calendar selected date and agenda are linked.
- [ ] People cards show useful professional context, not vanity metrics.
- [ ] Light and Matte Black token variants work.
- [ ] Tablet/mobile collapse rules are implemented.
- [ ] Whitespace and reading hierarchy are preserved.

## REF-02/03/04 Upload

- [ ] Queued, uploading, paused, processing, completed, failed, canceled and rejected states.
- [ ] Percentage/byte values reflect real upload events.
- [ ] Pause/resume appears only when the transport supports it.
- [ ] Cancel and remove are different actions.
- [ ] Change and Download appear only when meaningful and authorised.
- [ ] Server-side validation and file scanning are enforced.
- [ ] Accessible progress announcements and text/glyph status.
- [ ] Mobile action layout works without overflow.

## REF-05 Carousel

- [ ] Active item clearly distinguished.
- [ ] Adjacent-card preview is an enhancement, not required information.
- [ ] Keyboard, touch and button navigation work.
- [ ] No auto-advance by default.
- [ ] Reduced motion removes perspective/3D effects.
- [ ] Cards have clear accessible names and destination semantics.

## REF-06 Feature tiles

- [ ] Number sequence and title hierarchy consistent.
- [ ] Visual zones use relevant illustration/product imagery.
- [ ] Card colour variations remain within Signal Grove tokens.
- [ ] One clear action per card.
- [ ] Hover/focus are both visible and do not shift layout.
- [ ] Tiles stack in correct sequence on mobile.
- [ ] Reduced-motion behaviour is static and equally understandable.

---

# 11. Source references checked 25 November 2026

- [The Component Gallery](https://component.gallery/) — component and design-system pattern catalogue; [design-system index](https://component.gallery/design-systems/).
- [shadcn/ui](https://ui.shadcn.com/) — source-owned React/Tailwind component foundation and registry.
- [Base UI](https://base-ui.com/) — unstyled accessible React primitives.
- [Radix UI](https://www.radix-ui.com/primitives) — accessible unstyled primitives.
- [Ingot UI docs](https://ingotui.com/docs) and [licence](https://ingotui.com/license) — dashboard design systems, React/Tailwind components and terms.
- [BoardUI](https://www.boardui.com/) and [components](https://www.boardui.com/components) — React/Tailwind dashboard patterns.
- [Beautiful UI docs](https://beautiful-ui.dev/docs), [installation](https://beautiful-ui.dev/docs/installation) and [components](https://beautiful-ui.dev/components) — shadcn-compatible Notchset components and charts.
- [Bencho](https://bencho.dev/about) — interactive React UI components and micro-interactions; read the licence for individual free/Pro blocks.
- [Transitions](https://transitions.dev/), [MCP](https://transitions.dev/mcp.html) and [skill](https://transitions.dev/skill) — transition recipes, motion checks and agent workflows.
- [Browsable](https://browsable.dev/) — owner-supplied plain-language component discovery reference; verify availability before workflow integration.
- [UI Feed](https://ui-feed.dev/) — live interface inspiration and interaction examples.
- [Polymode Sans](https://polymodesans.com/) — variable display typeface with Realness axis; confirm early-access licence.
- [Deimos](https://deimos.evilrabbit.com/) — design encyclopedia / designer reference.
- [Motion for React](https://motion.dev/docs), [Lucide](https://lucide.dev/), [Simple Icons](https://simpleicons.org/), [TanStack Table](https://tanstack.com/table/latest), [Recharts](https://recharts.org/), [Tiptap](https://tiptap.dev/), [Uppy](https://uppy.io/), [react-dropzone](https://react-dropzone.js.org/).
- [Tailwind Play CDN](https://tailwindcss.com/docs/installation/play-cdn) — prototype-only; production builds compile Tailwind CSS.
- [Unsplash licence](https://unsplash.com/license), [Pexels licence](https://www.pexels.com/license/), [unDraw licence](https://undraw.co/license), [LottieFiles licence](https://lottiefiles.com/license), [Rive terms](https://rive.app/legal/terms/).

**External details change.** Recheck current version compatibility, pricing, source availability, licence and maintenance status when a developer actually adopts a component. The repository lockfile and package docs are the final technical source of truth.

# 12. Resources, Signup, Profile and Account component specifications

**Owner disposition:** all patterns and components in this section are **Approved Prototype** for the next review build. The design team has explicit creative freedom to explore colour, composition, image treatment and microinteraction variants. The selected variants must be reviewed for contrast, accessibility, responsiveness, licensing and fit with Signal Grove before becoming production standards.

## 12.1 Resources Library composition — PP-RES-001

**Purpose:** Make Community Resources feel like a curated engineering knowledge library rather than a folder of downloads.

**Desktop composition:** grouped Community sidebar; utility header/global search; breadcrumb; Resources title and one primary Share a resource action; optional featured collection/hero; discovery tabs (For you, Featured, Recent, Popular, Staff Picks); a filter/sort row; primary resource-card grid; optional contextual rail for popular topics, recently added and continue reading. Keep 24–32 px between major groups and let the card grid breathe. A compact view may exist for power users, but Comfortable is default.

**Resource card anatomy:** format icon/thumbnail; title; concise value statement; technology/category chips; source/author; difficulty and estimated time; updated/reviewed date; save control; optional trust/review status. Do not invent ratings or review states. Show a clear external-link cue for off-platform resources.

**Creative variants approved for prototype:** featured collection with editorial illustration; photo/diagram-led collection tiles; dense list mode; resource type colour accents; soft forest/teal gradient wash on one featured surface; muted technical thumbnails. Keep type/status colours semantically clear. Avoid making every card bright or illustrated.

## 12.2 Resource detail and reader — PP-RES-002 / PP-RES-003

**Primary region:** document/PDF/video/article preview. **Left or inline rail:** thumbnails/page navigation or article table of contents. **Right contextual rail:** resource details, tags, difficulty, estimated time, version, last reviewed, source, author, licence/attribution and save/share/report actions. Related resources and community discussion sit below or in a secondary tab; do not compete with reading.

For document preview, show page number, zoom, fit-to-width, download/open and accessible text alternative where available. For video, show captions/transcript when available. For articles, use Reading density, narrow line length and section anchors. External destinations must be identified before opening. The viewer must fail gracefully when preview is unsupported and offer a safe open/download alternative if permission allows.

## 12.3 Share Resource wizard — PP-RES-004 / PP-RES-005

Use a visible three-step stepper: **Details → Content → Review & publish**. Allow Back, Save draft and resume. Details fields: title, short description, resource type (Guide, Documentation, Tool, Template, Course, Video, Cheat sheet, Lab, Repository, Article), category, canonical technology tags, difficulty, intended audience, language and estimated time (if known). Content source: upload file, paste URL or write article. Review fields: author/source, attribution, licence/usage rights, version, last reviewed, visibility and guidelines acknowledgement.

Preview the resource as a recipient will see it. Show validation inline. Upload cards use `PP-UPLOAD-001` and all real lifecycle states. Scan, link validation and rights/attribution checks must be visible. A completed upload is not the same as a published resource. If a resource requires moderation, show “Submitted for review” and let the contributor track status.

## 12.4 Saved resources and collections — PP-RES-006

Tabs: All saved, Reading list, My collections, Recently viewed. Cards may use the perspective carousel pattern only for curated featured collections; the user's full saved library should remain a sortable list/grid. Collection metadata: name, description, cover/representative resource, count, visibility, last updated. Resource status: Saved, Not started, In progress, Completed where measurable. Resume reading at last position only when the source and permissions support it. Unsave never deletes the canonical resource.

## 12.5 Signup and email verification — PP-ID-001 to PP-ID-004

**Signup composition:** split-screen on wide desktop. One side carries PacketPulse's promise, a restrained network/engineering motif and concise trust copy; the other side contains the account form. Avoid overly large marketing copy or moving decorative graphics. On mobile, use a single-column form. Support email/password or passkey as the core path. Google/GitHub buttons are prototype-approved; the real identity provider is enabled only when configured and tested. If mocked, label it as a prototype action and never create a false authenticated state.

Form components: email, password with visibility toggle, password guidance, terms/privacy consent, create account action, existing-account sign-in, provider options and recovery route. Email verification uses a 6-digit code with expiry, resend cooldown, attempt-limit feedback and change-email action. Focus moves to the code field; paste of the full code is supported; announce errors accessibly.

## 12.6 Personalised onboarding — PP-ID-005 to PP-ID-007

A progress stepper guides **Role → Interests → Goals**. Role cards: Student, Engineer, Specialist, Mentor, Recruiter. Interests use canonical skill taxonomy tokens and searchable multi-select chips; allow custom suggestions through taxonomy workflow rather than silently creating taxonomy entries. Goals: Learn, Practice, Contribute, Mentor, Find opportunities. Optional steps may be skipped. Show “You can change this later”. Completion configures starting recommendations, not permissions or recruiter visibility.

## 12.7 Professional Profile — PP-ID-008 to PP-ID-012

The profile identity hero includes avatar, name, professional headline, optional location/timezone, short introduction and Edit Profile action. Banner/cover artwork may use a subtle network motif or member-selected image; avoid decorative data panels that compete with identity. Show verification labels with explicit type. The profile uses tabs/sections: Overview, Skills, Experience, Education & Certifications, Contributions, Learning, Mentoring, Activity and Achievements, rendered only when relevant data exists.

Skills are grouped by evidence state: Self-declared; Assessment verified; Experience verified; Certification verified; PP verified. Each verified state opens an explanation of evidence, issuer/reviewer, criteria, date, expiry and appeal path where permitted. Community contribution reputation is shown separately from verified skills. Profile completeness guidance is optional, dismissible, useful and non-judgmental. An identity timeline is optional and member-controlled.

## 12.8 Visibility Preview — PP-ID-013

Preview selector: My view, Community member view, Recruiter after forwarding. The implementation must call the same audience/field-level visibility rules used by the actual backend; it must not construct a front-end-only approximation. Hidden fields show a brief “Only you can see this” reason where useful. Date of birth, compensation, private notes and resume links follow DEC-015 and consent. Public web preview remains off by default and must not be implied by Community preview.

## 12.9 Account Control Centre — PP-ACC-001 to PP-ACC-006

The Account Settings overview uses spacious grouped cards with clear category descriptions and direct edit/Manage actions. Categories: Personal Information; Profile Visibility; Notifications; Login & Security; Sessions; Connected Accounts; Privacy & Data Rights; Billing & Payments when relevant. Individual detail screens use clear sections and save feedback.

Security page: password/passkey and MFA status, recovery options, active sessions, sign out other sessions, security events. Connected Accounts: provider icon, connected identity, status, requested scopes and unlink action. Prevent unlinking the last viable recovery route; step-up where required. Privacy/Data Rights: consents, export request, erasure request, request status and retained-data explanation. Deletion belongs in a distinct danger zone with consequences, re-authentication and explicit confirmation.

## 12.10 Component registry additions

| ID | Component | Main variants / states | Source inspiration | Review-build status |
|---|---|---|---|---|
| PP-RES-001 | Resource discovery hero and featured collection | Editorial, diagram-led, compact, no-image | REF-08, Component Gallery, BoardUI/Bencho patterns | Approved Prototype |
| PP-RES-002 | Resource card | Guide, PDF, tool, video, course, repo, article; saved/unsaved; reviewed/unreviewed | shadcn, BoardUI, Beautiful UI | Approved Prototype |
| PP-RES-003 | Resource reader/detail shell | Document, article, video, external link; rails collapsed/expanded | shadcn, Base UI/Radix, existing viewer audit | Approved Prototype |
| PP-RES-004 | Resource submission stepper | Details, Content, Review; draft/error/complete | shadcn, Transitions | Approved Prototype |
| PP-RES-005 | Resource rights and attribution block | Licence, source, author, version, warning | PacketPulse-owned composition | Approved Prototype |
| PP-RES-006 | Saved collection and reading state | Private/shared, progress, recently viewed | BoardUI, Bencho | Approved Prototype |
| PP-ID-001 | Split signup layout | Desktop split, mobile single-column, light/dark | PacketPulse-owned composition | Approved Prototype |
| PP-ID-002 | Provider sign-in buttons | Google, GitHub; configured/mock/disabled | shadcn, Lucide / provider brand icons | Approved Prototype |
| PP-ID-003 | Email verification code input | Empty, partial, complete, expired, retry | shadcn, accessible input primitive | Approved Prototype |
| PP-ID-004 | Onboarding stepper | Role, Interests, Goals; skippable optional step | Transitions, shadcn | Approved Prototype |
| PP-ID-005 | Role selection cards | Single-select, selected, disabled | BoardUI, Bencho patterns | Approved Prototype |
| PP-ID-006 | Interest and taxonomy selector | Search, multi-select, selected chips, suggested tag | Bencho, shadcn | Approved Prototype |
| PP-ID-007 | Goal selector | Multi-select cards/chips | PacketPulse-owned composition | Approved Prototype |
| PP-ID-008 | Profile identity hero | Avatar, cover, headline, location, edit | BoardUI, Component Gallery | Approved Prototype |
| PP-ID-009 | Verification-aware skill group | Self-declared, assessment, experience, certification, PP verified | PacketPulse-owned semantics | Approved Prototype |
| PP-ID-010 | Contribution summary | Solved, useful answers, articles, mentoring | BoardUI, Bencho | Approved Prototype |
| PP-ID-011 | Profile visibility preview switcher | Self, Community, Recruiter-after-forwarding | PacketPulse-owned composition | Approved Prototype |
| PP-ID-012 | Profile completeness helper | Suggested actions, dismissed, completed | PacketPulse-owned composition | Approved Prototype |
| PP-ID-013 | Identity activity timeline | Verified skill, assessment, contribution, mentoring milestones | BoardUI timeline patterns | Approved Prototype |
| PP-ACC-001 | Account settings hub | Spacious category cards, status and quick actions | BoardUI, shadcn | Approved Prototype |
| PP-ACC-002 | Settings section card | Default, hover, focus, warning, disabled | shadcn, Ingot UI patterns | Approved Prototype |
| PP-ACC-003 | Notification preference matrix | Event/channel choices, quiet hours, digest | PacketPulse-owned composition | Approved Prototype |
| PP-ACC-004 | Security and session list | Current session, active/expired, revoke, step-up | shadcn, Base UI/Radix | Approved Prototype |
| PP-ACC-005 | Connected account row | Connected, unlinked, issue, unlinking, last-recovery warning | PacketPulse-owned composition | Approved Prototype |
| PP-ACC-006 | Data rights and danger zone | Export, consent, erase request, pending/completed | PacketPulse-owned composition | Approved Prototype |

## 12.11 Creative exploration board

The following variants are explicitly approved for prototype exploration; they are not all required to coexist in one final screen:

- Matte Black resource library with teal/forest hero surfaces and restrained lime actions.
- Soft Signal Light resource discovery with editorial photography or technical diagrams.
- High-contrast file-type accents with semantic text labels, not colour-only identification.
- Perspective featured carousel for selected collections, mentor spotlights or events; static list/grid remains the accessible fallback.
- Numbered feature/step cards for onboarding and learning pathways.
- More expressive display typography (including Polymode Sans experiments) for marketing/editorial headings; Inter remains the baseline for dense product UI.
- Alternate identity hero treatments, cover art and contribution layouts.
- Profile completeness and activity timeline as optional cards that can be individually disabled.

Each variant should state its user hypothesis, audience, expected benefit, risks and measurement. The team may remove a variant in the following build if it does not improve clarity, confidence, usefulness or emotional quality.


# 13. Revision history

| Date | Version | Changes |
|---|---:|---|
| 26 Nov 2026 | 1.7 | Corrected source reference filenames/IDs to owner bundle REF-00..REF-06; expanded open creative direction; reaffirmed transparent overlay-only pattern scope and broad colour exploration |
| 26 Nov 2026 | 1.6 | Added Resources, Signup, Profile and Account components; expanded media, nested UX, WaveSurfer and brand-pattern families |
| 25 Nov 2026 | 1.5 | Added detailed community, identity, resource and component ecosystem specification |
| 25 Nov 2026 | 1.3 | Added media/recording stack, uploads, file previews, safe embeds, nested route patterns and initial PacketPulse motif library |

# 14. Media, recordings and embedded-file ecosystem

This section is an Approved Prototype specification, researched against official project documentation available on 26 November 2026. It is a recommended architecture for review, not proof of package installation or production approval. Repository compatibility, exact versions, transitive dependencies, security and licence terms must be checked before adoption.

## 14.1 Recommended stack

| Layer | Preferred candidate | Why it fits | Review notes |
|---|---|---|---|
| React playback | **Video.js 10 — `@videojs/react` (10.7.0 researched 26 Nov 2026)** | Stable v10 release; React-first, TypeScript and Tailwind patterns; player UI can be composed and branded; supports direct media and provider/stream integrations | Use only required adapters; v10 is a rewrite, not a drop-in v8 upgrade. The npm `video.js` package may still refer to v8; use the v10 framework package shown in official docs |
| Advanced streaming alternative | **Shaka Player** | HLS/DASH adaptive playback and specialist offline/EME capabilities | Separate alternative, not another default dependency. Evaluate only if DRM/offline/advanced stream requirements justify it |
| Upload UI | **Uppy React headless/hooks** | Modular, MIT-licensed uploader with React integration and custom UI composition | Use headless/hooks for PacketPulse styling; Dashboard is useful for prototypes or a quick baseline |
| Resumable transport | **Tus (`@uppy/tus`) and compatible server such as tusd** | Protocol-based pause/resume across interrupted networks; suitable for large recording uploads | Needs an actual client/server implementation and storage integration; verify existing backend before adding server infrastructure |
| Audio waveform visualisation | **WaveSurfer.js 8.1.0** | Interactive waveform, regions, timeline, hover and record plugins for audio-only recordings | Optional visual layer, not a replacement for Video.js; BSD-3-Clause; large/streamed assets may need pre-decoded peaks |
| PDF preview | **React-PDF + PDF.js** | React-friendly PDF rendering; MIT wrapper; Mozilla PDF.js viewer/renderer ecosystem | Test large files, worker configuration, text/annotation layers, SSR and memory on mobile |
| Office preview | **Isolated conversion to PDF** or separately licensed provider | One consistent reader UX and avoids blindly embedding office files | If considering ONLYOFFICE Community Edition, AGPLv3 obligations for SaaS/proprietary integration and branding restrictions need legal review; compare Developer/Commercial licensing |
| Media processing | **FFmpeg candidate** | Thumbnail extraction, metadata, audio/video transcode and HLS renditions | FFmpeg is LGPL by default with optional GPL parts; build flags/codecs may change obligations. Patent/licence review is required; do not assume all prebuilt binaries have the same licence |

**Current-version note:** Video.js official changelog lists v10.7.0 on 24 November 2026. Video.js 10.0.0 became generally available on 1 October 2026. Official v10 documentation lists first-class React, TypeScript and Tailwind support, and source support including HLS, DASH, YouTube, Vimeo, Mux and Cloudflare Stream. HLS/DASH playback engines are selectable adapters, so do not install every adapter by default.

## 14.2 Content/source type resolver

Build one PacketPulse `MediaResource` resolver that reads server-approved metadata and chooses the appropriate viewer. Do not rely only on a filename extension and do not pass arbitrary markup to a browser renderer.

- **Direct video/audio:** native source where suitable; Video.js 10 custom UI.
- **HLS/DASH:** Video.js with the matching adapter; test browser-native HLS path and supported MSE path.
- **External providers:** provider-specific adapter/embed from a server-validated canonical provider ID.
- **PDF:** React-PDF/PDF.js reader.
- **Images:** optimised image viewer with zoom, alt text and download permission.
- **Text/Markdown/code:** safe internal reader; syntax highlighting for code; sanitised Markdown; no arbitrary HTML.
- **CSV/tabular:** bounded, virtualised preview; do not execute formulas, macros or external references.
- **Office:** safe isolated conversion/preview or commercial editor after licensing/security decision.
- **Archive/executable/unknown:** metadata and permission-aware download only; never inline execute.

## 14.3 PacketPulse player experience

A player composition can include: branded poster/thumbnail, play/pause, seek bar, current time/duration, volume, playback rate, quality selection where the source supports it, captions/subtitles, transcript, chapters, fullscreen, Picture-in-Picture where supported, source/provider label, error/retry and resume. Use controls appropriate to the source; hide unavailable controls rather than rendering fake capability.

Recording details may combine a video stage with a chapter list, transcript/search, resource metadata, author/source, notes, related resources and discussion. Desktop can use a contextual rail; tablet may collapse it; mobile should turn it into tabs or sheets. Keep the player responsive and let users enter a focused/theater mode without losing the resource parent context.

**Accessibility:** captions/subtitles and transcripts are first-class. Show whether captions are human-reviewed, generated or unavailable. Keyboard operation, visible focus, accessible labels, audio descriptions where available, playback speed, transcript links and reduced-motion support should be part of acceptance testing. Avoid autoplay with sound. Respect user preferences and provider policies.

## 14.4 Upload experience and processing states

The upload component should have both a compact inline card and an expanded manager. Required states: idle, selected, validating, queued, uploading, paused, resuming, retrying, interrupted, complete, scanning, quarantined, processing, preview-ready, failed, cancelled and rejected. Show per-file progress, aggregate progress, size, time remaining only when meaningful, retry reason, pause/resume/cancel, remove/replace and processing steps. Do not claim completion before the server confirms it.

Use Uppy headless components/hooks to build a PacketPulse-owned UI. Use Tus where compatible for resumability. Store binary files in object storage, metadata in PostgreSQL, and expose short-lived signed URLs. Scan and validate before publication. Thumbnail/transcode jobs run in isolated workers and should be idempotent.

## 14.5 External provider and file security

- Accept only HTTPS and an approved provider list for embeds.
- Normalise URLs and resolve canonical provider IDs server-side.
- Do not store/render raw user-supplied iframe or HTML.
- Apply CSP `frame-src` only for providers actually enabled; check `postMessage` origin; use iframe sandbox and permission policies as compatible with provider requirements.
- Protect server-side URL resolvers against SSRF, private IPs, loopback, link-local addresses, unsafe redirects and DNS rebinding.
- Validate MIME/signature, file size, extension policy and ownership; scan files and quarantine suspicious ones.
- Process files in isolated workers with limits; never execute macros, scripts or archive contents in the application origin.
- Preserve attribution, licence, source and takedown status.

## 14.6 Source links and licence cautions

- Video.js v10 GA announcement: https://videojs.org/blog/videojs-10
- Video.js changelog: https://videojs.org/changelog
- Video.js React install: https://videojs.org/docs/guides/installation/react
- Video.js HTML source/adapter selection: https://videojs.org/docs/guides/installation/html
- Video.js HTTP Streaming (HLS/DASH): https://github.com/videojs/http-streaming
- Shaka Player: https://github.com/shaka-project/shaka-player
- Uppy React: https://uppy.io/docs/react/
- Uppy Tus: https://uppy.io/docs/tus/
- Tus reference server: https://tus.github.io/tusd/
- React-PDF: https://github.com/wojtekmaj/react-pdf
- WaveSurfer.js official documentation and source: https://wavesurfer.pages.dev/docs/ · https://github.com/katspaugh/wavesurfer.js (optional audio waveform layer; BSD-3-Clause; use pre-decoded peaks for large/streamed files)
- ONLYOFFICE Community licence FAQ: https://helpcenter.onlyoffice.com/docs/installation/community/faq
- FFmpeg licence guidance: https://ffmpeg.org/legal.html

# 15. Parent-child, nested and contextual screen patterns

Nested UI should feel like an understandable journey through a workspace. A parent page remains the user's anchor; child screens should make it easy to understand where they came from, why this child exists and how to return.

## 15.1 Navigation composition options

| Pattern | Best for | Behaviour |
|---|---|---|
| Parent page + child route | Full detail pages, readers, editors, complex forms, settings pages | URL is shareable; browser Back/Forward works; breadcrumb and local nav persist |
| Route-backed drawer/sheet | Inspecting a candidate, resource, member or queue item while retaining list context | URL identifies selected item; close/back restores parent filters, scroll and focus |
| Inline expansion | Small supplementary detail, lightweight explanation, row preview | No new modal stack; keyboard and screen-reader relationship is clear |
| Split workspace | Complex review queues, resource moderation, candidate assessment | Parent list and child details can coexist on wide viewports; collapses to route/sheet on mobile |
| Multi-step child workflow | Signup, share resource, verification, account security | Step state is visible; progress is recoverable; user can go back without losing valid input |

## 15.2 State and orientation model

A nested view should preserve, as appropriate: parent route, child route/record, active tab, search, filters, sort, selected rows, scroll location, draft state and keyboard focus. Use the URL for durable/shareable state and application state for transient UI. Do not put private personal data in URL query strings. Browser Back/Forward must match the visible screen. Deep links must repeat server-side permission checks.

Use breadcrumbs when they meaningfully help orientation, not merely because a page is nested. A clear back link, section heading or context label can be better on a short flow. On mobile, substantial children generally become their own full-screen route with an obvious back action; desktop drawers should not become tiny mobile dialogs for long-form content. Avoid modal-on-modal.

## 15.3 Shared nested-screen components

- `WorkspaceShell`: global sidebar, top bar and global utilities.
- `SectionNav`: module-specific navigation and tabs.
- `PageContextHeader`: parent name, breadcrumb/back, title, description and actions.
- `NestedRouteFrame`: shared child page structure and route transition.
- `ContextDrawer`: route-aware detail/preview panel.
- `MasterDetailWorkspace`: list/queue + detail pane.
- `ChildStepFlow`: resilient stepper for multi-stage actions.
- `ReturnContext`: restores parent filters, row selection, scroll and focus.
- `MobileChildHeader`: visible back path and child title.

# 16. PacketPulse brand-pattern library (open creative direction)

These motifs are a reusable starting vocabulary, not a closed or mandatory list. Patterns, palettes, layout and motion are open to experimentation; the registry should grow when a new idea earns its place. Designers may invent new motifs, blend families and adapt them to new content types. The key requirement from the owner is that these are **patterns/overlays, not background replacements**: keep the current surface, add the pattern as a separate transparent layer, and remove it where it competes with the information.

## 16.1 Pattern families

| ID | Pattern family | Visual language | Example places |
|---|---|---|---|
| PP-PAT-001 | Packet Routes | Orthogonal paths, packet squares, branching routes and highlighted hops | Resource cards, feature cards, section headers, network guides |
| PP-PAT-002 | Node Constellation | Connected nodes, varied node size, sparse/dense meshes | Community, member identity, groups, knowledge graph |
| PP-PAT-003 | Signal Waves | Sine waves, overlapping wave bands, amplitude variation | Recording cards, learning progress, media features, brand storytelling |
| PP-PAT-004 | Pulse Trails | A travelling pulse, short bright streaks, repeated signal markers | Status moments, loading, live recording indicators, activity summaries |
| PP-PAT-005 | Radar Echo | Concentric arcs, sweep lines, radial pings and detection points | Discovery, analytics, monitoring and empty states |
| PP-PAT-006 | Secure Layers | Nested hexagons, shield contours, segmented boundaries | Verification, identity, permissions and resource safety |
| PP-PAT-007 | Data Flow | Curved streams, dotted particles, multi-colour paths | Learning, featured collections, resource discovery and hero overlays |
| PP-PAT-008 | Packet Matrix | Repeating dots, squares, modular grid and occasional highlighted cells | Card corners, dashboards, profile sections and subtle surface overlays |

## 16.2 Colour and material exploration

Use the existing Signal Grove tokens as a starting point, not a fence. Forest/eucalyptus/lime can coexist with Learning indigo, Recruitment blue, Payments plum, slate information, amber, red, cyan, azure, violet, coral and new experimental accents when a clear role is found. Try single-colour linework, dual-tone routes, multi-hue data waves, tonal monochrome, gradient nodes and unexpected-but-readable combinations. Pantone may be used as a reference system during brand/print exploration; record the actual guide, edition, substrate/coated/uncoated reference and mapped digital values when confirmed. Do not invent Pantone numbers or imply an exact match from HEX alone.

## 16.3 Pattern component behaviours

Every motif may have several variations: sparse/dense, thin/bold, cropped/full, static/animated, monochrome/multicolour, calm/expressive and light/dark. These are exploratory variants, not required presets for every component. Provide token overrides for main stroke, secondary stroke, highlight, opacity, blend mode and scale. Prefer inline SVG/React components or CSS-generated vector shapes where theme tokens must flow into the asset. Avoid a full-page raster wallpaper where a transparent vector overlay would do.

Use patterns on card headers, card corners, hero overlays, profile covers, resource features, onboarding accents, media progress, section dividers, empty states and branded moments. A card can use an image, pattern, colour block or no decoration depending on its content. The absence of a pattern is also a valid design choice.

## 16.4 Motion ideas

Waves may gently travel; a packet may move along a route; a pulse may radiate from a node; a radar arc may sweep; a shield outline may resolve into focus; a data field may subtly drift. Motion can support brand recognition, atmosphere or communicate state. Explore ambient movement where it adds life; tune it to the context and preserve comfortable reading/task completion. Respect reduced-motion and offer a static alternative. Avoid movement that competes with text or obscures controls.

## 16.5 Initial asset library

`references/brand-patterns/` contains source SVG prototypes for the first eight families. They have no background rectangle and are intended to be embedded inline or converted into React components so CSS variables can theme them. Use these as seed assets; designers can evolve, combine or replace them.

# 17. Component ecosystem registry additions

| ID | Component | Variants / states | Preferred source or inspiration | Review-build status |
|---|---|---|---|---|
| PP-MEDIA-001 | Branded media player shell | Video/audio, compact/full, light/dark, theater, loading/error | Video.js 10 + PacketPulse skin | Approved Prototype |
| PP-MEDIA-002 | Recording/resource media card | Thumbnail, duration, provider, caption flag, progress, saved | PacketPulse composition, BoardUI patterns | Approved Prototype |
| PP-MEDIA-003 | Player controls | Play, seek, volume, speed, quality, captions, fullscreen, PiP when supported | Video.js 10 components adapted to Signal Grove | Approved Prototype |
| PP-MEDIA-004 | Transcript and chapter panel | Searchable transcript, timestamp jump, language, generated/reviewed status | PacketPulse composition | Approved Prototype |
| PP-MEDIA-005 | Approved embed frame | Provider label, consent, unavailable/restricted states | Video.js providers + PacketPulse security wrapper | Approved Prototype |
| PP-MEDIA-006 | Media/file fallback panel | Unsupported, unavailable, blocked, offline, expired access | PacketPulse composition | Approved Prototype |
| PP-MEDIA-007 | Audio waveform and timestamp region | Waveform, playhead, regions, markers, transcript jump, loading/fallback | WaveSurfer.js + PacketPulse audio controls | Approved Prototype |
| PP-FILE-001 | PDF reader | Page navigation, zoom, search, text/annotation layers | React-PDF / PDF.js | Approved Prototype |
| PP-FILE-002 | Image/document preview | Fit, zoom, alt text, download permission | PacketPulse composition | Approved Prototype |
| PP-FILE-003 | Code/text/CSV preview | Syntax, copy, line numbers, bounded/virtualised table | PacketPulse + existing code library audit | Approved Prototype |
| PP-UPLOAD-002 | Upload manager | Queue, pause/resume/retry/cancel, scan/process/publish states | Uppy headless + Tus | Approved Prototype |
| PP-NEST-001 | Page context header | Breadcrumb/back, parent label, child title and actions | shadcn/Radix or Base UI | Approved Prototype |
| PP-NEST-002 | Route-backed contextual drawer | Detail preview, query state, return focus | Base UI/Radix + Next.js routing | Approved Prototype |
| PP-NEST-003 | Master-detail workspace | List/queue + child pane, collapsed/mobile route | PacketPulse composition | Approved Prototype |
| PP-NEST-004 | Return-context controller | Parent filters, scroll, selection and focus restore | PacketPulse route/state layer | Approved Prototype |
| PP-PAT-001 | Packet Routes pattern | Sparse/dense, multi-colour, static/pulse | PacketPulse-owned SVG | Approved Prototype |
| PP-PAT-002 | Node Constellation pattern | Sparse/dense, connected/disconnected, animated nodes | PacketPulse-owned SVG | Approved Prototype |
| PP-PAT-003 | Signal Waves pattern | Single/multi-wave, amplitude and gradient variants | PacketPulse-owned SVG/CSS | Approved Prototype |
| PP-PAT-004 | Pulse Trails pattern | Routed pulses and node highlights | PacketPulse-owned SVG/CSS | Approved Prototype |
| PP-PAT-005 | Radar Echo pattern | Rings, sweep and pings | PacketPulse-owned SVG | Approved Prototype |
| PP-PAT-006 | Secure Layers pattern | Hex/shield contours and line variants | PacketPulse-owned SVG | Approved Prototype |
| PP-PAT-007 | Data Flow pattern | Curved streams and particle field | PacketPulse-owned SVG/CSS | Approved Prototype |
| PP-PAT-008 | Packet Matrix pattern | Modular dots and grid cells | PacketPulse-owned SVG/CSS | Approved Prototype |

# 18. Creative design and experiment governance

The component ecosystem is an invitation to build a distinct PacketPulse interface, not to collect libraries or freeze one visual style. External patterns can be studied, combined and adapted. New internal components can be created where they improve clarity or character. A component can be replaced when a better accessible implementation appears. Track the source, licence, version and adaptations, but do not let source-library defaults overrule the PacketPulse experience.

For any meaningful design experiment record: hypothesis, target journey, component/pattern variant, accessibility/performance risks, reference asset, feedback window, evidence, and next-build decision. An item labelled Approved Prototype must be included in the review build or visibly represented with a mock/sandbox state where integration is not ready. The team can later Retain, Refine, Restrict or Remove it. Production approval remains separate.



# Appendix B — Review build update summary and design discussion records

# PacketPulse 2.0 — Update Summary 5.7

**Issued:** 26 November 2026  
**Status:** Approved Prototype Review Build; not production approval.

## What changed

The five canonical documents now include the Resources and Identity work from 25 November plus the media/recording, nested UX and brand-pattern direction from 26 November. Design guidance is intentionally flexible: Signal Grove provides coherence but does not prohibit experimentation.

### New product experience

- Recordings/media with a branded player, transcript, captions, chapters, progress/resume and provider/source attribution.
- Type-aware previews for PDF, images, audio/video, code/text/Markdown and safe tabular data; office formats use isolated conversion or an approved/licensed editor.
- Upload manager with accurate progress, pause/resume/retry/cancel, scanning, processing and moderation states.
- Parent/child navigation with route-aware detail, contextual drawer, breadcrumbs, browser history and state restoration.
- Brand pattern system of transparent SVG/inline overlays, independent of the existing background.

### Preferred open-source ecosystem for prototype

- Video.js 10 (`@videojs/react`, 10.7.0 researched 26 Nov) for the primary player.
- Uppy React headless/hooks + Tus for resumable uploads.
- React-PDF/PDF.js for PDF viewing.
- Shaka Player as a specialist alternative, not a second default player.
- FFmpeg as a possible server-side processing option, subject to build/licence/patent review.
- ONLYOFFICE Community is not an automatic choice due AGPLv3 implications for SaaS/proprietary use.

### Brand patterns

Packet Routes; Node Constellation; Signal Waves; Pulse Trails; Radar Echo; Secure Layers; Data Flow; Packet Matrix. The catalogue is open-ended. Use existing tokens and explore wider colour combinations; do not repaint backgrounds to apply a pattern.

## Canonical document versions

| Document | Version |
|---|---:|
| 1. Product Guide | **5.5** |
| 2. Design System and UX Guide | **4.5** |
| 3. Users, Screens and Page Flows | **3.6** |
| 4. Delivery Plan and Developer Handoff | **4.6** |
| 5. Component Ecosystem, UI Patterns and Library Registry | **1.7** |

## Important

The codebase and package manifest were not available for audit in this documentation task. Proposed packages are not installed by this update. Production adoption requires repository compatibility, licence/security review, provider configuration and acceptance tests.

The cross-chat scan was limited to material available in the active workspace for 24–26 November 2026. Separate chat transcripts not present in the workspace are not represented.

- Added WaveSurfer.js as an optional audio waveform/regions layer beside the primary Video.js player; added DB/API/task/test traceability.
- Reframed design principles as flexible guidance; broadened palette exploration and added DES-022 to DES-030.
- Restored Resource/Identity DB-041..050 and API-061..068, and media DB-051..056 and API-069..077, with cross-document traceability.

- Restored Resource/Identity data/API traceability and allocated separate media API IDs 069–077.


## 26 November owner clarification — creative freedom

Design guidance is not a hard visual rulebook. Explore broad token colours, module accents, new colour stories, gradients, Pantone-referenced studies, typography, waves, pulses, patterns, microanimations and new compositions. The existing background is not changed for the current brand-pattern exercise; patterns are reusable transparent overlays. Pattern families may expand or be replaced.

### Media stack additions/refinements

- Video.js 10 (`@videojs/react`) is the preferred general player candidate.
- WaveSurfer.js 8.1.0 is optional for audio-only waveform/timeline interaction; standard audio controls remain available.
- Uppy headless/hooks + Tus for resumable uploads, React-PDF/PDF.js for PDFs, secure provider-specific embed handling and isolated/licensed Office preview.
- Parent/child layouts may use route pages, route-backed drawers, split workspaces, sheets or inline expansion according to the task and viewport.

### Current versions

| Document | Version |
|---|---:|
| Product Guide | **5.5** |
| Design System and UX Guide | **4.5** |
| Users, Screens and Page Flows | **3.6** |
| Delivery Plan and Developer Handoff | **4.6** |
| Component Ecosystem, UI Patterns and Library Registry | **1.7** |

## Owner clarification — 26 November 2026

Creative direction is open-ended and experimental, not a rigid aesthetic rulebook. Use the whole token palette and explore new colourways, gradients, Pantone-referenced studies, waves, pulses, patterns, layouts and components. The current pattern task is transparent overlays only; preserve existing backgrounds.


Owner design clarification (26 Nov): Be creative and experimental; use the wider token palette and explore new colourways. Waves and pulses are welcome. For the current pattern work, keep existing backgrounds unchanged and use optional transparent overlays.


# PacketPulse 2.0 — Discussion Record: Open Creative Direction and Pattern Overlays

**Date:** 26 November 2026  
**Scope:** Brand identity, design-system flexibility, reusable visual motifs and pattern assets  
**Status:** Owner-confirmed direction; included in Approved Prototype review scope  

## 1. Owner direction

The design system must not become a rigid visual rulebook. The owner wants the team to be creative, experimental and proactive about improving the complete product experience. Existing examples, recommended libraries, named pattern families and sample colours are starting points. They do not define the full boundary of what PacketPulse may explore.

## 2. Colour direction

- Use the complete Signal Grove brand, module and semantic token system.
- Do not make every motif or component green. Forest/eucalyptus/lime are useful brand colours, but indigo, blue, plum, violet, cyan, azure, amber, coral, red, neutrals, tonal ramps and new combinations may be explored.
- Experiment with single-colour linework, two-tone routes, multi-hue waves, gradient nodes, spectrum treatments and other expressive but legible colour stories.
- Pantone references may inform brand and print exploration. Record an official Pantone guide/edition and coated/uncoated reference only when verified; do not invent PMS numbers or infer a precise Pantone match from HEX alone.
- Record the actual digital colour values and test their use in light, dark and Matte Black contexts.

## 3. Pattern-only scope

The owner explicitly clarified: **do not change the existing background** for the current pattern exercise. Design patterns as reusable, optional, transparent overlays that can be applied to existing surfaces. The pattern can be omitted without changing the component.

Potential placements include card corners, card headers, profile covers, featured-resource panels, onboarding accents, empty states, section dividers, media cards, page headers and branded moments. The same motif should adapt through crop, scale, density, stroke weight, colour and opacity.

## 4. Pattern vocabulary (expandable)

- Packet routes and branching paths.
- Node constellations and network meshes.
- Signal waves and overlapping wave bands.
- Travelling pulses and pulse trails.
- Radar rings, arcs and detection points.
- Secure layers, shield contours and hexagonal geometry.
- Data-flow ribbons, particles and dotted fields.
- Packet matrices, grids and modular cells.
- Any new motif that strengthens recognition or communicates a useful idea.

Waves and pulses are explicitly welcome. Do not limit future exploration to these eight families.

## 5. Motion direction

Patterns may have static and animated variants. Examples include packets travelling along paths, nodes lighting up in sequence, a pulse radiating from a node, a wave passing through a card edge or a radar arc sweeping slowly. Motion can be expressive; it should be adapted to context and never obscure content or controls. Respect reduced-motion preferences and provide an equivalent static presentation.

## 6. What remains important

Creative freedom does not remove product-quality expectations. Evaluate new directions for readability, accessibility, responsive behaviour, usability, performance, privacy, security and licensing. These are review criteria, not a reason to avoid experimentation.

## 7. Review-build treatment

All pattern and colour explorations discussed here are **Approved Prototype** for inclusion in the review build as variants or sample components. Team feedback can result in Retain, Refine, Restrict or Remove in the next build. This is not production approval.

## 8. Documentation destinations

- Document 1: record owner design-exploration and pattern-scope decisions.
- Document 2: preserve creative flexibility and distinguish experience guardrails from aesthetic preferences.
- Document 3: identify useful surfaces/workflows where overlays may be applied without changing backgrounds.
- Document 4: include transparent pattern assets in the build and visual-review tasks.
- Document 5: maintain an expandable pattern/colourway registry and source asset manifest.


# PacketPulse 2.0 — Discussion Record: Media, Nested UX and Brand Pattern Exploration

**Date:** 26 November 2026  
**Status:** Owner-directed; included as Approved Prototype scope for the next review build  
**Related canonical documents:** Documents 1–5  
**Purpose:** Capture the latest discussion and the owner's corrections so the design system and Claude handoff remain aligned.

## 1. Owner direction: design is open, creative and experimental

The owner explicitly rejected a rigid or overly prescriptive design vocabulary. Signal Grove remains the shared identity, but it must not become a fixed aesthetic cage. The design team may explore new colours, Pantone references, patterns, compositions, typography and motion when they improve usability, clarity, brand recognition or emotional quality.

The owner also clarified that the generated background exploration should not be used to change existing page/card backgrounds. The requested work is a **pattern library**: transparent reusable motifs that can be layered onto existing surfaces.

## 1.1 Creative flexibility clarification

The owner reiterated that design guidance must not become hard-edged aesthetic restrictions. Use existing brand, module and semantic colours, Pantone-inspired exploration, new shades, gradients and combinations where they improve the product. The pattern list is a starting set, not a closed specification. Waves and pulses are welcomed, as are new motifs. Keep existing backgrounds untouched unless their separate redesign is requested; treat patterns as optional overlays.

## 2. Brand pattern families

Initial exploration families: Packet Routes; Node Constellation; Signal Waves; Pulse Trails; Radar Echo; Secure Layers; Data Flow; Packet Matrix. These are starting points, not an exhaustive list. New motifs and combinations are welcome.

Patterns may use the broader Signal Grove tokens, module accents, semantic colours and experimental palettes. Explore forest/eucalyptus/lime, indigo/blue/plum/violet, cyan/azure, amber/coral and multi-hue gradients where they fit. Do not force all motifs to be green. Pantone may be used as a reference for print/brand exploration, but do not invent a Pantone code or claim a direct match from HEX alone.

The motifs are to be built as transparent SVG/inline React or CSS overlays with scale, opacity, crop, line weight and colour variations. They do not replace or repaint the existing surface. The current generated wallpaper concepts are not treated as approved backgrounds.

## 3. Media and recording playback

The Resources experience must handle embedded recordings and multiple media/file types with the appropriate viewer. A single generic iframe is not sufficient.

### Preferred review-build stack

- **Video.js 10 (`@videojs/react`)** is the preferred default React player candidate. Official changelog records v10.7.0 on 24 November 2026; v10.0.0 became stable on 1 October 2026. The v10 architecture is modular and includes React/TypeScript/Tailwind patterns, adaptable skins and supported media sources including direct files, HLS, DASH and selected providers.
- **Shaka Player** remains a specialist alternative for requirements that specifically need advanced adaptive/offline/EME capabilities; not a second default player.
- **Uppy React headless/hooks** is the preferred upload UI candidate. **Tus** provides resumable upload where the existing storage/backend can support it. Uppy Dashboard is suitable for a quick prototype, but PacketPulse should own the final UI.
- **WaveSurfer.js 8.1.0 (BSD-3-Clause)** may be used as an optional audio waveform and region/timeline layer for audio-only recordings; it complements rather than replaces Video.js and needs a normal audio-control fallback. Pre-decoded peaks may be needed for streaming/large recordings.
- **React-PDF/PDF.js** is preferred for PDF preview. Office formats should use isolated conversion or a separately licensed provider after legal and security review.
- **FFmpeg** may be evaluated for thumbnails, metadata and transcode jobs; its license/build flags/codecs and patent implications must be reviewed.

### User experience expected

Playback controls should include what the source actually supports: play/pause, seek, volume, speed, quality, captions/subtitles, transcript, chapters, fullscreen, PiP where available, source label, resume progress, loading/error/offline/restricted states. No autoplay with sound. Captions and transcripts should be first-class, with provenance visible (human-reviewed/generated/unavailable).

### File handling

Use type-aware viewers: video/audio, PDF, image, Markdown/text/code and safe CSV preview. Office files may use a secured conversion pipeline or approved commercial/open-source provider. Archives, executables, unknown and unsafe formats should not be executed or embedded; show an honest fallback.

### Upload lifecycle

Selection → validation → queue → upload → pause/resume/retry/cancel → scan/quarantine → processing/transcoding/thumbnail → preview ready → moderation/publish. Status and progress must be real or visibly marked as mocked in a prototype. Store binaries in object storage and metadata in PostgreSQL; use short-lived signed access.

### Embed safety

Only approved providers should be embeddable. Canonicalise URLs server-side, allow-list providers, apply CSP/frame-src and sandbox/permission policies, check postMessage origins, prevent SSRF and unsafe redirects, and never render arbitrary member-supplied iframe or raw HTML.

## 4. Parent-child and nested-screen workflows

The owner wants the entire system to improve, including parent-child, nested screens and UI components. A parent remains the user's anchor while child experiences open.

- Use route-based child pages for substantial workflows and deep-linkable detail.
- Use route-backed drawers/sheets for contextual inspection where retaining the parent list is useful.
- Use inline expansion for small secondary information.
- Avoid modal-on-modal and deep, contextless flows.
- Preserve breadcrumbs/back path, browser history, filters, search, selected record, scroll and focus where feasible.
- On mobile, substantial children become full-screen routes or clearly titled sheets.
- Re-check permissions server-side on every child route and file/media request.

## 5. Approved Prototype scope

The following are included in the next review build: Video.js 10 player composition; upload manager with resumable path; PDF and supported file preview; secure provider embeds; recording detail with transcript/chapters/progress; parent-child navigation patterns; transparent motif library and multi-colour variants.

This is approval to prototype and review, not a claim that libraries are installed or production-ready. Repository audit, licensing, provider configuration, security, accessibility, mobile/browser playback and real media-processing checks remain required. After the review window the team records Retain, Refine, Restrict or Remove.

## 6. Technical research references (accessed 26 Nov 2026)

- Video.js 10 GA: https://videojs.org/blog/videojs-10
- Video.js changelog: https://videojs.org/changelog
- Video.js React installation: https://videojs.org/docs/guides/installation/react
- Video.js HLS/DASH streaming: https://github.com/videojs/http-streaming
- Shaka Player: https://github.com/shaka-project/shaka-player
- Uppy React: https://uppy.io/docs/react/
- Uppy Tus: https://uppy.io/docs/tus/
- Tus server: https://tus.github.io/tusd/
- React-PDF: https://github.com/wojtekmaj/react-pdf
- WaveSurfer.js: https://wavesurfer.pages.dev/docs/ · https://github.com/katspaugh/wavesurfer.js
- ONLYOFFICE Community licensing FAQ: https://helpcenter.onlyoffice.com/docs/installation/community/faq
- FFmpeg licensing: https://ffmpeg.org/legal.html

## 7. Recent cross-chat coverage note

The requested recent window was 24–26 November 2026. This record incorporates the current PacketPulse project discussion and the 24–25 November review-build documents present in the active workspace. Separate transcript exports for other independent chats in this date window were not available here; no unseen decisions have been inferred. Add those discussions later if their transcripts are supplied.


## 8. Final owner clarification: no hard visual rulebook

The owner reiterated: be creative, experimental and improve the whole design system. Do not write aesthetic guidance as rigid/hard-coded design laws. Signal Grove is a shared design language and an evolving token system, not a colour cage. The team may draw from all brand/module/semantic tokens and explore new hues, tonal shades, multi-colour gradients, Pantone-referenced studies and fresh palettes. Keep semantic status meaning legible; don't turn this into a restriction on decorative colour or compositions.

The current brand-pattern request is only to plan and build reusable transparent overlays. Do not change the page/card background when applying patterns. Make assets adaptable in colour, scale, crop, density, line weight, intensity and optional motion. Waves and pulses are welcome, alongside packet routes, nodes, routing traces, radar, security forms, topographic/flow fields, spectrums and motifs not yet named. These families are examples, not an exhaustive list.

Design guidance should enable exploration and review, not prevent it. Include promising variants in the Approved Prototype build. Team feedback after the review window determines Retain, Refine, Restrict or Remove for the next build. Accessibility, privacy, security, licensing and product integrity remain real safeguards.


## 8. Owner clarification — open creative direction and pattern-only scope

The owner clarified that no design aesthetic should become a rigid rulebook. Be creative, experimental and willing to improve the whole system. Existing examples and pattern families are inspiration, not limits. Use the full Signal Grove brand/module/semantic palette and explore further colour combinations, shades, gradients, Pantone-referenced studies and new hues when they work. Green is not compulsory.

The user also clarified that the current brand-pattern request must not change the existing background. The task is to design reusable, optional pattern overlays that can be applied in multiple places—cards, headers, profile covers, resource features, empty states, hero accents, section dividers and similar surfaces—while leaving the existing background intact. Waves and pulses are explicitly welcome alongside packets, nodes, routes, radar and security motifs.

Patterns should be reusable design assets, preferably transparent SVG/CSS/React variants, and can be subtle, expressive, static or animated. They are not a requirement for every component. Colour, crop, scale, density and intensity can adapt to context. Preserve usability, readability, accessibility, performance and reduced-motion support.

**Decision:** Open creative exploration is owner-confirmed. Transparent pattern-only overlays are owner-confirmed for the current pattern work. The current family list and colourways remain expandable.


# Consolidation provenance, source precedence and integrity

## Primary source packages and version lineage (24 Nov baseline; later updates reconciled)

- `PacketPulse_2.0_Update_2026-11-24.zip` (preserved in Git history; user-identified attached baseline) — four core guides, change/update summaries, Claude handoff, colour-system PDF and references.
- `PacketPulse_2.0_Approved_Prototype_Review_Build_2026-11-26.zip` — current 26 Nov canonical five-doc suite, changelog, update summary, review register, technical source register, Claude handoffs, discussion records and reference assets.
- `PacketPulse_2.0_Discussion_2026-11-25.zip` — prior discussion update set and design/component source context.
- `PacketPulse_2.0_Recovery_Pages_Design_System_Package.zip` — recovery pages and earlier design-system history.
- `PacketPulse_2.0_Team_Documentation_v1.3_2026-10-24.zip` — immutable earlier team documentation and design assets.
- `PacketPulse_Visual_Identity_Foundation_v1.0.zip` and `PacketPulse_Visual_Identity_Exploration_v0.1.zip` — identity explorations and owner-approved foundation artifact.
- `SCR-003_Frontend_Implementation_Starter.zip` — separate screen implementation starter; not integrated into the application repository by this documentation rebuild.

## User-identified source baseline — 24 November 2026

The owner noted that the attached source files represent the 24 Nov update set. Git history preserves this as `history/releases/2026-11-24-update-set/PacketPulse_2.0_Update_2026-11-24/`, including the four core guides, `CHANGELOG.md`, `UPDATE_SUMMARY.md`, `CLAUDE_UPDATE_HANDOFF.md`, the design colour-system PDF and its reference asset. The 24 Nov baseline is retained as historical source—not treated as the latest state.

## Later source sets reconciled

- 25 Nov discussion and review-build packages (discussion records, expanded core guides and component ecosystem).
- 26 Nov Approved Prototype Review Build (canonical five-document set, changelog, review register, technical source register, component additions, handoffs and visual/reference assets).
- 27 Nov owner decisions and Notion notes (user-psychology-first design; finalized Violet-led foundation; Claude token/logo delegation; SCR-004 and SCR-005 screen specifications; capability inventory and updated change lineage).

## Git repository snapshot inspected

- Repository: `kartik-binzade/packetpulse-community-2.0` (public documentation/history companion repository; not established as the live application source repository).
- Branch: `main`.
- Observed HEAD commit: `cca0a25576d65a9da2892c2f676a3efe9df481ec`.
- Commit message: `PacketPulse-Notion-Docs-latest(27Nov.7Pm)`; commit timestamp in Git metadata: `2026-11-27T14:21:04Z`.
- Tree includes `PacketPulse_Documentation_History/`, immutable `history/releases/` and `history/source-packages/`, `Notion's Doc/PacketPulse-Notion-Docs-latest(27Nov.7Pm)/`, governance, current documents, approved identity assets, token CSS, brand patterns, SCR-003 screen spec and a separate SCR-003 implementation starter.
- Git tree includes the 24 Nov update archive and later 25/26 Nov source packages. Latest Notion companion export includes Product Guide v5.5, Design System & UX Guide updated 27 Nov 7:41 PM (Notion metadata), Master Change Log/Decision Register, capability inventory, SCR-004 and SCR-005.
- The Git repository is a documentation/archive workspace and contains prototype/spec assets; this does not prove the production app repo has been inspected, the app integrated, or deployment/test status.
- The README within the history workspace described a standalone docs workspace and an earlier intended push destination; current repository metadata and HEAD above are the observed later state. Do not repeat the old setup instruction as current without owner confirmation.

## Notion pages consulted / cross-checked

Documentation & Project Memory; Product Guide v5.5; Design System & UX Guide (27 Nov); Users, Screens & Page Flows; Delivery Plan & Developer Handoff; Component Ecosystem & Library Registry; Decision Register & Governance; Master Change Log & Discussion Lineage; Source Index & Archive Manifest; Design Token & Theme History; Brand & Visual Design System; Required Product Components & Capability Inventory; SCR-003, SCR-004 and SCR-005 screen specifications; SCR-003 engineering handoff; 26 Nov Discussion Handoff. Notion companion pages explicitly identify themselves as structured summaries/navigation rather than verbatim imports.

## Source limitations

- Notion canonical companion pages are not full verbatim copies of all source documents. This rebuild uses the complete local Markdown source set for the 26 Nov review build and the available Notion page content/notes for later updates.
- Some Notion pages or discussion summaries may have been updated after the 26 Nov source ZIP; only specific retrieved current notes are merged. Unknown content is not inferred.
- The 205-file documentation-history archive referenced by Notion is a prior archive manifest; this four-file output is a new consolidated release, not a replacement or reconstruction of every archived binary.
- The application repository was not inspected as part of this document-generation task. No implementation, test, deployment or Git publish status is upgraded by these documents.

## Status vocabulary and versioning

Confirmed / Planned / Proposed / Approved Prototype / Production Approved / Open / Discovery / Historical / Delegated / Repository validation pending retain their source meanings. Never treat a prototype as production approval. New owner decisions supersede current guidance; historical source files stay immutable and are linked, not silently rewritten.
