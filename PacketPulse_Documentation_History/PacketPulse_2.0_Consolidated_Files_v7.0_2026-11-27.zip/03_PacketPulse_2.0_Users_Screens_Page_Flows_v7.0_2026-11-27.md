# PacketPulse 2.0 — Users, Screens, Journeys & Functional Page Flows

**Consolidated release:** v7.0 · 27 November 2026  
**Source baseline:** Owner-supplied project documentation set dated 24 November 2026, reconciled against later 25–26 November source packages, Notion exports/records and Git main snapshot through 27 November 2026.  
**Document status:** Product/design specification and project handoff. Not evidence of production implementation, legal approval or repository validation.  
**Source precedence:** Current owner-approved decisions and dated Notion decision/change records supersede earlier proposal or historical token values. Dated releases remain immutable; see the source/lineage section at the end.  
**Working agreement:** Product behavior, user flows, edge cases, acceptance criteria and quality standards are defined here. Claude audits and implements in the actual application repository. Do not invent repository paths, replace working services, or claim tests/deployment without evidence.

**Current owner direction (27 Nov):** User-context-first design, ethical psychology, accessible and truthful UX. The approved visual foundation is Violet-led Palette 1 (`#615AB9`, `#16133E`, `#8B7FF7`, `#F1F5F9`) complemented by Forest `#156152`, Signal Lime `#C7FE53`, Soft Forest `#8BBBA5`, and balanced black/white neutrals. Detailed operational tokens, shade/state refinement within this foundation, scoped Payments blue and reusable logo completion are delegated to Claude; the foundation and product-policy boundary are fixed unless the owner changes them.

**Reading note:** The complete 26 Nov canonical source text is retained below for traceability and detail. The 24 Nov source set is the historical baseline you identified; later dated records supersede it only where explicitly approved. Its dated palette/token proposals and other historical states are not silently promoted; use this 27 Nov authority block and the explicit current-decision addenda for present-day decisions.

Version 3.6 · 26 November 2026 · Owner: product lead with design lead (to be named) · Supersedes the 17 October 2026 Users, Screens and Page Flows v2.0. Requirements are cited as PRD, decisions as DEC and OPEN (Document 1); design rules as DES (Document 2); build capabilities, tasks and tests in Document 4. **[APPROVED PROTOTYPE]** marks owner-approved scope for the next review build; it is not production approval. PV means built and tested in the reference prototype only. Proposed screens and flows in this revision are not proof of production implementation. Which routes exist in production is not known until the repository audit (OPEN-15).

## 1. Users and their main journeys

Each user has one home page, a few frequent screens and one success signal. Screens are listed by ID and described in section 4.

| User | Goal | Entry | Home screen | Frequent screens | Success signal |
| --- | --- | --- | --- | --- | --- |
| Visitor | Understand PacketPulse and decide to join | Search, referral, community link | Home (SCR-001) | Fees (SCR-002), Join (SCR-003) | Registers and verifies email |
| Fresher member | Learn, practice, get a first role | Join, invitation | Dashboard (SCR-004) | Learn, Practice, Assessments, Community, Jobs | First verified skill, first application |
| Experienced member | Grow, prove depth, change roles | Join, referral | Dashboard | Assessments, Practice, Jobs, Applications, Community | Verified skills, an interview |
| Mentor | Help others, build reputation | Invitation by admin or eligible member request | Dashboard | Community, Reviews (SCR-014), Mentoring (SCR-016), Groups and Events | Helpful answers, completed mentoring and reviews |
| Community contributor | Solve engineering problems and publish reusable knowledge | Onboarding interests or search | Community Discover (SCR-047) | Questions, Discussions, Knowledge, Resources, Groups, Events, Profile | Helpful contribution and knowledge reused by others |
| Instructor | Publish and review learning content | Invitation by admin | Dashboard | Content (SCR-017), Reviews | Published content, reviewed labs |
| Recruiter | Fill positions with good candidates | Company onboarding (SCR-033) | Recruiter dashboard (SCR-018) | Positions, Candidates, Candidate review | A hire marked Joined |
| Admin | Keep the platform safe and moving | Staff invitation | Operations (SCR-024) | Verification, Taxonomy, Payments, Analytics | Queues cleared within target times |
| SuperAdmin | Control access, policy and security | Staff invitation | Operations | Users, Roles, Policies, Security | No policy or access change without audit |

### 1.1 Journey maps

| Journey | Steps | Ends when |
| --- | --- | --- |
| Member: discovery to first value (WF-001) | Home, Fees, Join, verify email, choose Fresher or Experienced, required details, resume review, consent, Dashboard, first action (ask, enroll or start a lab) | The member completes a first action |
| Member: prove a skill (WF-002, WF-003, WF-004) | Assessments or Practice, attempt or submit, result or review, add evidence if needed, verification decision, badge | A skill shows a verified label |
| Member: get hired (WF-006, WF-007) | Jobs, Apply (consent and fee declaration), Applications timeline, interview, offer, accept, Joined, invoice | The application reaches Joined or ends with a status the member understands |
| Recruiter: fill a position (WF-006, WF-012) | Company onboarding, create position, review, publish, forwarded candidates, review with scorecard, interview, offer, Joined | The position is Closed as Fulfilled |
| Admin: handle a queue (WF-008) | Sign in with MFA, Operations queue, open item, decide with reason, notify, audit entry | The queue item is closed with a recorded decision |
| Anyone: data rights (WF-011) | Settings or Profile, Privacy, export or erase, confirmation, result | The request is completed and logged |

## 2. Information architecture

### 2.1 Structure

```
Public        Home, Fees, Sign in, Join
Onboarding    Verify email, choose Fresher or Experienced, required details, resume review, consent
Member        Dashboard, Learn, Practice, Assessments, Jobs, Applications, Community (Discover, Questions, Discussions, Knowledge, Resources, Groups, Events, Mentors, Saved), Profile, Notifications, Settings
Reviewers     Reviews (queue, detail), Mentoring, Content (instructors and admins)
Recruiter     Dashboard, Candidates (list, review), Positions (list, detail, form), Interviews
Admin         Operations (Analytical Workspace), Verification, Taxonomy, Content, Payments, Analytics, Moderation, Experiment review
SuperAdmin    Users, Roles, Policies, Security (plus all Admin areas)
```

Relationships that drive navigation: Profile and Taxonomy feed Jobs and Candidates; Assessments, Practice and Verification feed the evidence recruiters see; Jobs feed Applications; Positions feed Candidates; Payments depend on Learn (priced content) and Applications (placement fee); every area writes to the audit log in Operations.

&#91;embedded content: member sign-up path · 6 steps then 5 paths\]

Applying for jobs stays blocked until the required details are complete (PRD-003); every other path opens as soon as the member reaches the dashboard.

### 2.2 Navigation by role

| Role | Primary navigation |
| --- | --- |
| Member | Home, Learn, Practice, Assessments, Jobs, Applications, Community, Profile |
| Mentor | Member pages plus Reviews and Mentoring |
| Instructor | Member pages plus Reviews and Content |
| Recruiter | Dashboard, Candidates, Positions |
| Admin | Operations, Verification, Reviews, Taxonomy, Content, Payments, Analytics |
| SuperAdmin | Admin pages plus Users, Roles, Policies, Security |

Navigation is built from the person's permissions, and the server checks every page and action again (DEC-010). Deep links survive sign-in. A denied page shows a plain explanation and a valid destination (SCR-043). Members have eight items; the mobile bottom bar shows the five most used: Home, Learn, Practice, Community, Jobs, with the rest behind a More item **\[REVIEW\]**.

### 2.3 Visual flexibility across parent/child screens

Child workflows inherit the product's shared design language but are not forced into identical layouts. Explore drawers, sheets, split workspaces, full-page readers, responsive master-detail layouts, contextual tabs and inline expansions based on the task. Use PacketPulse brand motifs as optional transparent overlays; the current pattern work preserves existing page/card backgrounds. Colour, display type and motion can vary by context while navigation, state and accessibility remain coherent.

## 3. Page rules that apply to every screen

| Rule | Detail |
| --- | --- |
| States | Every data screen has loading, empty, error, success and, where relevant, disabled states (DES-001) |
| One primary action | At most one primary button per screen or dialog (DES-008) |
| Titles | One H1 per page; the browser tab title follows it |
| Back and deep links | Detail pages show a breadcrumb; filters and scroll position are kept when returning to a list |
| Responsive | One column below 768 px; tables become stacked cards; dialogs become full screens for long tasks |
| Keyboard | Everything reachable; focus moves to the page heading after navigation |
| Unsaved work | A warning before leaving a changed form; long forms save and resume |
| Permissions | A person never sees a control they cannot use; the server rejects it anyway |

### 3.1 Workspace layout families

| Workspace | Screens | Composition |
| --- | --- | --- |
| Editorial Workspace | Member dashboard, Community discovery, thread, article, learning and profile | Reading-led hierarchy, generous whitespace, contextual navigation, narrow reading measure where appropriate |
| Analytical Workspace | Operations, recruiter analytics, admin analytics, moderation and verification queues | Grouped sidebar, breadcrumb/header, context filters, 4–5 KPIs, primary chart/table area, collapsible contextual rail and detailed records |

The supplied Vantage Admin screenshot is an inspiration reference for the Analytical Workspace, not a pixel-perfect implementation target. Use Matte Black Edition tokens for the preferred analytics reference; support the light theme and responsive layouts. Community/learning editorial pages should not be forced into a dense admin-dashboard pattern.

## 4. Screen register

Columns: ID, screen, proposed route, audience, purpose and main actions, permission, status.

### 4.1 Screens built in the prototype (PV)

| ID | Screen | Route | Audience | Purpose and main actions | Permission | Status |
| --- | --- | --- | --- | --- | --- | --- |
| SCR-001 | Home | / | Visitors | Explain the product loop; Join, Sign in, How fees work | Public | PV |
| SCR-002 | Fees | /fees | Visitors | Free, paid and fee table; worked example | Public | PV |
| SCR-003 | Join and verify | /join | Visitors | Email, 6-digit code, Fresher or Experienced | Public | PV |
| SCR-004 | Dashboard | /dashboard | Member | Loop tracker, next step, completeness, getting-started list | Member | PV |
| SCR-005 | Learn | /learn | Member | Filter by state; enroll, start, continue; buy priced items | Member | PV |
| SCR-006 | Practice | /practice | Member | Open a lab; submit root cause, evidence, fix, prevention; resubmit | Member | PV |
| SCR-007 | Assessments and verified skills | /assessments | Member | Skills with labels; add evidence; take assessment | Member | PV (attempt is a 2-question demo) |
| SCR-008 | Jobs | /jobs | Member | Filter by work mode; apply with consent | Member | PV |
| SCR-009 | Applications | /applications | Member | Timeline; accept or decline offer; pay invoice; withdraw | Member (own) | PV |
| SCR-010 | Community | /community | Member | Search, filter by mode, ask, request a mentor | Member | PV |
| SCR-011 | Thread | /community/id | Member | Answer, vote, follow, report, accept | Member | PV |
| SCR-012 | Profile | /profile | Member | Required details, resume review, career, compensation, consent, privacy, recruiter preview, data requests | Member (own) | PV |
| SCR-013 | Notifications | /notifications | All | List, mark all read | Own | PV |
| SCR-014 | Reviews queue | /reviews | Mentor, Instructor, Admin | Awaiting and reviewed lab submissions | Reviewer | PV |
| SCR-015 | Review detail | /reviews/id | Same | Score four areas, feedback, decide | Reviewer | PV |
| SCR-016 | Mentoring | /mentoring | Mentor | Accept or decline requests | Mentor | PV |
| SCR-017 | Content | /content | Instructor, Admin | Create, submit, review, publish, unpublish | Instructor or Admin | PV |
| SCR-018 | Recruiter dashboard | /recruiter | Recruiter | Attention items, positions at a glance, agenda, activity | Recruiter | PV |
| SCR-019 | Candidates | /recruiter/candidates | Recruiter | Search, filter, sort, compare up to 3 | Recruiter (own company) | PV |
| SCR-020 | Candidate review | /recruiter/candidates/id | Recruiter, Admin | Profile, evidence, assessments, learning, resume, decide, interview, offer | Recruiter (forwarded only), Admin | PV |
| SCR-021 | Positions | /recruiter/positions | Recruiter | Filter by status; pause, close, reopen | Recruiter | PV |
| SCR-022 | Position detail | /recruiter/positions/id | Recruiter | Vacancies, dates, candidates, hiring history | Recruiter | PV |
| SCR-023 | Position form | /recruiter/positions/new | Recruiter | Create or edit; draft from pasted text; fee and experienced-only switches | Recruiter | PV |
| SCR-024 | Operations | /admin | Admin | Screening, jobs awaiting review, moderation, feature controls, audit filter | Admin | PV |
| SCR-025 | Verification | /admin/verification | Admin | Queue, review, revoke | Admin | PV |
| SCR-026 | Taxonomy | /admin/taxonomy | Admin | Tree, suggestions, automation | Admin | PV |
| SCR-027 | Payments | /admin/payments | Admin | Transactions, refunds, approve refund | Admin | PV |
| SCR-028 | Analytics | /admin/analytics | Admin | Funnel by segment | Admin | PV |
| SCR-029 | Users | /admin/users | SuperAdmin | Search, manage with step-up | SuperAdmin | PV |
| SCR-030 | Roles | /admin/roles | SuperAdmin | Permission matrix | SuperAdmin | PV |
| SCR-031 | Policies | /admin/policies | SuperAdmin | Recruiter visibility, AI policy | SuperAdmin | PV |
| SCR-032 | Security | /admin/security | SuperAdmin | Settings, sessions, access review | SuperAdmin | PV |

### 4.2 Screens approved or proposed but not built

| ID | Screen | Why it is needed | Status |
| --- | --- | --- | --- |
| SCR-033 | Company onboarding and verification | Recruiters register a company before posting (OPEN-10) | Planned |
| SCR-034 | Assessment attempt | Timed, autosaving attempts with instructions and results (PRD-017) | Planned |
| SCR-035 | Course and lesson player | Real content delivery | Planned |
| SCR-036 | Lab workspace | Topology, logs and terminal for real labs | Proposed (later) |
| SCR-037 | Notification preferences | Channels, quiet hours (PRD-041) | Planned |
| SCR-038 | Data export and erasure | DPDP rights (PRD-045) | Planned |
| SCR-039 | Billing history | Members see invoices and receipts | Planned |
| SCR-040 | Interview calendar | Scheduling with invitations | Proposed (later) |
| SCR-041 | Integrations settings | ClickUp and n8n (OPEN-12) | Planned |
| SCR-042 | Public member profile | Not at launch; profiles stay private (PRD-052, OPEN-19) | Deferred **\[REVIEW\]** |
| SCR-043 | Error pages (no access, not found, server error, maintenance) | Recovery paths | Planned |
| SCR-044 | Hide from companies | List of companies the member blocks (PRD-050) | Proposed **\[REVIEW\]** |
| SCR-045 | How verification works | Public page with the criteria for each label (Document 1, 10.1) | Proposed **\[REVIEW\]** |
| SCR-046 | Community guidelines | The moderation rules and appeals route (Document 1, 10.4) | Planned |

### 4.3 Dialogs and interaction surfaces (PV)

| ID | Surface | Purpose | Key rules |
| --- | --- | --- | --- |
| SCR-D01 | Apply | Consent to share resume; fee declaration and permission | Both fee ticks required when a fee applies; blocked if required details are missing or the role is experienced-only |
| SCR-D02 | Add evidence | Certification or experience submission | Validation per PRD-013 |
| SCR-D03 | Evidence review | Two checks, decision, reason | PRD-014 |
| SCR-D04 | Step-up confirmation | Reason and fresh code for sensitive actions | Lockout after repeated failures |
| SCR-D05 | Manage user | Reset link, MFA reset, sign out, role change, suspend | Every action audited; the user is notified |
| SCR-D06 | Checkout | Price, GST, payment, refund policy | Sandbox only; double payment prevented |
| SCR-D07 | Accept offer | Shows the exact fee; second confirmation | PRD-037 |
| SCR-D08 | Pause, close, reopen position | Reasons and dates | PRD-031 |
| SCR-D09 | Schedule interview, record outcome | Round, interviewer, IST time | PRD-034 |
| SCR-D10 | Compare candidates | Side by side, up to 3 | Respects visibility |
| SCR-D11 | Request a mentor, report, withdraw, decline | Reasons where required | Per PRD |
| SCR-D12 | Command palette | Search pages and actions by role | Keyboard first |

### 4.4 Community knowledge-network additions

| ID | Screen | Proposed route | Audience | Purpose and main actions | Permission | Status |
| --- | --- | --- | --- | --- | --- | --- |
| SCR-047 | Community Discover | /community/discover | Member | For you, Latest, Unanswered and Solved feeds; follow/mute topics; save content; discover experts | Member | Approved Prototype |
| SCR-048 | Structured post composer | /community/new | Member | Choose Question, Discussion, Case study, Knowledge article, Event/AMA or Announcement; draft, preview and publish | Member; additional content types may require moderation | Approved Prototype |
| SCR-049 | Knowledge library and search | /community/knowledge | Member | Search questions, answers, articles, members, groups, events and related learning; filters and saved search | Member | Approved Prototype |
| SCR-050 | Groups and interest spaces | /community/groups | Member, Moderator | Browse/join groups, view group feed/resources, manage membership and moderation | Member / Moderator | Approved Prototype |
| SCR-051 | Events and expert sessions | /community/events | Member, Mentor, Admin | Browse, RSVP, reminders, attendee list and post-event resources | Member / Host | Approved Prototype |
| SCR-052 | Community contribution profile | /profile/contributions | Member | Contribution history, solved questions, articles, mentoring and reputation; member-controlled visibility | Member (own); viewer-scoped | Approved Prototype |
| SCR-053 | Automated verification experiment review | /admin/verification/experiments | Admin, SuperAdmin | Configure mode, policy, thresholds, cohorts, review outcomes, appeal/escalation and rollback | Authorised Admin; policy changes SuperAdmin | Approved Prototype |

Existing screens are updated by layout family rather than duplicated: SCR-004 Member Dashboard = Editorial Workspace; SCR-018 Recruiter Dashboard = Analytical Workspace; SCR-024 Operations = Analytical Workspace; SCR-028 Analytics = Analytical Workspace; SCR-025 Verification = queue-first analytical view with member-friendly detail states.

### 4.5 Resources and identity review-build screens (Approved Prototype)

| ID | Screen | Proposed route | Audience | Purpose and main actions | Permission | Status |
|---|---|---|---|---|---|---|
| SCR-054 | Resources Library | /community/resources | Member | Discover curated resources; search; filter by category, format, technology, difficulty and audience; switch For you/Featured/Recent/Popular/Staff Picks; save and open collections | Member | Approved Prototype |
| SCR-055 | Resource Detail / Reader | /community/resources/[id] | Member | Preview/open document, video, article or external source; table of contents; view source, author, attribution, licence, version and last review; save/share/report; related resources and discussion | Member | Approved Prototype |
| SCR-056 | Share a Resource | /community/resources/share | Member, Contributor | Three-step Details → Content → Review & publish wizard; upload file, add URL or write article; choose type/category/technologies/difficulty/audience; record source and licence; preview; save draft/submit | Member; moderator review where required | Approved Prototype |
| SCR-057 | Saved Resources and Collections | /community/resources/saved | Member | All saved, Reading list, My collections, Recently viewed and Continue reading; create/rename/reorder/share/delete own collections; update reading status | Member (own) | Approved Prototype |
| SCR-058 | Resource Review Queue | /admin/resources/review | Moderator, Admin | Review submissions, scan/link status, source/rights/attribution, preview and version; approve, request changes, reject, hide or archive with reason | Moderator/Admin | Approved Prototype |
| SCR-059 | Personalised Onboarding | /onboarding/personalise | New member | Stepper for Role → Interests → Goals; choose Student/Engineer/Specialist/Mentor/Recruiter; choose taxonomy-backed interests; choose learning/community/career goals; skip optional steps and edit later | Authenticated member (own) | Approved Prototype |
| SCR-060 | Profile Visibility Preview | /profile/preview | Member | Preview self, community-member and recruiter-after-forwarding view; explain hidden fields and why; edit audience-specific visibility | Member (own) | Approved Prototype |
| SCR-061 | Account Settings Overview | /settings | Member, Recruiter, Staff | Entry point for personal information, profile visibility, notifications, security, sessions, connected accounts, privacy/data rights and billing where applicable | Own account; role-scoped | Approved Prototype |
| SCR-062 | Login, Security and Sessions | /settings/security | Member, Recruiter, Staff | Password/passkey, MFA, recovery, active sessions, sign out other sessions, security history and step-up | Own account; stronger staff controls | Approved Prototype |
| SCR-063 | Connected Accounts | /settings/connections | Member | View/link/unlink Google, GitHub and LinkedIn where configured; explain permissions and account-linking consequences | Own account; step-up to unlink last recovery method | Approved Prototype |
| SCR-064 | Recording / Media Viewer | /media/[mediaId] | Member, Learner | Play hosted recordings, direct files and approved provider embeds; show playback controls, captions, transcript, chapters, speed, quality where available, progress/resume, optional audio waveform for audio-only assets, source and related resources | Entitled audience; media visibility follows parent resource/course | Approved Prototype |
| SCR-065 | Embedded File Preview | /files/[fileId]/preview | Member, Learner, Reviewer | Render supported PDF, image, audio/video, text/Markdown/code and safe tabular previews; show unsupported/blocked format fallback and download permission | Same permission as source file; private files use short-lived access | Approved Prototype |
| SCR-066 | Upload Manager / Processing Detail | /uploads/[uploadId] (also available as a drawer) | Member, Contributor, Reviewer | Select files, upload, pause/resume/retry/cancel, view scan/transcode/thumbnail/processing states, preview, replace or remove before publication | Uploader and authorised reviewers; private object access | Approved Prototype |
| SCR-067 | Media Embed and Source Details | /community/resources/[id]/source | Member, Moderator | See source provider, embed type, original link, licence/attribution, caption/transcript availability and provider availability; report broken or unsafe source | Member; moderation fields restricted | Approved Prototype |

Existing screens are extended rather than duplicated: SCR-003 becomes the split-layout signup and email-verification entry; SCR-012 becomes the living professional profile; SCR-037 carries the expanded notification preferences; SCR-038 carries privacy, export and erasure; SCR-044 remains the hide-from-companies control. SCR-042 public web profile remains off by default and is not silently enabled by profile previews.

## 5. Detailed specs for screens not yet built

Each spec follows the handoff pattern: content, actions, rules and states, and sample copy. Sample copy uses the patterns in Document 2 section 11.

| Screen | Content and fields | Actions | Rules and states | Sample copy |
| --- | --- | --- | --- | --- |
| SCR-033 Company onboarding | Company name, website, size band, contact person (name, work email, phone), registration or GST number (optional), LinkedIn company page (optional), agency toggle with end-client name | Save draft, Submit for review | Free email domains are held for review. Status timeline: Submitted, In review, Approved or Changes requested. Positions can be drafted but not published until approved. Rejected or suspended shows the reason. See Document 1, 10.6 **\[REVIEW\]** | Your company is in review. You can draft positions while you wait. |
| SCR-034 Assessment attempt | Instructions page (time, attempts left, pass mark, validity, honesty statement tick), question view (Question 4 of 20, visible timer, flag for review, previous, next, navigator), review page listing unanswered and flagged items, result page (score, pass or not, level, weak topics, next step) | Start, Next, Flag, Submit, Leave | Autosave every answer; a reload resumes the same attempt with the remaining time; one active attempt only; attempts and retake gap enforced; the timer is announced to assistive technology at 10 minutes and 1 minute, not every second; locked state shows the next available date. Values in Document 1, 10.2 | Submit with 3 questions unanswered? You cannot change answers after submitting. Buttons: Submit now, Keep working |
| SCR-037 Notification preferences | Grid of event types by channel, quiet hours, WhatsApp opt-in with number confirmation, separate marketing opt-in, digest frequency | Save | In-app is always on; critical events are listed and cannot be switched off; every change is recorded with a time. Defaults in Document 1, 10.3 | Interview and offer messages always reach you, even in quiet hours. |
| SCR-038 Data rights | Sections: Download my data, Correct my data (link to Profile), Withdraw consent (list), Delete my account and data, Grievance contact | Request download, Withdraw, Delete account | Re-enter the password or a code before deletion; a 30-day grace period to cancel; the page lists what is kept for legal reasons and for how long; requests show Open, In progress, Done | We will email a link when your data is ready. The link works for 7 days. |
| SCR-039 Billing history | Invoices and receipts with status chips (Paid, Due, Refunded), download as PDF, placement-fee invoices show the offer they belong to | Pay now, Download | Empty state explains when invoices appear; a due invoice shows the due date and days left | No invoices yet. Paid courses and placement fees appear here. |
| SCR-043 Error pages | No access, Not found, Something went wrong, Maintenance | One next action each; a reference code to quote to support | Never show technical details | We could not find that page. Go to your dashboard, or search for what you need. |
| SCR-044 Hide from companies | List of blocked companies with remove buttons; add by company name | Add, Remove | Up to 20; matched by name and web domain; staff can still see the profile; an agency cannot be guaranteed to honor it **\[REVIEW\]** | Hidden companies will not see your profile in search or in forwarded lists. |
| SCR-045 How verification works | The five labels, what is checked, who decides, validity, appeals | Link from every badge | Public page; same wording as Document 1, 10.1 **\[REVIEW\]** | PP verified means two kinds of evidence, one of them reviewed by a person. |
| SCR-046 Community guidelines | Rules, action steps, response times, appeals route | Accept (first post), Report | Linked from every post form; acceptance recorded | Never post passwords, keys or customer data. |

### 5.1 Resource and identity screen specifications (review build)

**SCR-054 — Resources Library**
- Header: breadcrumb Community / Resources, H1 “Resources”, one-line purpose statement, primary “Share a resource” action.
- Discovery feature: optional featured collection with editorial illustration/diagram, title, short description and CTA.
- Tabs: For you, Featured, Recent, Popular, Staff Picks. Filters: Category, Format, Technology, Difficulty, Audience, Sort.
- Main content: resource cards with file/type icon or thumbnail, title, short value proposition, technology chips, author/source, difficulty/estimated time, updated/reviewed date, save control and moderation/quality label where applicable.
- Optional right rail: popular topics, recently added, curated collections and “continue reading”; collapses on tablet and becomes a sheet/stack on mobile.
- States: first-use empty, no results, loading, error/retry, saved, hidden/removed resource and restricted resource.

**SCR-055 — Resource Detail / Reader**
- Primary column: document/media/article preview with zoom/page controls where supported; article uses readable measure and section anchors; video has captions/transcript when available; external links show destination before opening.
- Secondary rail: table of contents, metadata, format, difficulty, estimated time, version, last reviewed, author/contributor, source, licence and attribution.
- Actions: Open/Download (when permitted), Save, Add to collection, Share, Report issue, Helpful/Not helpful.
- Lower section: related resources, community discussion/questions and “learn/practice this topic” cross-links.
- Do not claim a third-party resource is reviewed unless a real review event exists. Broken or expired links show an explanation and report action.

**SCR-056 — Share a Resource**
- Step 1 Details: title, short description, resource type (Guide, Documentation, Tool, Template, Course, Video, Cheat sheet, Lab, Repository, Article), category, technology tags, difficulty, intended audience and language.
- Step 2 Content: choose Upload file, Paste URL or Write article. Upload supports queued/uploading/paused/processing-scanning/complete/failed/canceled/rejected states. Pause/resume only when transport supports it. Show actual bytes transferred, filename, size and validation.
- Step 3 Review & publish: preview, source/author, attribution, licence/usage rights, optional version and review date, audience visibility, community guidelines confirmation and submission status.
- Save draft at every step. If upload or validation fails, preserve completed fields and offer retry/remove/replace. Never publish a file that has not passed the configured scan and server-side validation.

**SCR-057 — Saved Resources**
- Tabs: All saved, Reading list, My collections, Recently viewed.
- Collection cards show name, description, resource count, privacy/sharing state, cover thumbnail and last updated. Resource list shows type, title, category, reading state, saved date and actions.
- Reading state: Not started, In progress, Completed. Progress is only shown when the underlying resource supports meaningful progress; otherwise use simple saved status.
- Continue reading resumes at a stored, permission-checked location. Member can remove a save without deleting the source resource.

**SCR-058 — Resource Review Queue**
- Analytical Workspace: KPI strip (Pending review, Needs changes, Scan/link issues, Recently published); filters; submission table; contextual review rail.
- Detail pane: content preview, metadata, attribution/licence evidence, file scan, URL health and revision history.
- Actions: Approve, Request changes, Reject, Hide/Archive. Every non-approval action needs a reason; every decision is audited and author receives a status message.

**SCR-003 — Signup and verification refresh**
- Wide screen: split layout with a restrained PacketPulse brand/story panel and a focused account form. Small screens: single-column form with no decorative panel competing with inputs.
- Options: email/password or passkey; Google/GitHub provider buttons are approved for prototype display and interaction. Real provider authentication is enabled only after provider setup and security audit; otherwise show a clearly labelled demo/disabled state in prototype.
- Include password visibility, strength guidance, Terms and Privacy consent, email verification, resend cooldown, error and recovery states. Keep login and account recovery links visible.

**SCR-059 — Personalised onboarding**
- Three-step progression: Role, Interests, Goals. Selected chips/cards show a check and accessible selected state. Role is single-select; interest and goal can be multi-select. Optional fields can be skipped. A small “You can change this later” note reduces pressure.
- On completion, create editable preferences and route to a personalised Community/Resource/Learn landing. Recommendations must be explainable and hide/mute controls are available later.

**SCR-012 — Professional Profile**
- Identity hero: avatar, name, headline, location/timezone if supplied, short introduction, edit button and distinct verification label. Do not use one generic “Verified” badge for every verification type.
- Tabs/sections: Overview, Skills, Experience, Education & Certifications, Contributions, Learning, Mentoring, Activity and Achievements where data exists.
- Skills section groups Self-declared, Assessment verified, Experience verified, Certification verified and PP verified; each has a detail view showing evidence/issuer/reviewer/date/expiry as permitted.
- Contributions show solved questions, useful answers, articles, case studies and mentoring, but community reputation never substitutes for skill verification.

**SCR-060 — Profile visibility preview**
- Preview modes: “My view”, “Community member view” and “Recruiter after forwarding”. The preview is generated by the same field-level policy as actual access; it is not a cosmetic mock.
- Explain each hidden field with a short reason and an action to change the setting when allowed. Do not expose date of birth, compensation, private notes, contact data or resume links beyond DEC-015 and consent.

**SCR-061 to SCR-063 — Account Control Centre**
- Settings hub uses spacious grouped cards: Personal information, Profile visibility, Notifications, Login & security, Sessions, Connected accounts, Privacy & data rights and Billing (when applicable).
- Security/session screens show current device, last active, approximate location only if the auth provider provides it reliably, sign-out controls, MFA/passkey state and recent security events. Do not invent device details.
- Connected accounts explain provider scopes and consequences. Prevent unlinking the last viable recovery method. Account linking/unlinking requires clear confirmation and may require step-up.
- Privacy/data rights reuse SCR-038: view consent, withdraw optional consent, request export, request erasure and see request status. Deletion is separated in a danger zone and requires re-authentication and confirmation of consequences.

## 6. Workflows

Each workflow lists actors, steps, failure and recovery, and notifications and audit. State names are in section 7.

| ID | Workflow | Actors and steps | Failure and recovery | Notifications and audit |
| --- | --- | --- | --- | --- |
| WF-001 | Member: discovery to first value | Visitor reads Home and Fees, joins, verifies email, picks Fresher or Experienced, completes required details, reviews the parsed resume, sets consent, reaches the Dashboard, takes a first action | Wrong or expired code gives a clear message and a resend after a cooldown; a parse failure falls back to manual entry | Welcome email; consents recorded with times |
| WF-002 | Evidence verification | Member adds evidence and confirms accuracy; skill shows Pending; reviewer ticks two checks and decides: Approve, Need more evidence, or Reject (reason of 10 or more characters); rejected evidence can be appealed once; approved evidence can be revoked and expires on its date | A decision without both checks or a reason is refused | Member told of every decision; audit records who, when, reason, policy version |
| WF-003 | Assessment to verification (Planned) | Discover, check eligibility, read instructions, attempt, submit, see the result; a pass creates an evidence record for review; the reviewer decision issues the badge or sends the member to practice | Autosave protects answers; attempts and retake gaps enforced | Result notification; audit of the decision |
| WF-004 | Lab practice | Open lab, work through observe, hypothesize, test, collect evidence, root cause, fix, explain, prevent; submit four parts; a reviewer scores four areas 0 to 4; the member can resubmit up to three attempts | A fourth attempt is refused | Member told of the result; review recorded |
| WF-005 | Community question and moderation | Ask (mode, title, detail, sensitive-data confirmation); others answer and vote; the asker accepts one answer; anyone can report with a reason; a moderator dismisses or removes | Removal needs a reason shown to the author | Moderator action audited |
| WF-006 | Recruitment, end to end | Recruiter drafts a position and submits it; reviewer publishes or requests changes; members apply; Admin screens and shortlists; a person forwards; the recruiter reviews with a scorecard, decides, schedules interviews, records an outcome, extends an offer; the member accepts or declines; the recruiter marks Joined | A declined offer lowers the filled count and can pause a position that had closed as fulfilled | Member told at every stage; recruiter reminded after 10 working days without an update (PRD-051); every step audited |
| WF-007 | Fee consent and invoicing | Role shows the fee; apply with declaration and permission; accept the offer with the exact amount and a second confirmation; recruiter marks Joined; invoice created, due in 15 days; member pays through the checkout | No offer, a declined offer or a withdrawal owes nothing | Invoice email; payment audit |
| WF-008 | Admin action with audit | Sign in with MFA; open the queue; choose an action; sensitive actions ask for a reason and a fresh code; the action runs | A refund requested by an Admin waits for a SuperAdmin | User notified; audit entry written |
| WF-009 | Content publishing | Instructor drafts with required details; submits; reviewer publishes or requests changes with a reason; learners see it as Available; an Admin can unpublish | Publishing without required metadata is refused | Author notified |
| WF-010 | Paid service and refund | See the price and GST; pay; receive receipt and access; a refund needs a reason | Failed payment keeps the cart and says why | Receipt; refund audited |
| WF-011 | Data rights and consent (Planned) | Member views consents, withdraws one, exports data or requests erasure; the system confirms, completes within the policy period and logs it | A pending request can be canceled during the grace period | Confirmation emails; audit |
| WF-012 | Company onboarding (Planned) | Recruiter signs up with a work email; enters company details; Admin reviews; approved companies can publish; the first position is always reviewed | Changes requested shows the reason and lets the recruiter edit and resubmit | Recruiter notified of each status; audit |
| WF-013 | Hide from companies (Proposed) | Member adds company names; those companies stop seeing the profile in search and forwarded lists | A name that matches several companies asks the member to choose | Audit of changes |
| WF-014 | Community knowledge loop (Proposed) | Member discovers a topic, opens a structured post, asks/answers or publishes a case study, saves/follows it, and follows links to related knowledge, learning or practice | Draft autosave, sensitive-data warning, duplicate suggestion, report/mute controls | Contribution and content events; no public exposure beyond visibility policy |
| WF-015 | Groups, events and mentoring (Proposed) | Member joins a curated group, RSVPs to an event or requests a mentor with a goal; host/mentor accepts or declines; useful resources are attached afterward | Capacity, schedule/time-zone conflict, decline reason and cancellation paths are explicit | RSVP/reminder delivery; membership and moderation audit |
| WF-016 | Automated skill-verification experiment (Experiment candidate) | Policy selects Manual, AI-assisted or Automated mode; evidence is checked against versioned criteria; high-confidence outcomes may be decided automatically; configured uncertain/high-risk cases route to human review; member can appeal/re-request review | Feature flag off, model/policy unavailable, insufficient evidence, low confidence, conflicting signals and appeal all route to safe/manual handling | Store evidence references, decision reason, confidence band, policy/model version, timestamp and actor/system; notify member; append-only audit |


| WF-017 | Resource discovery, contribution and curation | Member discovers/searches/filters resources; opens detail; saves or adds to a collection; contributor drafts a resource, supplies content/source/licence, submits for review; moderator validates and publishes or requests changes | Broken link, unsupported file, unsafe file, missing rights/attribution, scan failure or moderation rejection preserve the draft and show a reason; member can replace/re-submit where allowed | Resource view/save/download/share events; resource version and review audit; no private file URL leakage |
| WF-018 | Signup and personalised onboarding | Visitor selects sign up; registers by email/password or passkey (optional provider sign-in when configured); verifies email; chooses role, interests and goals; completes/skip optional profile details; lands on personalised dashboard | Provider unavailable falls back to email; expired code can be resent after cooldown; onboarding can be resumed; preferences editable later | Consent timestamp/version, verification result, provider link audit and onboarding preference event |
| WF-019 | Profile and account management | Member views/edits professional profile; previews self/community/recruiter-after-forwarding views; changes visibility; opens Account Settings; manages notifications, security, sessions, connections and data rights | Sensitive fields remain hidden by policy; account-link failure does not lock member out; deletion requires re-authentication; privacy changes take effect immediately or show pending status | Visibility and consent changes audited; account security events logged; export/erasure follows WF-011 |
| WF-020 | Parent-child and nested navigation | User enters a parent section, opens child detail or workflow, moves between sibling tabs/records and returns to the parent | URL and breadcrumb reflect location; browser Back/Forward works; preserve parent query/filter/selection/scroll/focus where feasible; child route permissions are checked server-side; mobile uses an obvious full-screen child route when a split panel is unsuitable | Navigation events avoid private content in URLs; focus returns to the invoking control; no stacked modal traps |
| WF-021 | Embedded recording/media playback | User opens a resource/course recording, plays or pauses, seeks, changes speed/quality, reads transcript/chapters, resumes later and follows related content | Media source type selects the right adapter; external provider is allow-listed; captions/transcript availability is explicit; failures have retry/open-provider/fallback states; playback progress respects privacy and parent visibility | Playback progress is scoped to the member; provider events are handled safely; no autoplay with sound |
| WF-022 | File upload, processing and preview | User selects or drops media/document, validates, uploads with resumable transport where supported, scans, transcodes/generates preview and submits for review | Pause/resume/retry/cancel states are real; file signature and size/type validated server-side; scan/transcode errors do not publish; unsupported files have a safe fallback; upload ownership and signed access are enforced | Upload/process events are auditable; private URLs are short-lived; malicious files never enter preview pipeline |
| WF-023 | Resource child-view navigation | User opens resource detail, then jumps to Watch/Read, Transcript, Discussion, Versions or Source and returns | Parent resource context and selected child tab stay available; deep links open at the correct child state; mobile preserves a back path | No dead-end child panes; access rights are inherited from the resource and checked on every sub-route |
| WF-024 | Audio waveform and transcript interaction | User opens an audio-only recording, views waveform, seeks by tapping/dragging, jumps to transcript/chapters and resumes listening | Waveform is optional and source-specific; pre-decoded peaks are used for streams/large files where required; normal audio controls remain available if waveform fails or is disabled | Keyboard seek, screen-reader time controls, reduced-motion behaviour and progress privacy are tested |

## 7. State models

Each model lists states, allowed moves and moves the server must reject.

&#91;embedded content: application lifecycle · 9 steps, 3 early endings\]

| Model | States | Allowed moves | Moves to reject |
| --- | --- | --- | --- |
| Application | Received, Processing, Under review, Shortlisted, Ready to forward, Forwarded, Interview, Selected, Joined; Rejected, Withdrawn, Job closed | Forward only after screening; Interview after Forwarded; Selected after Interview; Joined after an accepted offer | Joined without an accepted offer; any change after Withdrawn |
| Recruiter decision | Under review, Shortlisted, On hold, Rejected | Any to any until a final outcome; Rejected sets the application to Not selected | A decision change after Selected or Joined |
| Position | Draft, In review, Changes requested, Published, Paused, Closed (Fulfilled or Unfulfilled) | Submit, publish, request changes; pause and resume; close; reopen | Publish without review; reopen without a future deadline or with openings not above the filled count |
| Company | Pending, Approved, Changes requested, Suspended | Admin approves or asks for changes; suspend with a reason | A position published by a Pending company |
| Evidence | Pending, Needs more evidence, Approved, Rejected, Appealed, Revoked, Expired | Decide from Pending or Appealed; resubmit from Needs more evidence; appeal once from Rejected; revoke from Approved; expire by date | Approve without both checks; a second appeal; a decision by a non-reviewer |
| Lab submission | Under review, Needs revision, Passed, Failed | Decide from Under review; resubmit from Needs revision up to attempt 3 | A fourth attempt; a pass with any area below 2 |
| Assessment attempt | In progress, Submitted, Passed, Not passed, Expired | Submit before the time ends; retake after the gap | A second active attempt; a retake inside the gap |
| Offer | Extended, Accepted, Declined, Joined | Accept or decline from Extended; Joined from Accepted | Accept after the validity date; Joined from Declined |
| Fee invoice | Due, Paid, Refunded | Created after Joined; paid; refunded | An invoice before Joined or after a declined offer |
| Badge | Earned, Displayed, Expiring, Expired or Revoked, Renewed | Expiring 60 days before expiry; renewal by new evidence | Display after Expired |
| Notification | Queued, Sent, Delivered, Read, Failed | Retry from Failed within a limit | Sending after an opt-out |
| Moderation report | Open, Dismissed, Removed | Decide from Open | Removing without a reason |
| Community content | Draft, In review (where required), Published, Hidden, Archived | Publish according to content type and permissions; hide/remove with reason; appeal/restore through policy | Publishing blocked content; silent deletion of audited records |
| Group membership | Requested, Active, Muted, Left, Removed | Join/open group according to visibility; moderators remove with reason; member may leave | Access to private group without membership |
| Event RSVP | Interested, Registered, Waitlisted, Cancelled, Attended, No-show | RSVP subject to capacity; waitlist promotion; host records attendance | Over-capacity registration without waitlist rule; time-zone ambiguity |
| Automated verification decision | Queued, Evaluating, Auto-approved, Auto-rejected, Needs human review, Appealed, Reversed, Failed | Only when experiment flag and policy active; decision records model/policy version; appeal triggers re-review | Missing evidence, missing policy version, disabled flag, out-of-range confidence or unaudited decision |

| Content | Draft, In review, Changes requested, Published, Archived | As in PRD-022 | Publish without required details |

| Resource | Draft, Submitted, In review, Changes requested, Published, Hidden, Archived, Rejected | Submit after metadata/content checks; reviewer publishes or requests changes/rejects with reason; author edits and resubmits where permitted; hide/archive preserves audit/version history | Publish before required scan/rights checks; silent deletion of published/used resource; download without permission |
| Saved resource | Not saved, Saved, In reading list, In progress, Completed, Removed | Member saves/unsaves; moves to own collections; reading progress updates only when supported | Deleting a saved pointer deletes the source resource; sharing a private collection without owner action |
| Upload item | Queued, Uploading, Paused, Processing, Scanning, Complete, Failed, Canceled, Rejected | Actual transport progress; resume only if supported; replace/retry on failure; publish only after processing and scan success | Fake progress; treating upload complete as safe/published; pause/resume when transport does not support it |
| Signup | Draft, Email pending, Verified, Onboarding, Active, Recovery required, Suspended, Closed | Verify within expiry; resend on cooldown; recover through allowed method; onboarding can resume | Active account before required verification; linking provider without ownership confirmation; bypassing age gate |

## 8. Screen-to-system traceability

Chain: screen, component, user action, workflow, capability (API in Document 4), data, permission, acceptance test (TEST in Document 4). A screen without a capability row is a demonstration, not a feature. A task is complete only when its screen, capability, data and test rows all exist and pass.

| Screen | Action | Workflow | Capability | Data | Permission | Acceptance |
| --- | --- | --- | --- | --- | --- | --- |
| SCR-D01 Apply | Submit application | WF-006, WF-007 | API-024 | Application, consent | Member | TEST-021: both fee ticks required; consent stored with a time |
| SCR-D03 Evidence review | Save decision | WF-002 | API-017 | Evidence, approval, audit | Admin, SuperAdmin | TEST-016: approval without two checks is refused |
| SCR-015 Review detail | Save review | WF-004 | API-020 | Submission, review | Reviewer | TEST-018: a pass needs every area at 2 or more |
| SCR-020 Candidate review | Save decision, schedule | WF-006 | API-027, API-028 | Application, scorecard, interview | Recruiter (forwarded) | TEST-025: an unforwarded candidate returns not available |
| SCR-009 Applications | Accept offer | WF-007 | API-030 | Offer, invoice | Member (own) | TEST-029: fee shown and confirmed before acceptance |
| SCR-029 Users | Reset link | WF-008 | API-040 | User, audit | SuperAdmin | TEST-038: step-up lockout after repeated bad codes |
| SCR-032 Security | Save limits | WF-008 | API-043 | Security settings, audit | SuperAdmin | TEST-040: out-of-range values are refused |
| SCR-033 Company onboarding | Submit for review | WF-012 | API-051 | Company, audit | Recruiter, Admin | TEST-048: an unreviewed company cannot publish |
| SCR-034 Assessment attempt | Submit attempt | WF-003 | API-052 | Attempt, result | Member | TEST-049: autosave, resume and attempt limits hold |
| SCR-044 Hide from companies | Add company | WF-013 | API-053 | Blocked company | Member (own) | TEST-046: a hidden company never sees the profile |


### 8.1 Added traceability targets

| Screen / workflow | Action | Capability | Data | Acceptance target |
| --- | --- | --- | --- | --- |
| SCR-047 / WF-014 | Change feed view, follow/mute/save topic | API-054 | Feed preference, follow, bookmark, content | TEST-052 |
| SCR-048 / WF-014 | Save/publish structured post | API-055 | Content, tags, attachment, revision | TEST-053, TEST-054 |
| SCR-049 / WF-014 | Search and open related knowledge | API-056 | Search query, taxonomy link, result | TEST-055 |
| SCR-050 / WF-015 | Join/leave group | API-057 | Group, membership, moderation event | TEST-056 |
| SCR-051 / WF-015 | RSVP/cancel/check in | API-058 | Event, RSVP, attendance | TEST-057 |
| SCR-052 | View/edit contribution visibility | API-059 | Contribution, visibility rule | TEST-058 |
| SCR-053 / WF-016 | Configure/run/review verification mode | API-060 | Verification policy, evaluation, decision, appeal, audit | TEST-059 to TEST-061 |

### 8.2 Resources and identity traceability targets

| Screen / workflow | Action | Capability | Data | Permission | Acceptance target |
|---|---|---|---|---|---|
| SCR-054 / WF-017 | Search, filter, open resource | API-061 | Resource, tags, search event | Member, visibility filtered | TEST-065 |
| SCR-055 / WF-017 | Preview, download/open, save, report | API-061, API-064 | Resource version, access event, bookmark | Member; published/allowed only | TEST-066 |
| SCR-056 / WF-017 | Upload/link/article, submit | API-062, API-063 | Resource, revision, attachment, rights | Member/Contributor | TEST-067, TEST-068 |
| SCR-057 / WF-017 | Save, collection, reading progress | API-064 | Saved resource, collection, progress | Member (own) | TEST-069 |
| SCR-058 / WF-017 | Review/publish/request changes | API-065 | Review, version, audit event | Moderator/Admin | TEST-070 |
| SCR-003 / WF-018 | Register, verify, provider sign-in | API-001, API-002, API-068 | User, consent, provider identity | Public/own account | TEST-071 |
| SCR-059 / WF-018 | Save onboarding role/interests/goals | API-066 | Onboarding preference | Member (own) | TEST-072 |
| SCR-012 / SCR-060 / WF-019 | Edit profile and preview audiences | API-005, API-067 | Profile, field visibility | Member (own); preview is policy scoped | TEST-073 |
| SCR-061 / WF-019 | Update account, notifications, privacy and security | API-005, API-009, API-038, API-039, API-040 | Account preference, session, data request, consent | Own account; step-up for sensitive actions | TEST-074, TEST-075, TEST-076 |
| SCR-063 / WF-019 | Link/unlink connected identity providers | API-068 | Connected identity, provider consent and link history | Own account; step-up when needed | TEST-075 |
| SCR-038 / WF-019 | Export or request erasure | API-009 | Data request, consent | Member (own) | TEST-076 |

### 8.3 Media and nested workflow traceability targets

| Screen / workflow | Action | Capability | Data | Permission | Acceptance target |
|---|---|---|---|---|---|
| SCR-064 / WF-021 | Open/play recording, read transcript/chapters, resume and optionally view waveform | API-069, API-070, API-075, API-077 | Media asset, playback progress, captions/transcript, waveform peaks | Parent resource/course access; member-scoped progress | TEST-077, TEST-083, TEST-084 |
| SCR-065 / WF-022 | Preview supported file or use safe fallback | API-074 | Media asset, source file and derived preview | Source file permissions preserved | TEST-080 |
| SCR-066 / WF-022 | Create upload, pause/resume/retry/cancel and process | API-072, API-073 | Upload session, processing job, media asset | Uploader/reviewer; private signed access | TEST-079 |
| SCR-067 / WF-021 | Resolve and inspect approved provider embed/source | API-071, API-075 | External media source, provider status, captions | Parent resource and provider policy | TEST-078 |
| WF-020, WF-023 | Resolve nested child state and restore parent context | API-076 | Parent/child route state | Server-side route permission | TEST-081 |

## 9. Media, embedded files and parent-child screen behaviour

### SCR-064 — Recording / Media Viewer

**Layout:** Parent resource header and breadcrumbs; primary player; optional transcript/chapter side panel; below/adjacent metadata, captions, notes, discussion and related resources. Audio-only assets may show an optional waveform timeline and region markers. On narrow screens the player remains the primary content and chapters/transcript become tabs or bottom sheets.

**Controls/states:** play/pause, seek, volume, speed, quality where available, captions, transcript, chapters, fullscreen, PiP where supported, source/provider, resume, playback error, network recovery, restricted access, unavailable provider and unsupported codec. Audio waveform, regions and timestamp markers are optional enhancements and should fail back gracefully to familiar audio controls. Keyboard controls and visible focus are essential. No autoplay with sound.

**Recording cards:** show title, thumbnail, duration, source label, caption/transcript indicators, progress and last-viewed state. Keep decorative patterns outside text and control surfaces.

### SCR-065 — Embedded File Preview

Choose a viewer by validated file type: PDF viewer; optimized image viewer; audio/video player; syntax-highlighted text/code/Markdown; virtualized CSV/table preview; supported Office preview via isolated conversion or approved editor. For unknown, unsupported or blocked formats show a clear explanation, safe download when authorised, and report/retry path. Never render raw HTML or macros.

### SCR-066 — Upload Manager / Processing Detail

Support multi-file selection, drag/drop, per-file queue, aggregate progress, pause/resume/retry/cancel, remove/replace, network interruption, duplicate warning, size/type errors, scanning, thumbnail generation, transcoding, moderation and publication. Use real server progress/status. If a prototype uses mock media processing, label it visibly as a prototype state.

### SCR-067 — Media Embed and Source Details

Show original source/provider, resource owner, licence/attribution, embed provider, caption/transcript availability, provider playback status and a report-broken-source control. Provider errors should not break the parent resource page.

### Nested-screen composition guidance

- **Parent page:** establishes section context, filters, selected record and primary task.
- **Child route:** use for substantial workflows, deep links, browser history and pages with their own meaningful state.
- **Contextual drawer/sheet:** use for quick inspection, editing a small set of fields or reviewing details without losing the parent workspace. A route-backed drawer may be used when the detail must be shareable.
- **Inline expansion:** use for small supplementary detail, not large forms or complex media readers.
- **Mobile:** convert complex child panes into full-screen routes or clearly titled sheets with a visible back/close action.
- **State restoration:** keep search, filters, sort, selected parent record and scroll position where feasible. Restore keyboard focus to the invoking control.
- **Avoid:** modal-on-modal, hidden hierarchy, changing the parent background as a navigation cue, and controls that open a child surface without announcing its title.

## 9. Revision history

| Date | Version | Change |
| --- | --- | --- |
| 26 Nov 2026 | 3.6 | Clarified nested parent-child workflows, adaptable child-surface patterns, media-resolver and embed states; aligned screen IDs with owner-supplied reference assets and review-build flow |
| 26 Nov 2026 | 3.5 | Expanded media and nested-resource UX; confirmed API mapping separation (Resources/Identity 061–068; media 069–077); added optional WaveSurfer audio waveform |
| 26 Nov 2026 | 3.4 | Corrected Resource/Identity API traceability and added media/nested traceability targets for APIs 069–077, including optional WaveSurfer waveform details |
| 26 Nov 2026 | 3.3 | Added optional WaveSurfer audio waveform interaction and accessible seeking/fallback behaviour |
| 26 Nov 2026 | 3.2 | Added SCR-064 to SCR-067 for media, previews and uploads; WF-020 to WF-023 for nested navigation, playback and upload lifecycle |
| 25 Nov 2026 | 3.1 | Added Resources screens SCR-054 to SCR-058, onboarding SCR-059, visibility preview SCR-060, Account Control Centre SCR-061 to SCR-063; expanded signup/profile flows |
| 24 Nov 2026 | 3.0 | Added Editorial/Analytical workspace mapping, Matte Black dashboard reference, Community IA and automated verification experiment flow |

## 10. Related documents

---

# Notion screen specifications and onboarding consolidation — 27 November 2026

This section consolidates current Notion screen pages into the canonical flow guide. The Notion pages remain the detailed working records; their statuses below are not production implementation claims.

## Onboarding sequence

**SCR-003 → SCR-004 → SCR-005 → community/home**

### SCR-003 — Create Account & Email Verification (`/join`)

Finalized at screen-spec level; implementation/repository audit pending. Unauthenticated visitor creates an eligible account using email, DOB, password and required Terms acceptance/Privacy acknowledgement. Eligibility is 18+ in the prototype; under-18 does not create a member profile and OPEN-20 counsel sign-off remains a production gate. DOB is private and never recruiter-visible. Do not add a redundant 18+ checkbox. Account state remains pending until server-side email verification.

Email verification uses a six-digit code, 10-minute expiry, maximum five attempts in the approved prototype, and limited resends governed authoritatively by server cooldown/rate limits. Provide masked destination, paste/autofill, verify, resend and change-email; changing email invalidates the prior challenge. Use non-enumerating responses for existing addresses, prevent duplicate submissions, preserve recoverable form values and show honest loading/error/expired/locked states. After verification, choose **Fresher** or **Experienced** as an experience track—not an RBAC role. Continue to SCR-004. Passkey/OAuth buttons appear only if genuinely configured.

Desktop split layout (brand panel + constrained form); tablet/mobile single column, compact brand and form-first hierarchy. Use concise copy and approved original SVG/CSS illustration only; omit/reduce illustration on mobile. 44px touch target, visible labels/focus, keyboard/screen-reader support, reduced motion and 200% zoom. No full CV fields at signup.

### SCR-004 — Personalise Your Experience (`/onboarding/personalise`)

Verified account and SCR-003 experience track are prerequisites. Progressive three-step **Role → Interests → Goals**; role single-select (including “Not sure yet”), interests multi-select recommended 1–5, goals multi-select recommended 1–3. Use existing taxonomy IDs and reconcile with current product taxonomy before implementation. Role/interests/goals are preference signals—not permissions, verified skills or eligibility. Never grant recruiter/admin/moderator/instructor privileges from self-selection.

Keep the flow compact, single-column, skippable and reversible. Back preserves selections; save/finish persists via existing preference/profile service; retry retains local state; no false defaults if skipped. Completion marker and selections are persisted only on confirmed success. Community access is not blocked by skipping. Re-entry is edit mode with prefilled choices, not a restart. A general feed remains useful when preferences are absent.

### SCR-005 — Profile Readiness & Visibility Preview

Follows personalisation and precedes community/home entry as documented in the current onboarding flow. Explain optional profile improvements versus fields required for consequential actions (such as applying); show an audience/visibility preview and what each audience can see. Do not invent arbitrary profile-completeness percentages, expose private data or imply “recruiter ready”/verified status without rules and evidence. User can skip, continue, edit and control visibility. Confirm the actual privacy model, canonical route and required-field rules in repository/product source before implementation.

## Notion screen-spec status and traceability

| Screen | Current documented status | Not yet established |
|---|---|---|
| SCR-003 | Finalized screen spec; engineering handoff and starter component package exist | Production integration, actual API/schema/routes, full test suite, legal 18+ approval |
| SCR-004 | Product workflow/spec documented; role/interests/goals taxonomy and behavior defined as proposed/approved direction | Canonical taxonomy, route, persistence service and implementation |
| SCR-005 | Screen spec documented for readiness/visibility and privacy | Actual permission/visibility model and repository validation |

Notion references: SCR-003 https://app.notion.com/p/425520a4e1138154b32ec44ef10a1465 ; SCR-004 https://app.notion.com/p/425520a4e11381b79f0be1fd4931ac7b ; SCR-005 https://app.notion.com/p/425520a4e11381fb8b5ef0567984be3d ; SCR-003 implementation handoff https://app.notion.com/p/425520a4e11381919e7dc8553a34db42 .

## Shared screen-spec standard

Every screen must document: purpose/success condition; entry/prerequisites; every user action; immediate and server-confirmed response; states/transitions; validation/boundaries; data creation/update/retention/deletion; privacy/permissions; notification/feedback; navigation/deep links/history/session continuity; accessibility/responsive/reduced motion; edge cases/abuse; acceptance criteria/test scenarios; unresolved decisions and improvement room. Claude audits existing architecture and patterns first; product-visible workflow, policy, data collection, permissions or success-criteria changes return for owner approval.

## Current capability inventory note

The Notion Required Product Components & Capability Inventory is a cross-product checklist (shared foundations, community, learning, assessment, verification, jobs/recruitment, payments, operations). It complements the UI component/library registry and must be marked implemented only after repository evidence. https://app.notion.com/p/425520a4e11381039756de0a666184cd


# Appendix — Resources and identity discussion record (25 Nov 2026)

# PacketPulse 2.0 — Discussion Record: Resources and Member Identity Experiences

**Date:** 25 November 2026  
**Status:** Owner-approved prototype scope for the next review build  
**Related canonical documents:** Documents 1–5, versions 5.1 / 4.1 / 3.1 / 4.1 / 1.2  
**Purpose:** Capture the two most recent design discussions: Community Resources and Signup/Profile/Account. This document records the visual intent, full workflows, interaction states and review-build decisions. It is not production implementation evidence.

---

## 0. Owner direction and review-build decision

The owner explicitly directs the team to **be open, creative and experimental** with patterns, components, colours, layouts, imagery, typography and microinteractions. This is an affirmative design decision, not a request for a fixed narrow palette.

All items in these two discussions, including previously open-for-approval recommendations, are **Approved Prototype**. They must be represented in the next prototype/review build. This means the team should create working front-end flows with realistic sample data and safe sandbox/mock states where integrations are not ready.

Prototype approval is not production approval. Do not process live payments, enable real OAuth providers without configuration, publish unsafe files, expose private profile data or bypass legal/security checks. During the team review window, capture feedback and decide for the next build: **Retain, Refine, Restrict or Remove**.

## 1. Discussion A — Community Resources

### 1.1 Product purpose

Resources should feel like a curated engineering knowledge library—not a generic downloads page or an unstructured folder. It is a first-class Community capability that helps members discover, understand, save, reuse and contribute technical knowledge.

Resource types include:

- Guides and technical documentation
- Tools and utilities
- Configuration templates and scripts
- Courses and learning paths
- Videos and recorded sessions
- Cheat sheets and reference sheets
- Labs and practical exercises
- Repositories and code examples
- Technical articles and case studies
- Diagrams and architecture references

### 1.2 Screen 1 — Resources Library / discovery hub

**Route:** `/community/resources`  
**Audience:** Members and approved contributors  
**Primary action:** Share a resource

**Layout:** Signal Grove Editorial Workspace with Matte Black as the approved prototype visual variant and a fully designed light counterpart. Persistent PacketPulse shell and Community navigation; page title and search; featured collection banner; discovery tabs; filter row; resource-card grid/list; optional contextual rail.

**Discovery tabs:** For you, Featured, Recent, Popular, Staff Picks.

**Filters:** Category, Format, Technology, Difficulty, Intended audience, Language and Sort.

**Resource card:** Type icon or thumbnail; title; short value statement; technology/category chips; author/source; difficulty and estimated time (when known); updated/reviewed date; save action; reviewed/official/source status when real evidence exists.

**Optional rail:** Popular topics, newly added resources, curated collections and Continue reading. The rail collapses on tablet and becomes a sheet/stack on mobile.

**States:** Loading, first-use empty, no results, error/retry, resource removed/archived, permission-restricted, saved and unsaved.

### 1.3 Screen 2 — Resource detail / reader

**Route:** `/community/resources/[id]`

A reading-first work surface. The resource preview is primary; a table of contents/page navigation may sit beside it; a contextual details rail displays:

- Resource type and format
- Title and description
- Author/contributor and source
- Technology/category tags
- Difficulty and estimated time
- Version and last-reviewed date
- Licence and attribution
- Open/download/share/save/report actions
- Related resources and linked Community discussions

Document, article, video and external-link resources use appropriate preview patterns. Long-form content uses Reading density and a comfortable line length. If preview is unsupported, explain why and offer a safe open/download action where permitted. A broken external link must be reportable. Do not fabricate ratings, verification or review claims.

### 1.4 Screen 3 — Share a Resource wizard

**Route:** `/community/resources/share`

Three steps, always recoverable:

1. **Details:** Title, short description, resource type, category, taxonomy-backed technologies, difficulty, audience, language and estimated time.
2. **Content:** Upload a file, paste a URL or write an article. Preview the result. Save draft at any point.
3. **Review & publish:** Confirm source/author, attribution, licence/usage rights, version, review date, audience visibility and community guidelines. Submit for review or publish if policy permits.

File lifecycle: Queued → Uploading → Paused (only when supported) → Processing → Scanning → Complete, or Failed/Canceled/Rejected. Progress reflects actual bytes transferred. Completed upload is not the same as a safe or published resource. Preserve the draft after failure. Require configured file validation and malware scanning. Rights/attribution and moderation rules apply.

### 1.5 Screen 4 — Saved Resources and Collections

**Route:** `/community/resources/saved`

Tabs: All saved, Reading list, My collections, Recently viewed. Include collection cards with name, description, count, visibility, representative cover and last-updated information. Include Continue reading for resources that support meaningful progress. Saved state is separate from reading progress. Removing a bookmark never deletes the underlying source resource. Collections can be private or shared explicitly by the owner.

### 1.6 Moderator workflow

A dedicated review queue shows Pending review, Changes requested, Scan/link issues and Recently published. Reviewer opens a submission with content preview, metadata, source/rights/attribution, scan status, link health and revision history. Actions: Approve, Request changes, Reject, Hide or Archive. Non-approval actions require a reason; all actions are audited and the author receives a clear status update.

### 1.7 Resource design components

- Resource discovery hero / featured collection
- Resource cards by type and format
- Search and multi-dimensional filter bar
- Resource reader/document viewer
- Table of contents / page thumbnail rail
- Resource metadata and attribution block
- Licence and usage-rights selector
- Share Resource stepper
- Upload/dropzone and complete upload lifecycle card
- Upload validation, scanning and warning states
- Saved collection card and reading-state indicator
- Related resources and discussion panel
- Resource moderation queue and review panel

**Visual direction:** generous whitespace; high-quality technical diagrams and occasional editorial imagery; compact metadata; matte-black surfaces for the dark prototype; forest/teal brand surfaces and restrained lime emphasis; resource-type accents may be explored but always include text labels. Avoid turning every card into a colourful tile.

## 2. Discussion B — Signup, Profile and Account

### 2.1 Product principle

Signup is the beginning of an engineering journey, not a long CV form. Profile is how a member presents their professional/community identity. Account is how the member controls their relationship with PacketPulse. Keep Profile and Account separate in navigation and information architecture.

### 2.2 Screen 1 — Create Account / Signup

**Existing screen expanded:** SCR-003, `/join`  
**Audience:** Visitors  
**Primary action:** Create account

**Layout:** Split-screen on wide displays. One panel carries PacketPulse brand promise (“Build your engineering journey”, “Learn. Share. Grow Together.”) and a restrained network/engineering illustration. The other panel contains a focused registration form. On mobile, collapse to one column and remove decorative clutter.

**Methods:** Email/password or passkey as the baseline; Google and GitHub sign-in buttons are approved prototype elements. Real OAuth is enabled only after provider configuration and security checks. Until then, mock clearly or show disabled/unavailable state—never imply a real authentication succeeded.

**Fields and controls:** Email, password with show/hide, password guidance, Terms of Service and Privacy Policy consent, create account, existing-account sign-in and account recovery. Verification is a six-digit code with expiry, attempt/resend limits, change-email control and accessible error feedback.

Minimise friction. Do not ask for all career, resume and skill information before a member experiences value unless a protected product workflow requires it.

### 2.3 Screen 2 — Personalised onboarding

**Proposed route:** `/onboarding/personalise`  
**Primary flow:** Role → Interests → Goals

**Role choices:** Student, Engineer, Specialist, Mentor, Recruiter. A user can have additive roles later; role selection here personalises the first experience and must not grant privileged permissions.

**Interest choices:** Networking, Cybersecurity, Cloud, Automation, Infrastructure and taxonomy-backed topics. Support search and multi-select. Unknown terms enter a taxonomy suggestion route; they do not silently become canonical skills.

**Goal choices:** Learn, Practice, Contribute, Mentor, Find opportunities.

Show a clear stepper, selected states, Back/Continue, Skip optional step and “You can change this later”. Finish with a useful landing page and editable preferences. Onboarding data does not affect recruiter visibility or verification status.

### 2.4 Screen 3 — Professional Member Profile

**Existing screen expanded:** SCR-012, `/profile`

The profile becomes a living professional identity and record of community contribution.

**Identity hero:** Avatar, member name, professional headline, optional location/timezone, short introduction, edit profile action and explicit verification indicator(s). A subtle network-inspired cover or member-selected image may be explored; identity stays the focal point.

**Sections/tabs:** Overview, Skills, Experience, Education & Certifications, Contributions, Learning, Mentoring, Activity and Achievements where data exists.

**Skills:** Show separate labels for Self-declared, Assessment verified, Experience verified, Certification verified and PP verified. A badge detail view shows issuer/reviewer, evidence, criteria, date and expiry where the viewer is permitted. Self-declared skills never appear as verified. Community reputation is separate from skill verification and certification.

**Contributions:** Solved questions, helpful answers, knowledge articles, case studies, mentoring and curated resources, each with its own visibility controls. Emphasise meaningful contributions, not follower/vanity metrics.

### 2.5 Screen 4 — Profile Visibility Preview

**Route:** `/profile/preview`

Three preview modes:

- My view
- Community member view
- Recruiter after forwarding

Each preview must use the same backend field-level policy as actual data access. Show why private fields are hidden and provide a settings shortcut. Date of birth, compensation, private notes, contact details and resumes stay protected under the existing visibility/consent model. Public web profile remains opt-in/later and off by default.

### 2.6 Screen 5 — Account Settings Control Centre

**Route:** `/settings`

Spacious card-based settings hub. Sections:

- Personal Information
- Profile Visibility
- Notifications
- Login & Security
- Sessions and Devices
- Connected Accounts
- Privacy & Data Rights
- Billing & Payments (when relevant)

Each card includes a concise explanation and a Manage/Edit action. Use dedicated subpages for complex settings rather than long accordion walls.

### 2.7 Child account windows

**Notifications:** event categories by channel, in-app/email/opt-in WhatsApp, quiet hours, digest frequency, transactional vs marketing separation, save confirmation.

**Login & Security:** password/passkey, MFA state, recovery options, active sessions, sign out other sessions, recent security events. Stronger staff rules remain enforced.

**Connected Accounts:** Google, GitHub and LinkedIn where configured; display provider, linked identity, scopes and unlink action. Prevent unlinking the last recovery route. Require re-authentication where appropriate.

**Privacy & Data Rights:** consent history, change/withdraw optional consent, data export request, erasure request, request status and retained-data explanation. Deletion lives in a distinct danger zone with consequences and re-authentication.

**Profile completeness assistant:** optional, dismissible suggestions for useful missing fields. Never demand 100%, shame the member, block navigation or imply that completeness guarantees hiring.

**Identity activity timeline:** optional milestones such as skill verified, assessment completed, resource shared, answer accepted or mentoring completed. Member controls visibility.

### 2.8 Identity and account design components

- Split-screen Signup layout
- Email/password/passkey field group
- Google/GitHub provider buttons
- Six-digit verification input and recovery states
- Role selection cards
- Interest/taxonomy multi-select chips
- Goals selector and onboarding stepper
- Professional identity hero and profile cover
- Verification-aware skill groups
- Contribution summary cards
- Profile audience-preview switcher
- Profile completeness assistant
- Identity activity timeline
- Account settings category cards
- Notification preference matrix
- Security and active-session list
- Connected-account row with recovery guard
- Privacy/data export/erasure panel and danger zone

**Visual direction:** Matte Black variant for the dark prototype; Soft Signal Light counterpart; high-contrast form controls; generous field spacing; forest/teal trust surfaces; lime for one primary action or selected emphasis; module accents only where context helps. Keep login forms focused and profile screens expressive but readable.

## 3. Cross-cutting interaction and accessibility rules

- Keep the shared PacketPulse shell where it helps; unauthenticated signup remains a focused standalone layout.
- Use generous whitespace and Comfortable density by default. Compact is reserved for moderation/review tables. Reading density applies to resource content.
- Buttons, cards, tabs, menus, upload controls and stepper are keyboard accessible and expose visible focus.
- Use microanimations only for action acknowledgement, transition/orientation, upload progress and meaningful milestones. Respect reduced motion.
- Status always uses text plus a glyph, not colour alone.
- Resource file upload and provider sign-in must show real or explicitly mocked state; no fake progress or false success.
- Preserve drafts and progress on recoverable errors.
- Profile preview must enforce real visibility rules; client hiding alone is not security.
- Provide light and dark themes; Matte Black is the preferred analytical/dark product treatment, not a mandate for every page.
- Verify WCAG 2.2 AA, screen reader labels, focus order, responsive reflow and contrast in every major state.

## 4. Approved prototype review process

All features and patterns above are approved for the next review build. During review, collect:

- First-time signup completion and time to first value
- Onboarding skip/complete and preference-edit rates
- Resource search success, zero-result searches, saves, opens and reading continuation
- Resource submission completion, scan failure, moderation turnaround and broken-link reports
- Profile edit success, visibility-preview comprehension and privacy-setting errors
- Account-settings task success, security recovery failures and notification opt-out behaviour
- Qualitative feedback on visual vibe, clarity, whitespace, trust and perceived complexity
- Accessibility, keyboard and mobile testing findings

At the next build boundary, each experimental item receives one disposition: **Retain, Refine, Restrict or Remove**. Record the reason and evidence in CHANGELOG.md and Documents 1–5. Keep the first review build reversible through feature flags/configuration where appropriate.

## 5. Reference assets

The bundle's `references/design-inspiration/` contains the supplied and generated reference images:

- REF-00: Matte Black Analytical Dashboard
- REF-01 to REF-06: original dashboard, upload and card-pattern references
- REF-07: Community Technical Questions concept
- REF-08: Community Resources concept
- REF-09: Signup/Profile/Account concept
- REF-10: contact sheet of the six user-supplied visual inspirations



# PacketPulse 2.0 — Discussion Record: Media, Nested UX and Brand Pattern Exploration

**Date:** 26 November 2026  
**Status:** Owner-directed; included as Approved Prototype scope for the next review build  
**Related canonical documents:** Documents 1–5  
**Purpose:** Capture the latest discussion and the owner's corrections so the design system and Claude handoff remain aligned.

## 1. Owner direction: design is open, creative and experimental

The owner explicitly rejected a rigid or overly prescriptive design vocabulary. Signal Grove remains the shared identity, but it must not become a fixed aesthetic cage. The design team may explore new colours, Pantone references, patterns, compositions, typography and motion when they improve usability, clarity, brand recognition or emotional quality.

The owner also clarified that the generated background exploration should not be used to change existing page/card backgrounds. The requested work is a **pattern library**: transparent reusable motifs that can be layered onto existing surfaces.

## 1.1 Creative flexibility clarification

The owner reiterated that design guidance must not become hard-edged aesthetic restrictions. Use existing brand, module and semantic colours, Pantone-inspired exploration, new shades, gradients and combinations where they improve the product. The pattern list is a starting set, not a closed specification. Waves and pulses are welcomed, as are new motifs. Keep existing backgrounds untouched unless their separate redesign is requested; treat patterns as optional overlays.

## 2. Brand pattern families

Initial exploration families: Packet Routes; Node Constellation; Signal Waves; Pulse Trails; Radar Echo; Secure Layers; Data Flow; Packet Matrix. These are starting points, not an exhaustive list. New motifs and combinations are welcome.

Patterns may use the broader Signal Grove tokens, module accents, semantic colours and experimental palettes. Explore forest/eucalyptus/lime, indigo/blue/plum/violet, cyan/azure, amber/coral and multi-hue gradients where they fit. Do not force all motifs to be green. Pantone may be used as a reference for print/brand exploration, but do not invent a Pantone code or claim a direct match from HEX alone.

The motifs are to be built as transparent SVG/inline React or CSS overlays with scale, opacity, crop, line weight and colour variations. They do not replace or repaint the existing surface. The current generated wallpaper concepts are not treated as approved backgrounds.

## 3. Media and recording playback

The Resources experience must handle embedded recordings and multiple media/file types with the appropriate viewer. A single generic iframe is not sufficient.

### Preferred review-build stack

- **Video.js 10 (`@videojs/react`)** is the preferred default React player candidate. Official changelog records v10.7.0 on 24 November 2026; v10.0.0 became stable on 1 October 2026. The v10 architecture is modular and includes React/TypeScript/Tailwind patterns, adaptable skins and supported media sources including direct files, HLS, DASH and selected providers.
- **Shaka Player** remains a specialist alternative for requirements that specifically need advanced adaptive/offline/EME capabilities; not a second default player.
- **Uppy React headless/hooks** is the preferred upload UI candidate. **Tus** provides resumable upload where the existing storage/backend can support it. Uppy Dashboard is suitable for a quick prototype, but PacketPulse should own the final UI.
- **WaveSurfer.js 8.1.0 (BSD-3-Clause)** may be used as an optional audio waveform and region/timeline layer for audio-only recordings; it complements rather than replaces Video.js and needs a normal audio-control fallback. Pre-decoded peaks may be needed for streaming/large recordings.
- **React-PDF/PDF.js** is preferred for PDF preview. Office formats should use isolated conversion or a separately licensed provider after legal and security review.
- **FFmpeg** may be evaluated for thumbnails, metadata and transcode jobs; its license/build flags/codecs and patent implications must be reviewed.

### User experience expected

Playback controls should include what the source actually supports: play/pause, seek, volume, speed, quality, captions/subtitles, transcript, chapters, fullscreen, PiP where available, source label, resume progress, loading/error/offline/restricted states. No autoplay with sound. Captions and transcripts should be first-class, with provenance visible (human-reviewed/generated/unavailable).

### File handling

Use type-aware viewers: video/audio, PDF, image, Markdown/text/code and safe CSV preview. Office files may use a secured conversion pipeline or approved commercial/open-source provider. Archives, executables, unknown and unsafe formats should not be executed or embedded; show an honest fallback.

### Upload lifecycle

Selection → validation → queue → upload → pause/resume/retry/cancel → scan/quarantine → processing/transcoding/thumbnail → preview ready → moderation/publish. Status and progress must be real or visibly marked as mocked in a prototype. Store binaries in object storage and metadata in PostgreSQL; use short-lived signed access.

### Embed safety

Only approved providers should be embeddable. Canonicalise URLs server-side, allow-list providers, apply CSP/frame-src and sandbox/permission policies, check postMessage origins, prevent SSRF and unsafe redirects, and never render arbitrary member-supplied iframe or raw HTML.

## 4. Parent-child and nested-screen workflows

The owner wants the entire system to improve, including parent-child, nested screens and UI components. A parent remains the user's anchor while child experiences open.

- Use route-based child pages for substantial workflows and deep-linkable detail.
- Use route-backed drawers/sheets for contextual inspection where retaining the parent list is useful.
- Use inline expansion for small secondary information.
- Avoid modal-on-modal and deep, contextless flows.
- Preserve breadcrumbs/back path, browser history, filters, search, selected record, scroll and focus where feasible.
- On mobile, substantial children become full-screen routes or clearly titled sheets.
- Re-check permissions server-side on every child route and file/media request.

## 5. Approved Prototype scope

The following are included in the next review build: Video.js 10 player composition; upload manager with resumable path; PDF and supported file preview; secure provider embeds; recording detail with transcript/chapters/progress; parent-child navigation patterns; transparent motif library and multi-colour variants.

This is approval to prototype and review, not a claim that libraries are installed or production-ready. Repository audit, licensing, provider configuration, security, accessibility, mobile/browser playback and real media-processing checks remain required. After the review window the team records Retain, Refine, Restrict or Remove.

## 6. Technical research references (accessed 26 Nov 2026)

- Video.js 10 GA: https://videojs.org/blog/videojs-10
- Video.js changelog: https://videojs.org/changelog
- Video.js React installation: https://videojs.org/docs/guides/installation/react
- Video.js HLS/DASH streaming: https://github.com/videojs/http-streaming
- Shaka Player: https://github.com/shaka-project/shaka-player
- Uppy React: https://uppy.io/docs/react/
- Uppy Tus: https://uppy.io/docs/tus/
- Tus server: https://tus.github.io/tusd/
- React-PDF: https://github.com/wojtekmaj/react-pdf
- WaveSurfer.js: https://wavesurfer.pages.dev/docs/ · https://github.com/katspaugh/wavesurfer.js
- ONLYOFFICE Community licensing FAQ: https://helpcenter.onlyoffice.com/docs/installation/community/faq
- FFmpeg licensing: https://ffmpeg.org/legal.html

## 7. Recent cross-chat coverage note

The requested recent window was 24–26 November 2026. This record incorporates the current PacketPulse project discussion and the 24–25 November review-build documents present in the active workspace. Separate transcript exports for other independent chats in this date window were not available here; no unseen decisions have been inferred. Add those discussions later if their transcripts are supplied.


## 8. Final owner clarification: no hard visual rulebook

The owner reiterated: be creative, experimental and improve the whole design system. Do not write aesthetic guidance as rigid/hard-coded design laws. Signal Grove is a shared design language and an evolving token system, not a colour cage. The team may draw from all brand/module/semantic tokens and explore new hues, tonal shades, multi-colour gradients, Pantone-referenced studies and fresh palettes. Keep semantic status meaning legible; don't turn this into a restriction on decorative colour or compositions.

The current brand-pattern request is only to plan and build reusable transparent overlays. Do not change the page/card background when applying patterns. Make assets adaptable in colour, scale, crop, density, line weight, intensity and optional motion. Waves and pulses are welcome, alongside packet routes, nodes, routing traces, radar, security forms, topographic/flow fields, spectrums and motifs not yet named. These families are examples, not an exhaustive list.

Design guidance should enable exploration and review, not prevent it. Include promising variants in the Approved Prototype build. Team feedback after the review window determines Retain, Refine, Restrict or Remove for the next build. Accessibility, privacy, security, licensing and product integrity remain real safeguards.


## 8. Owner clarification — open creative direction and pattern-only scope

The owner clarified that no design aesthetic should become a rigid rulebook. Be creative, experimental and willing to improve the whole system. Existing examples and pattern families are inspiration, not limits. Use the full Signal Grove brand/module/semantic palette and explore further colour combinations, shades, gradients, Pantone-referenced studies and new hues when they work. Green is not compulsory.

The user also clarified that the current brand-pattern request must not change the existing background. The task is to design reusable, optional pattern overlays that can be applied in multiple places—cards, headers, profile covers, resource features, empty states, hero accents, section dividers and similar surfaces—while leaving the existing background intact. Waves and pulses are explicitly welcome alongside packets, nodes, routes, radar and security motifs.

Patterns should be reusable design assets, preferably transparent SVG/CSS/React variants, and can be subtle, expressive, static or animated. They are not a requirement for every component. Colour, crop, scale, density and intensity can adapt to context. Preserve usability, readability, accessibility, performance and reduced-motion support.

**Decision:** Open creative exploration is owner-confirmed. Transparent pattern-only overlays are owner-confirmed for the current pattern work. The current family list and colourways remain expandable.


# Consolidation provenance, source precedence and integrity

## Primary source packages and version lineage (24 Nov baseline; later updates reconciled)

- `PacketPulse_2.0_Update_2026-11-24.zip` (preserved in Git history; user-identified attached baseline) — four core guides, change/update summaries, Claude handoff, colour-system PDF and references.
- `PacketPulse_2.0_Approved_Prototype_Review_Build_2026-11-26.zip` — current 26 Nov canonical five-doc suite, changelog, update summary, review register, technical source register, Claude handoffs, discussion records and reference assets.
- `PacketPulse_2.0_Discussion_2026-11-25.zip` — prior discussion update set and design/component source context.
- `PacketPulse_2.0_Recovery_Pages_Design_System_Package.zip` — recovery pages and earlier design-system history.
- `PacketPulse_2.0_Team_Documentation_v1.3_2026-10-24.zip` — immutable earlier team documentation and design assets.
- `PacketPulse_Visual_Identity_Foundation_v1.0.zip` and `PacketPulse_Visual_Identity_Exploration_v0.1.zip` — identity explorations and owner-approved foundation artifact.
- `SCR-003_Frontend_Implementation_Starter.zip` — separate screen implementation starter; not integrated into the application repository by this documentation rebuild.

## User-identified source baseline — 24 November 2026

The owner noted that the attached source files represent the 24 Nov update set. Git history preserves this as `history/releases/2026-11-24-update-set/PacketPulse_2.0_Update_2026-11-24/`, including the four core guides, `CHANGELOG.md`, `UPDATE_SUMMARY.md`, `CLAUDE_UPDATE_HANDOFF.md`, the design colour-system PDF and its reference asset. The 24 Nov baseline is retained as historical source—not treated as the latest state.

## Later source sets reconciled

- 25 Nov discussion and review-build packages (discussion records, expanded core guides and component ecosystem).
- 26 Nov Approved Prototype Review Build (canonical five-document set, changelog, review register, technical source register, component additions, handoffs and visual/reference assets).
- 27 Nov owner decisions and Notion notes (user-psychology-first design; finalized Violet-led foundation; Claude token/logo delegation; SCR-004 and SCR-005 screen specifications; capability inventory and updated change lineage).

## Git repository snapshot inspected

- Repository: `kartik-binzade/packetpulse-community-2.0` (public documentation/history companion repository; not established as the live application source repository).
- Branch: `main`.
- Observed HEAD commit: `cca0a25576d65a9da2892c2f676a3efe9df481ec`.
- Commit message: `PacketPulse-Notion-Docs-latest(27Nov.7Pm)`; commit timestamp in Git metadata: `2026-11-27T14:21:04Z`.
- Tree includes `PacketPulse_Documentation_History/`, immutable `history/releases/` and `history/source-packages/`, `Notion's Doc/PacketPulse-Notion-Docs-latest(27Nov.7Pm)/`, governance, current documents, approved identity assets, token CSS, brand patterns, SCR-003 screen spec and a separate SCR-003 implementation starter.
- Git tree includes the 24 Nov update archive and later 25/26 Nov source packages. Latest Notion companion export includes Product Guide v5.5, Design System & UX Guide updated 27 Nov 7:41 PM (Notion metadata), Master Change Log/Decision Register, capability inventory, SCR-004 and SCR-005.
- The Git repository is a documentation/archive workspace and contains prototype/spec assets; this does not prove the production app repo has been inspected, the app integrated, or deployment/test status.
- The README within the history workspace described a standalone docs workspace and an earlier intended push destination; current repository metadata and HEAD above are the observed later state. Do not repeat the old setup instruction as current without owner confirmation.

## Notion pages consulted / cross-checked

Documentation & Project Memory; Product Guide v5.5; Design System & UX Guide (27 Nov); Users, Screens & Page Flows; Delivery Plan & Developer Handoff; Component Ecosystem & Library Registry; Decision Register & Governance; Master Change Log & Discussion Lineage; Source Index & Archive Manifest; Design Token & Theme History; Brand & Visual Design System; Required Product Components & Capability Inventory; SCR-003, SCR-004 and SCR-005 screen specifications; SCR-003 engineering handoff; 26 Nov Discussion Handoff. Notion companion pages explicitly identify themselves as structured summaries/navigation rather than verbatim imports.

## Source limitations

- Notion canonical companion pages are not full verbatim copies of all source documents. This rebuild uses the complete local Markdown source set for the 26 Nov review build and the available Notion page content/notes for later updates.
- Some Notion pages or discussion summaries may have been updated after the 26 Nov source ZIP; only specific retrieved current notes are merged. Unknown content is not inferred.
- The 205-file documentation-history archive referenced by Notion is a prior archive manifest; this four-file output is a new consolidated release, not a replacement or reconstruction of every archived binary.
- The application repository was not inspected as part of this document-generation task. No implementation, test, deployment or Git publish status is upgraded by these documents.

## Status vocabulary and versioning

Confirmed / Planned / Proposed / Approved Prototype / Production Approved / Open / Discovery / Historical / Delegated / Repository validation pending retain their source meanings. Never treat a prototype as production approval. New owner decisions supersede current guidance; historical source files stay immutable and are linked, not silently rewritten.
