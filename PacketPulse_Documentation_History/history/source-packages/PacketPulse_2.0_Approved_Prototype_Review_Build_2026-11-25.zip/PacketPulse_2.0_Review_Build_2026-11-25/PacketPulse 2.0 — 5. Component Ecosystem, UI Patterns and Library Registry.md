# PacketPulse 2.0 — 5. Component Ecosystem, UI Patterns and Library Registry

**Version:** 1.2  
**Issued:** 25 November 2026  
**Revision:** Added Resources, Signup, Profile and Account component systems; promoted open concepts to Approved Prototype for review build  
**Owner:** Product / Design Lead (to be named)  
**Status:** Owner-directed design specification; implementation candidates require repository audit and component review  
**Companion documents:** Product Guide v5.0; Design System and UX Guide v4.0; Users, Screens and Page Flows v3.0; Delivery Plan and Developer Handoff v4.0  
**Purpose:** Turn the visual references and UI resources supplied by the product owner into an actionable design and implementation specification for PacketPulse's shared component system.

> **Core instruction:** Do not copy reference screens literally. Extract the useful visual and interaction patterns, adapt them to Signal Grove, validate them against real PacketPulse workflows, and implement them once as reusable, documented components.

---

## 0. How to use this document

This is the fifth canonical PacketPulse 2.0 reference document. It extends, rather than replaces, the existing Design System and UX Guide.

- Document 1 defines product vision, requirements and decisions.
- Document 2 defines the brand, design tokens, accessibility, layout and UX rules.
- Document 3 defines users, screens and page flows.
- Document 4 defines delivery tasks, developer handoff and acceptance tests.
- **Document 5 defines the component ecosystem, reusable UI patterns, source-library registry and the detailed implementation requirements for the six new visual references.**

When two documents appear to conflict, use the newer owner-approved decision recorded in `CHANGELOG.md`. An owner-approved prototype may be built and reviewed in the next review build. A package may be evaluated/adapted in prototype; production dependency adoption still requires DEV-11, version/licence audit and technical approval. Prototype approval is not production approval.

### Status vocabulary

| Status | Meaning |
|---|---|
| Owner-directed | The product owner explicitly asked for this direction or supplied the reference. |
| Approved Prototype | Owner approved the pattern/component concept for the next review build; feedback can remove or refine it in a later build. |
| Production Approved | Approved for production adoption after repository, accessibility, security, licence and operational gates. |
| Recommended | A technical/design recommendation not yet owner-approved. |
| Candidate | A source/package may be explored in prototype; not yet selected as a production dependency. |
| Approved pattern | The pattern is approved for PacketPulse adaptation; exact code may still need implementation. |
| Implemented | Present in the repository and verified against its acceptance criteria. |
| Deprecated | Do not use in new work; replace through a documented migration. |

**Documentation is not evidence of implementation.** Developers must inspect the repository and record current state before changing packages or routes.

## 0.1 Owner direction: Be open, creative and experimental

The product owner explicitly directs the team to **be open, creative and experimental**. Treat this as a design and product-development principle, not as a request to abandon consistency or quality.

- Do not reject a visual idea, interaction, component, library, or capability solely because it is unfamiliar, unconventional, or outside the current component set.
- Explore the idea in the context of a real PacketPulse user need. Ask what it improves: clarity, confidence, belonging, delight, task completion, discovery, credibility, or development speed.
- When the right approach is uncertain, create a lightweight prototype or side-by-side variants instead of debating in the abstract. A useful default is to explore two or three materially different treatments for high-impact or uncertain experiences.
- Allow controlled visual experiments beyond the current palette or layout conventions in the exploration stage. Before promotion into a shared production component, map the winning treatment to Signal Grove semantic tokens and document any deliberate exception.
- Use feature flags, limited cohorts, reversible configuration, or isolated routes for behavioural experiments where appropriate. Keep experiments observable and reversible.
- Define a team review window for significant experiments. Collect member feedback, usability findings, accessibility results, performance, error rates and relevant product outcomes. At review, retain, refine, restrict, pause or remove the experiment based on evidence.
- Do not mistake novelty for value. Experimental work must still respect privacy, security, accessibility, performance, licensing and operational constraints.
- Avoid prematurely freezing the design system. It should provide a coherent foundation while leaving room for new patterns and better ideas.

### Experiment maturity states

| State | Meaning | Expected evidence before promotion |
|---|---|---|
| Spark | An idea worth exploring; no implementation commitment | User/problem hypothesis and inspiration/source note |
| Prototype | A quick, reversible demonstration | Visual/interaction comparison and feasibility notes |
| Pilot | Limited real use, cohort or feature-flag rollout | Defined review window, owner, success measures and safeguards |
| Approved | Team/product review supports continued use | Feedback summary, accessibility and technical review |
| Standard | Adopted into the shared PacketPulse system | Documentation, component API, tests, maintenance owner |
| Retired | Removed or replaced after review | Reason, migration or replacement note where applicable |

An experiment can be valuable even when it is not promoted. Record what was learned so the team does not repeat the same exploration without new evidence.

## 0.2 Experience principle: Make the product feel good to use

Whitespace, visual rhythm and emotional tone are product requirements. The interface should feel calm, capable, welcoming, credible and quietly rewarding. Do not fill available space with widgets merely because the viewport can hold them. Prefer a clear visual path, a meaningful focal point, and enough breathing room for users to understand what matters.

Use microanimations where they acknowledge an action, explain a state change, establish spatial relationships or make progress understandable. Do not add motion only for decoration. Preserve reduced-motion behaviour and keep all information understandable without animation.

---

# 1. Design direction from the supplied references

The six supplied images are grouped into four reusable design patterns. They show distinct jobs and should not be flattened into one visual style.

| Reference | File | Observed pattern | PacketPulse interpretation |
|---|---|---|---|
| REF-01 | `references/ui-inspiration/REF-01-spacious-people-analytics-dashboard.jpg` | Light dashboard; top utility bar; four KPI panels; large analytic panel; calendar; explanatory tiles; participant/people cards; forest green and vivid lime | Soft Signal dashboard variant for people, community participation, scheduling and member-facing overview screens. |
| REF-02 | `references/ui-inspiration/REF-02-file-upload-in-progress.jpg` | Horizontal file card; file-type icon; filename; upload percentage and transferred/total size; pause and cancel controls; prominent progress rail | Uploading state of the shared File Transfer component. |
| REF-03 | `references/ui-inspiration/REF-03-file-upload-complete-compact.jpg` | Compact completed file row; file icon; success glyph; completed status; file size; removal action | Compact successful state of the shared File Transfer component. |
| REF-04 | `references/ui-inspiration/REF-04-file-upload-complete-actions.jpg` | Completed file card; status and file size; secondary Change action; strong Download action | Expanded completed state with next-step actions. |
| REF-05 | `references/ui-inspiration/REF-05-perspective-card-carousel.jpg` | Horizontal card gallery; active centre card; side cards partially visible; perspective depth; image-led content; metadata row | Featured content, mentor, expert, event or project-showcase carousel. |
| REF-06 | `references/ui-inspiration/REF-06-numbered-feature-cards.jpg` | Three tall numbered cards; large numerals; varied visual panels; strong title and short copy; directional arrow; layered surfaces | Editorial feature tiles, onboarding steps, learning pathways and product storytelling cards. |

## 1.1 What these references have in common

- Whitespace separates the interface into understandable groups.
- Large, clear primary content is supported by quieter secondary information.
- Cards have a recognisable silhouette without relying on heavy shadows.
- Status and progress are visible without opening a separate detail page.
- Colour is used with intent: a small number of strong accents against calm neutral surfaces.
- Repeated patterns can become reusable components instead of one-off page compositions.

### Supplied visual references

The seven reference images are included in `references/ui-inspiration/` in the discussion bundle. `REF-00` is the matte-black analytical dashboard reference discussed earlier; `REF-01` to `REF-06` are the six new images reviewed on 25 November 2026.

| Reference | Preview |
|---|---|
| REF-00 Matte Black Analytical Dashboard | ![Matte Black dashboard](references/ui-inspiration/REF-00-matte-black-analytical-dashboard.jpg) |
| REF-01 Spacious People Analytics Dashboard | ![Spacious people analytics dashboard](references/ui-inspiration/REF-01-spacious-people-analytics-dashboard.jpg) |
| REF-02 File Upload In Progress | ![File upload in progress](references/ui-inspiration/REF-02-file-upload-in-progress.jpg) |
| REF-03 File Upload Complete — Compact | ![File upload compact completed](references/ui-inspiration/REF-03-file-upload-complete-compact.jpg) |
| REF-04 File Upload Complete — Actions | ![File upload completed actions](references/ui-inspiration/REF-04-file-upload-complete-actions.jpg) |
| REF-05 Perspective Card Carousel | ![Perspective card carousel](references/ui-inspiration/REF-05-perspective-card-carousel.jpg) |
| REF-06 Numbered Feature Cards | ![Numbered feature cards](references/ui-inspiration/REF-06-numbered-feature-cards.jpg) |

## 1.2 What must not be copied literally

- Do not reuse the reference's sample names, people, dates, company data, percentages or metrics as PacketPulse data.
- Do not introduce an unrelated purple brand palette because one reference uses it for a progress rail. Use Signal Grove semantic/module tokens.
- Do not introduce a 3D carousel into ordinary lists, tables or the primary community feed.
- Do not use the numbered feature cards as the default treatment for all dashboard cards.
- Do not compress the layout just to fit more widgets into the first viewport.
- Do not treat visual similarity as proof of accessibility, responsive behaviour, code quality or licence permission.

---

# 2. Signal Grove visual language for these patterns

## 2.1 One design system, multiple workspace moods

PacketPulse uses one Signal Grove token system with two layout families and deliberate theme variants:

1. **Editorial Workspace:** Community discussions, technical articles, learning content, profiles, mentoring and discovery. It prioritises reading comfort, content hierarchy, human identity and whitespace.
2. **Analytical Workspace:** Operations, recruitment analytics, community analytics, administrative queues and performance workspaces. It prioritises scanning, comparison, data clarity and drill-down.

The Analytical Workspace has two intentional appearances:

- **Matte Black Edition:** Preferred reference for data-heavy administrative and analytical workspaces, based on the owner's positive response to the matte-black dashboard reference.
- **Soft Signal Light:** Light counterpart inspired by REF-01. Particularly suitable for people/participation summaries, scheduling, community overviews and users who prefer light mode.

Both themes use the same component API, semantic tokens, information hierarchy and interaction rules. Theme choice must not change the meaning of data or the available actions. Respect the member's saved preference when a screen supports personal theme selection; organisation policy may set a default but should not silently remove the user's choice unless a separate product requirement approves that behaviour.

## 2.2 Theme tokens

Existing Document 2 tokens remain the source of truth. This table repeats the values needed by the new patterns; it does not create a second palette.

### Signal Grove light / Soft Signal Light

| Token | Value | Usage |
|---|---|---|
| Canvas | `#F5F8F6` | Main application background |
| Surface | `#FFFFFF` | Main cards, panels and forms |
| Surface subtle | `#E8F4EF` | Selected rows, soft panels and contextual highlights |
| Text primary | `#152025` | Headings, labels and body text |
| Text secondary | `#52615B` | Supporting text; validate at actual font size |
| Border | `#DCE5DF` | Low-emphasis structural boundaries |
| Control border | `#738279` | Input boundaries and controls |
| Brand forest | `#156152` | Brand actions and navigation |
| Forest hover | `#0F4D41` | Hover state |
| Signal lime | `#C7FE53` | Rare milestone/reward emphasis; use dark text on it |

### Matte Black Edition

| Token | Value | Usage |
|---|---|---|
| Analytics canvas | `#0B0D0C` | Main dashboard background |
| Analytics surface | `#171A18` | KPI panels, tables and workspace sections |
| Analytics raised | `#222724` | Raised panels, menus and selected surfaces |
| Analytics border | `#303631` | Subtle separators |
| Analytics text | `#F2F5F2` | Primary text |
| Analytics muted | `#A8B2AC` | Secondary text; contrast must be checked at actual size |
| Brand action | `#156152` | Primary actions; maintain visible label and focus state |
| Signal emphasis | `#C7FE53` | Rare emphasis and meaningful milestones |
| Secondary chart series | `#A78BFA` | Optional data series only; not a brand or status colour |

**Validation required:** Matte Black draft values must be contrast-tested for every foreground/background pair, border/control state, disabled state, chart series and focus ring before production. A visually attractive muted grey is not automatically readable at 12–14px.

## 2.3 Module accents

Use the existing module identities from Document 2:

- Community / Brand: Forest.
- Learning: Indigo.
- Recruitment: Blue.
- Payments: Plum.
- Operations: neutral/brand shell, with semantic state colours.

A component may accept a `tone` or `module` variant, but it must use semantic tokens rather than raw page-level hex values. Success, warning, danger and information always retain their semantic meaning. A module accent must never impersonate a success or verification state.

## 2.4 Whitespace and density

Whitespace is a deliberate UX tool. It establishes grouping, lowers perceived effort, improves scan paths and creates a calm product atmosphere. It is not unused space to be filled with widgets.

| Context | Default spacing guidance |
|---|---|
| Page edge | 24–40px desktop; 16–20px mobile |
| H1 to description | 8–12px |
| Description to first section | 24–32px |
| Major section separation | 40–64px desktop; 28–40px mobile |
| Standard card padding | 20–24px desktop; 16px mobile |
| Small status card padding | 12–16px |
| Form field groups | 20–24px |
| Reading line length | Aim for 60–75 characters |
| Dashboard grid gap | 16–24px, selected by density and viewport |

Density modes:

- **Comfortable:** Default for member dashboard, feed, cards, people panels and forms.
- **Compact:** Use for high-volume tables, review queues, candidate comparison and admin lists. Keep text readable and touch targets accessible.
- **Reading:** Use for article, question/answer, documentation and technical content.

Do not create empty space by hiding useful information; create it by grouping, prioritising and progressively disclosing secondary detail.

## 2.5 Shape, border and elevation

- Standard cards: 14–18px radius; larger feature panels may use 20–24px.
- File upload cards: 16–20px radius; compact rows may use 12–14px.
- Feature tiles: 20–24px radius, with clear internal padding.
- Inputs and buttons: follow the existing 10px radius token; pill shapes are reserved for chips and selected compact controls.
- Prefer a subtle 1px border and tonal surface separation over heavy shadows.
- Shadows are reserved for actual floating layers (menus, popovers, dialogs), not every card.
- Hover must not cause surrounding layout shift.

---

# 3. Reference pattern specifications

## 3.1 PP-DASH-001 — Spacious People & Community Analytics Dashboard

**Source inspiration:** REF-01.  
**Workspace:** Analytical Workspace, Soft Signal Light variant; compatible with Matte Black tokens.  
**Primary use:** Community overview, member participation, people/mentor operations, learning engagement and other dashboards that mix metrics with schedules or people.

### Layout anatomy

1. **Top utility bar**
   - Global search on the left with a visible keyboard hint (e.g. `⌘ K` / `Ctrl K`).
   - Optional AI/help assistant entry point, if the feature is enabled for that role.
   - Notifications with unread count.
   - Member avatar and account menu on the right.
   - Utility controls must remain compact and must not compete with the page title.

2. **Page header**
   - Breadcrumb where depth requires it.
   - One clear H1 and concise description.
   - Date range, workspace selector or primary action aligned to the right.
   - On mobile, selectors may move into a filter sheet.

3. **KPI strip**
   - Usually 3–5 cards. Four is a good starting arrangement for REF-01-style dashboards.
   - One featured metric may use a deeper forest surface with a high-contrast number and a small sparkline.
   - Remaining KPI cards use neutral surfaces, clear label/value/period comparison and a restrained mini-visual where useful.
   - Each metric must define its period, unit and comparison baseline. A number without a definition is not an approved KPI.
   - Avoid decorative mini charts if the data cannot be interpreted or if they duplicate the main chart.

4. **Primary analysis area**
   - Use a clear 8/4 or 7/5 grid depending on the right rail content.
   - Main panel may include chart, distribution, percentage breakdown or activity analysis.
   - Show a title, metric unit, period selector, legend and direct labels or tooltip details.
   - A tooltip can reveal detail but must not contain the only explanation of a metric.
   - Pattern fills/hatching may support series differentiation, but colour alone must never be the only distinction.

5. **Contextual calendar / schedule panel**
   - Month and date navigation.
   - Selected day, today, event day and disabled date must be visually distinct and keyboard operable.
   - Below the calendar, show a concise agenda list for the selected day.
   - Mobile: calendar collapses to a compact date strip or opens in a sheet; agenda remains a readable list.

6. **Supporting insight panels**
   - Use a two-column arrangement for short explanation, happiness/health signal, next action, or overview text.
   - One panel may have a slightly stronger background or accent; do not give every panel a different colour.
   - Each panel has a clear title, short explanatory copy and at most one obvious action.

7. **People / contributor panels**
   - Member avatar, display name, area/skill, relevant tags, participation context and one appropriate action.
   - Avatar groups can show a small set of additional participants, with a `+N` overflow label.
   - Do not show follower counts or vanity scores as the primary credibility signal.
   - Keep privacy and profile visibility settings intact.

### Visual hierarchy

- KPI value is the strongest element inside a metric card; metric label and comparison follow.
- Use tabular numerals for counts, dates and percentages.
- One featured KPI is enough; all cards should not compete for hero treatment.
- Chart occupies the largest visual area because it answers the dashboard's primary question.
- Calendar and people panels are secondary context, not equal-weight competitors.
- Use a restrained green/lime accent; lime is for selected days, key milestone or one meaningful emphasis, not all chart bars.

### Responsive behaviour

| Viewport | Behaviour |
|---|---|
| ≥1280px | Full KPI strip; main analysis and contextual rail side-by-side; supporting panels below |
| 1024–1279px | KPI grid may wrap; right rail may narrow or collapse |
| 768–1023px | Two-column KPI cards; calendar and people context move below chart or into collapsible panel |
| <768px | Single-column flow; no horizontal page overflow; compact utility bar; calendar uses sheet/date strip |
| <640px | KPI cards may use 2 columns only if labels and values remain clear; otherwise stacked list |

### States and interactions

- Loading: skeletons preserve the final layout dimensions; avoid flashing empty cards.
- Empty: explain why there is no data and provide a next action (e.g. invite members, select period, create event).
- Error: show what failed, keep selected filters, provide retry.
- Metric drill-down: clicking a KPI should navigate or open a meaningful detail view; do not make numbers look clickable if they are not.
- Chart hover/focus: keyboard-accessible inspection and text-equivalent summaries.
- Calendar date selection: visibly update agenda panel and announce selection accessibly.

### Build notes

Use the shared `AnalyticalWorkspaceShell`, `MetricCard`, `ChartPanel`, `CalendarPanel`, `PeopleListCard` and `InsightPanel`. The page must not be implemented as one monolithic dashboard component.

---

## 3.2 PP-UPLOAD-001 — File Transfer / Upload Card

**Source inspiration:** REF-02, REF-03 and REF-04.  
**Use:** Community technical questions, learning submissions, resumes, certifications, verification evidence, profile media and administrative attachments.

The three images represent related states of one component, not three unrelated designs.

### Component anatomy

- File-type icon or thumbnail.
- Filename (truncate only after a useful visible portion; full name available to screen readers and detail tooltip).
- File size and optional file type.
- Status label and, when uploading, progress percentage and transferred/total bytes.
- Progress rail with accessible text value.
- State-dependent controls: pause, resume, cancel, retry, remove, change file and download.
- Optional security/validation status (e.g. scanning, file type rejected, sensitive-data warning).

### Required state model

| State | Visual treatment | Available action |
|---|---|---|
| Idle / empty | Drop zone or browse button; accepted formats and max size stated | Choose file / drag and drop |
| Selected / queued | File icon, name, size and queued label | Start, remove |
| Uploading | Progress rail, percentage, transferred/total size | Pause, cancel |
| Paused | Frozen progress, explicit Paused label | Resume, cancel |
| Processing / scanning | Indeterminate progress or staged status; do not fake percentage | View status, cancel only if supported |
| Completed | Success glyph, Completed text, file size | Change, download, remove if permitted |
| Failed | Error glyph, concise reason, retained filename | Retry, change, remove |
| Canceled | Canceled label, no success semantics | Retry or remove |
| Rejected | Policy reason (format, size, malware or policy) | Change file, view guidance |

### Reference states

- **REF-02 Uploading:** Place filename and file identity on the first line. Show percentage and bytes transferred on the second line. Progress rail spans most of the card width. Pause and cancel remain clearly separate controls.
- **REF-03 Completed compact:** Use a single-row version for completed lists. Show file icon, success glyph, status and file size; removal action is visually separated and labelled accessibly.
- **REF-04 Completed actions:** Use an expanded footer with secondary `Change` and primary `Download` buttons when the next task requires the file. If download is not relevant (e.g. uploaded evidence), replace it with the appropriate approved next action.

### Progress behaviour

- Progress value must come from actual transfer events, not a decorative timer.
- Show a numerical percentage when reliable. If the upload is indeterminate, use an indeterminate progress state and explanatory label.
- Pause/resume is shown only if supported by the upload transport/provider. Do not show a fake pause button.
- Cancel is not the same as delete. Cancel stops an active transfer; remove deletes a queued/completed item from the current form according to the product's storage rules.
- Completion state must be stable; do not auto-dismiss a file needed for the next step.
- If a file is replaced, clarify whether the old file is removed immediately or after the replacement succeeds.

### Validation and safety

- Display accepted formats and maximum size before upload.
- Validate size and extension client-side for fast feedback and server-side for enforcement.
- Verify file content/type server-side; extension alone is not trusted.
- Scan files and quarantine unsafe attachments before making them accessible.
- For technical uploads, add sensitive-data warning/redaction guidance where applicable.
- Never expose an attachment to other users until the server-side access policy permits it.
- For long/resumable uploads, select a transport that actually supports pause/resume and recovery. Evaluate the existing backend first; Uppy or a provider-native resumable approach is a candidate, not a default dependency.

### Accessibility

- Progress uses `role="progressbar"` or the appropriate native element with accessible name, `aria-valuenow`, `aria-valuemin`, `aria-valuemax` where determinate.
- Announce state changes (uploading, paused, completed, failed) without announcing every percent tick.
- Buttons have explicit names (`Pause upload`, `Cancel upload`, `Remove file`, `Download file`).
- Do not rely on green/red alone; show icon and text.
- Preserve keyboard navigation and visible focus.

### Responsive behaviour

On mobile, stack metadata and actions naturally. Keep primary status visible; place secondary actions in an overflow menu only when necessary. Do not make the progress rail too thin to perceive or tap its controls too small.

### Component API direction (illustrative, not final code)

```tsx
<FileTransfer
  file={file}
  status="uploading"
  progress={65}
  transferredBytes={1_400_000}
  totalBytes={2_300_000}
  onPause={pauseUpload}
  onCancel={cancelUpload}
  onRetry={retryUpload}
  onRemove={removeFile}
  onDownload={downloadFile}
  onReplace={replaceFile}
  density="comfortable"
/>
```

The API must not expose unsupported actions. Use controlled state from the upload service; do not have the visual component invent or simulate upload completion.

---

## 3.3 PP-CAROUSEL-001 — Perspective Featured Card Carousel

**Source inspiration:** REF-05.  
**Use:** Featured mentors, expert contributors, upcoming events, curated learning resources, community projects and selected case studies.

### Visual style

- Horizontal track with one clearly active centre card and adjacent cards partially visible.
- Active card may be slightly larger or sharper; adjacent cards may be scaled down or subtly angled.
- Use restrained perspective (`perspective` / `rotateY`) as a progressive enhancement, never as a requirement for understanding content.
- Active content includes image/portrait, title/name, category or role, and a small set of useful metadata.
- A separate metadata strip may show relevant facts (e.g. availability, skill area, reading time, event date), not arbitrary vanity values.
- Keep surrounding canvas calm; no glowing neon rails or continuous auto-motion.

### Interaction

- Support drag/swipe, previous/next controls and keyboard navigation.
- Make active index visible via dots, count or selected card semantics where appropriate.
- Do not auto-advance by default. If auto-advance is introduced, provide pause/stop controls and a respectful interval; avoid auto-advancing content that users are reading.
- Clicking a card opens its detail page or performs a clearly indicated action.
- Ensure partially visible cards do not trap focus or hide essential controls.

### Responsive behaviour

- Desktop: show active centre card plus partial neighbours.
- Tablet: reduce side peek and perspective; allow drag/swipe.
- Mobile: use a single-card swipe layout with visible next-card hint; keep navigation buttons accessible.
- Reduced motion: remove 3D rotation and animated scale; use a simple horizontal scroll/instant active state.

### Appropriate PacketPulse uses

- Featured mentors/expert contributors.
- Upcoming AMAs or technical events.
- Curated courses, labs or learning paths.
- Member project/case-study showcases.
- Featured community spaces.

### Do not use for

- Primary question feed.
- Long lists, tables or search results.
- Important alerts or transactional controls.
- Interfaces where users must compare many items precisely.

---

## 3.4 PP-FEATURE-TILE-001 — Numbered Editorial Feature Cards

**Source inspiration:** REF-06.  
**Use:** Product marketing, community onboarding, learning pathways, step-by-step setup, value proposition sections and curated feature explanation.

### Visual anatomy

1. A tall portrait-oriented card with a large number or sequence marker (`01`, `02`, `03`).
2. A visual zone in the upper/central area: illustration, abstract pattern, product screenshot crop or restrained gradient.
3. A clear heading and short description near the lower section.
4. A small directional affordance (arrow) showing that the card can be opened or explored.
5. A layered panel or inset surface that gives the card visual depth without excessive shadow.

### Style rules

- Use a coherent family of surfaces: one forest/teal card, one neutral/light card, one dark/raised card where the story benefits from variation.
- Numbering must be consistent in position, size and visual meaning.
- Keep the title concise; description should normally be 1–3 short lines.
- A card should have one clear destination/action.
- Use a single shared card layout, not three unrelated designs.
- The card's visual zone must not be a decorative placeholder without meaning. Prefer custom illustrations or real product imagery.
- In Matte Black mode, use tonal surface separation and a restrained accent; do not simply invert the reference's bright gradient.

### Interaction

- Whole card is clickable only if it leads to a single destination; otherwise keep a clear button/link.
- Hover may raise the card by 1–2px, move the arrow by 2–4px or reveal a subtle border/gradient change.
- Focus state must be as visible as hover.
- No auto-playing video or continuous gradient animation.
- Reduced-motion users receive a static card with the same hierarchy.

### Appropriate PacketPulse uses

- `Learn → Practice → Prove` pathway.
- Community onboarding: discover, ask, contribute.
- Product capability storytelling.
- How verification works.
- Getting-started guides for organisations.

### Do not use for

- Repeated dashboard KPI cards.
- Dense admin lists.
- Transaction status or verification decision details.
- Long explanatory text.

---

# 4. Shared component design catalogue

The following catalogue converts the references and previously researched component sources into PacketPulse-owned components. `PP-*` identifiers are stable registry IDs. The owner has approved this catalogue as the **review-build component scope**. Components are Approved Prototype until implementation and review; source packages remain subject to repository/licence audit before production adoption.

## 4.1 Foundations and shell

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-FND-001 | Design tokens & theme bridge | Light, Matte Black, module accents, semantic states, typography, spacing and motion | Existing Signal Grove tokens; Tailwind CSS v4 | P0 |
| PP-SHELL-001 | Application shell | Shared app frame, route content, theme and role context | shadcn patterns; custom PacketPulse wrapper | P0 |
| PP-SHELL-002 | Workspace sidebar | Grouped, role-aware, collapsible nav | Component Gallery, BoardUI, Bencho | P0 |
| PP-SHELL-003 | Utility header | Search, assistant entry point, notifications, theme and account | REF-01; custom wrapper | P0 |
| PP-SHELL-004 | Page header | Breadcrumb, H1, description, action and filters | Beautiful UI, BoardUI, shadcn | P0 |
| PP-SHELL-005 | Contextual rail | Collapsible task-specific side panel | REF-01; BoardUI; Base UI / Radix primitive | P1 |

## 4.2 Navigation, discovery and overlays

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-NAV-001 | Breadcrumbs | Deep-page orientation | Component Gallery, BoardUI, shadcn | P0 |
| PP-NAV-002 | Tabs / segmented control | Switch view or period | Component Gallery, BoardUI, Transitions | P0 |
| PP-NAV-003 | Global command/search palette | Search and action discovery | Bencho, Beautiful UI, shadcn | P1 |
| PP-NAV-004 | Filter bar | Visible filters, removable chips, clear all | BoardUI, TanStack patterns | P0 |
| PP-NAV-005 | Combobox / autocomplete | Select taxonomy, skills, members and entities | Bencho, BoardUI, Beautiful UI | P0 |
| PP-OVL-001 | Dialog | Confirm, edit or focused task | shadcn + existing primitive choice | P0 |
| PP-OVL-002 | Drawer / sheet | Detail preview and contextual editing | BoardUI, Beautiful UI | P0 |
| PP-OVL-003 | Popover / tooltip | Supplementary context and compact controls | Component Gallery, Bencho | P0 |
| PP-OVL-004 | Calendar / date picker | Event, assessment and schedule selection | BoardUI; existing primitive | P1 |

## 4.3 Analytics and data

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-DATA-001 | Metric / KPI card | Label, value, period, comparison, optional sparkline | REF-01, BoardUI, Ingot UI | P0 |
| PP-DATA-002 | Featured KPI card | One priority metric on a stronger brand surface | REF-01 adapted to Signal Grove | P0 |
| PP-DATA-003 | Chart panel | Chart title, description, period control, legend and text summary | BoardUI, Beautiful UI, Recharts candidate | P0 |
| PP-DATA-004 | Data table | Sorting, filters, visibility, selection, pagination and empty/error states | TanStack Table candidate; BoardUI patterns | P0 |
| PP-DATA-005 | Activity timeline | Audits, status changes and chronological activity | Component Gallery, Bencho | P1 |
| PP-DATA-006 | Calendar panel | Month grid with selected-day agenda | REF-01, BoardUI | P1 |
| PP-DATA-007 | Insight panel | Short insight, supporting context and one action | REF-01 | P1 |

## 4.4 File and technical content

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-FILE-001 | File transfer card | Queued/uploading/paused/processing/completed/failed/rejected states | REF-02 to REF-04; custom PacketPulse component | P0 |
| PP-FILE-002 | Dropzone | Browse and drag/drop entry | Bencho, BoardUI; evaluate react-dropzone/Uppy only if needed | P0 |
| PP-FILE-003 | File preview | Safe preview of images, PDFs and supported evidence | Custom wrapper; existing preview package audit | P1 |
| PP-CONT-001 | Rich content editor | Markdown/rich text with preview and sanitisation | Tiptap candidate; existing editor audit | P0 |
| PP-CONT-002 | Code block | Syntax highlight, copy, language label and overflow handling | Custom styling; existing highlighter audit | P0 |
| PP-CONT-003 | Technical redaction notice | Warn about secrets and sensitive values | Custom UI; detection service separate | P0 |
| PP-CONT-004 | Revision history | Display edits and compare revisions | Custom timeline/diff composition | P1 |

## 4.5 Community, identity and contribution

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-COM-001 | Question card | Question summary, tags, status, answer count and activity | Component Gallery, Bencho, custom wrapper | P0 |
| PP-COM-002 | Answer card | Answer body, author, useful vote, accepted/reviewed distinction | Component Gallery; custom wrapper | P0 |
| PP-COM-003 | Discussion / article card | Structured content feed | Component Gallery, REF-06 for featured treatment only | P0 |
| PP-COM-004 | Member identity card | Name, role/interests, skills and contribution context | Bencho, REF-05 | P0 |
| PP-COM-005 | Avatar group | Participants and reviewer groups | Bencho, Transitions | P1 |
| PP-COM-006 | Featured carousel | Selected mentors, events, knowledge and case studies | REF-05; Bencho/BoardUI patterns | P1 |
| PP-COM-007 | Numbered feature tile | Onboarding and editorial explanation | REF-06; custom wrapper | P1 |
| PP-COM-008 | Saved item / bookmark | Save and manage useful knowledge | Custom wrapper | P0 |
| PP-COM-009 | Reputation summary | Contribution quality, separate from formal verification | Custom wrapper | P1 |

## 4.6 Feedback, state and progression

| ID | Component | Purpose | Source inspiration / implementation candidate | Priority |
|---|---|---|---|---|
| PP-FB-001 | Toast | Brief action feedback | Sonner candidate; Transitions recipes | P0 |
| PP-FB-002 | Banner / inline alert | Persistent or contextual system status | BoardUI, Beautiful UI | P0 |
| PP-FB-003 | Empty state | Explain absence and provide next action | unDraw/custom illustration | P0 |
| PP-FB-004 | Skeleton | Layout-matched loading | Transitions, custom CSS | P0 |
| PP-FB-005 | Progress indicator | Multi-step flow and learning/verification progress | BoardUI, Bencho, Transitions | P0 |
| PP-FB-006 | Status badge | Semantic states with icon and label | Component Gallery, shadcn | P0 |
| PP-FB-007 | Confirmation action | Destructive or high-impact confirmation | Beautiful UI, shadcn | P0 |

---

# 5. Component ecosystem and library registry

## 5.1 Adoption architecture

PacketPulse must own the final component API and visual behaviour. External libraries are sources and foundations, not competing product design systems.

Recommended layers:

1. **Foundation:** Tailwind CSS v4, CSS variables, semantic tokens, typography, spacing and motion tokens.
2. **Accessible primitives:** Use the primitive family already present in the repository. New shadcn projects currently default to Base UI; Radix remains supported. Do not mix both arbitrarily or migrate a stable app without a clear technical reason.
3. **Source-owned components:** shadcn/ui is the preferred base where appropriate; components are copied into the repo and adapted.
4. **Curated registries:** Ingot UI, BoardUI, Beautiful UI and Bencho may supply specific components after a code, licence, accessibility and theme audit.
5. **PacketPulse wrappers:** `PPButton`, `PPDialog`, `PPDataTable`, `PPFileTransfer`, etc. expose stable product-specific APIs and Signal Grove tokens.
6. **Product compositions:** Analytical Workspace, Community Composer, Verification Review Panel and other screen-level assemblies.

External code should be imported into a controlled location, reviewed, and then adapted behind the PacketPulse component API. Do not allow a library's default design tokens, font, colours or icon style to become global product defaults.

## 5.2 UI component/source registry

Counts and pricing/licence terms can change. The entries below are a snapshot of source research dated 25 November 2026; recheck the official page and licence before copying a component or installing a paid item.

| Source | Type | PacketPulse use | Adoption decision | Key checks |
|---|---|---|---|---|
| [Component Gallery](https://component.gallery/) | Component/design-system reference catalogue | Compare patterns for navigation, forms, tables, cards, feedback, calendars and upload patterns | Essential research reference; not a dependency | Study original design-system guidance, accessibility and implementation context |
| [shadcn/ui](https://ui.shadcn.com/) | Source-owned component foundation and registry | Common controls, dialogs, menus, forms, navigation and accessible compositions | Preferred primary foundation | Inspect current primitive family, project React/Tailwind versions and existing packages |
| [Base UI](https://base-ui.com/) | Unstyled accessible component primitives | New shadcn-compatible primitive layer where it fits the existing app | Candidate / current shadcn default for new projects | Do not migrate existing Radix stack only to follow a default |
| [Radix UI](https://www.radix-ui.com/primitives) | Accessible unstyled primitives | Existing or selected dialog, menu, popover, tabs and select behaviours | Retain if already established; avoid arbitrary mixing | Check component coverage and compatibility |
| [Ingot UI](https://ingotui.com/) | Dashboard design-system/component registry | KPI cards, chart panels, admin and analytical patterns | Approved prototype source for selective adaptation; production dependency requires audit | Official docs currently describe React 19 + Tailwind v4 + Base UI; light mode ships and dark mode is listed as a later update. Check current status; verify plan-specific licence and mobile fit |
| [BoardUI](https://www.boardui.com/) | React/Tailwind dashboard component library | Data tables, calendars, charts, KPI cards, sidebars and dashboard blocks | Approved prototype source for selective adaptation; production dependency requires audit for Analytical Workspace | Official site currently advertises React 19.2, Tailwind v4, 104 components and 19 charts; check each component's installability, terms and responsive behaviour |
| [Beautiful UI / Notchset](https://beautiful-ui.dev/) | shadcn-compatible React component and chart registry | Specialised controls, data visualisations, action rails and dashboard blocks | Approved prototype source for selective adaptation; production dependency requires audit | Official docs describe React 19 and Tailwind v4, Base UI and Radix builds; 150 items, including free and Pro tiers. Check item-level licence and primitive match |
| [Bencho](https://bencho.dev/) | Interactive React component and microinteraction library | Resizable panels, autocomplete, avatar groups, network/graph patterns, sliders and interaction ideas | Approved prototype source for selective adaptation; production dependency requires audit and inspiration source | Site states live-tunable blocks; free blocks MIT and Pro source/MCP. Verify individual block licence and dependencies |
| [Transitions](https://transitions.dev/) | Motion recipes, component builder and agent workflow | Card resize, progress, notifications, tabs, modal/panel, skeleton reveal and icon transitions | Approved motion reference/workflow; not a second runtime animation framework | Check free/Pro recipe terms, MCP/skill plan, generated code and performance; use PacketPulse motion tokens |
| [Beautiful UI charts](https://beautiful-ui.dev/components) | Chart examples within registry | Chart patterns and controls | Approved for prototype pattern exploration; standardise chart renderer separately | Ensure accessible labels, series colours, table alternative and data definitions |
| [TanStack Table](https://tanstack.com/table/latest) | Headless table logic | Complex operations, recruiter and moderation data tables | Approved prototype behaviour layer; adopt if existing table stack is insufficient | Use only if existing table layer is insufficient; PacketPulse owns styling |
| [Recharts](https://recharts.org/) | React charting library | Standard bar, line, area and composition charts | Approved prototype renderer candidate; use existing renderer if available | Audit bundle cost, accessibility limitations and current chart dependency before adoption |
| [Motion for React](https://motion.dev/) | Runtime animation library | Layout transitions, gestures and meaningful component motion | Approved prototype runtime candidate from Document 2; verify repository compatibility before installation | Inspect package state and current React/Next compatibility; use CSS for simple transitions |
| [Tiptap](https://tiptap.dev/) | Rich-text editor framework | Community technical composer and knowledge articles | Approved prototype editor candidate; compare against existing editor before adopting | Evaluate schema, extensions, sanitisation, accessibility, collaboration needs and licence |
| [Sonner](https://sonner.emilkowal.ski/) | Toast notification library | Non-blocking save/copy/submit feedback | Candidate | Toasts must not be sole record of high-impact outcomes |
| [Lucide](https://lucide.dev/) | UI icon library | Default interface iconography | Preferred default | Consistent stroke, accessible labels and tree-shaking |
| [Simple Icons](https://simpleicons.org/) | Brand/product logo collection | Technology tags, integrations and vendor identities | Use selectively | Check brand usage and individual trademark terms; never replace generic UI icons |
| [Uppy](https://uppy.io/) | File upload framework | Resumable/large uploads where the upload infrastructure needs it | Candidate only if required | Audit storage, transport, security, server integration and bundle cost |
| [react-dropzone](https://react-dropzone.js.org/) | File selection/dropzone utility | Simple browser drag/drop and file input handling | Lightweight candidate | Does not by itself provide resumable upload transport or server-side validation |

## 5.3 Discovery, inspiration and learning registry

| Source | Type | Use | Status / guardrail |
|---|---|---|---|
| [Browsable](https://browsable.dev/) | Plain-language component search (as supplied by owner) | Discover components by describing a need in natural language | Approved for design research; no runtime dependency; validate availability and exact capabilities |
| [UI Feed](https://ui-feed.dev/) | Live interface inspiration gallery | Observe new interaction and visual ideas; copy patterns only after adapting them | Approved for design research; inspiration, not implementation authority |
| [Polymode Sans](https://polymodesans.com/) | Variable display typeface | Campaign graphics, selected editorial headlines and brand experiments | Approved for prototype typography experiments only; confirm early-access licence, font format and performance before production use. Do not replace Inter for dense application UI |
| [Deimos](https://deimos.evilrabbit.com/) | Design encyclopedia / designer reference | Improve design vocabulary, visual research and team learning | Learning reference, not a component library |
| [Component Gallery design systems](https://component.gallery/design-systems/) | Design-system directory and reference catalogue | Study mature systems such as Polaris, Carbon, Fluent and others | Use original documentation and accessibility guidance, not just screenshots |

## 5.4 Media and asset registry

| Source | Asset type | PacketPulse use | Guardrail |
|---|---|---|---|
| [Unsplash](https://unsplash.com/) | Photography | Campaign, event and selected editorial imagery | Follow Unsplash licence/API conditions, attribution requirements where applicable, hotlink and caching rules |
| [Pexels](https://www.pexels.com/) | Photography and video | Events, community/editorial sections and marketing | Verify licence, API requirements, model/property releases and content suitability |
| [unDraw](https://undraw.co/) | SVG illustrations | Empty states, onboarding and explainers | Follow current licence and avoid distributing the collection as a competing asset library |
| [LottieFiles](https://lottiefiles.com/) | Lottie animations | Selected empty states, onboarding and achievements | Review exact animation licence, attribution and runtime cost |
| [Rive](https://rive.app/) | Interactive vector animation | High-value interactive brand moments and selected illustrations | Review asset/runtime licence, accessibility and performance |
| [Lucide](https://lucide.dev/) | Functional icons | Buttons, navigation, status and controls | Default icon family; do not mix icon families without a reason |
| [Simple Icons](https://simpleicons.org/) | Technology logos | Skills, technology stacks and integrations | Logos are brand assets, not generic pictograms |
| PacketPulse-owned SVGs | Brand illustration and diagrams | Product-specific onboarding, network/architecture diagrams and empty states | Preferred for recognisable core brand moments; record author/source |

### Asset provenance fields

Every non-trivial image, illustration, logo or animation should have a record with:

- Asset ID and local path or managed asset URL.
- Source page and creator/author if known.
- Licence/terms and date checked.
- Attribution requirement.
- Model/property release review where people/property are depicted and the licence requires it.
- Usage scope (marketing, in-app, community, paid tier, etc.).
- Dimensions, format, compression and fallback.
- Owner and replacement/deprecation status.

Do not scrape, bulk-copy or redistribute a provider's asset catalogue. Do not ship user-supplied or third-party assets without confirming the right to use them.

---

# 6. Motion and microinteraction patterns

Motion must make state changes understandable, acknowledge input or clarify spatial relationships. It must not be an attention trap or make a task slower.

## 6.1 Runtime and workflow

- Preferred runtime candidate: Motion for React, subject to repository/dependency audit.
- Use CSS transitions for simple hover, focus and colour changes; do not add JavaScript animation for a simple CSS job.
- Transitions.dev may provide recipes, audit guidance or an AI-agent skill/MCP workflow. It is not automatically a second runtime library.
- Bencho and UI Feed may inform interaction ideas. Copying an effect requires source/licence review and adaptation to the PacketPulse motion tokens.

## 6.2 Motion tokens

| Token | Starting duration | Use |
|---|---:|---|
| `--motion-instant` | 100–120ms | Immediate pressed/selected feedback |
| `--motion-quick` | 120–180ms | Button, bookmark, toggle, check and icon feedback |
| `--motion-standard` | 160–240ms | Tabs, tooltip, toast, dropdown and small overlays |
| `--motion-emphasis` | 240–350ms | Drawers, expandable panels and card layout changes |
| `--motion-milestone` | 350–700ms | A meaningful achievement, assessment result or verification milestone |

Durations are starting values, not an excuse to animate everything. Prefer opacity and transform. Avoid `transition: all`; animate named properties. Do not animate expensive filters, large blur layers or continuously repainting backgrounds.

## 6.3 Approved interaction candidates

| Pattern | PacketPulse use | Guidance |
|---|---|---|
| Number subtle change / pop-in | KPI updates | Use for changed values, not every page load; keep data legible |
| Progress rail fill | File transfer, assessments and onboarding | Reflect real progress; do not fake completion |
| Spinner-to-check / success check | Save or verification completion | Use only after server confirms success |
| Skeleton-to-content crossfade | Dashboard/feed loading | Keep layout stable; no shimmer under reduced motion |
| Panel reveal | Contextual rail, drawer and details | Preserve focus and reading order |
| Sliding tabs | Feed views and analytics periods | Active state must remain understandable without motion |
| Avatar group hover | Participant preview | Desktop enhancement; mobile gets tap/click equivalent |
| Card resize | Expandable insight and dashboard panels | Do not reflow unrelated content abruptly |
| Toast open/close | Low-impact operation feedback | High-impact outcomes must persist on the page or in history |
| Error state | Form or upload failure | Use clear inline explanation; avoid aggressive shake |
| Feature tile hover | Editorial feature cards | Small lift/arrow shift; not 3D on every tile |

## 6.4 Reduced motion and accessible interaction

- Respect `prefers-reduced-motion: reduce` throughout the app.
- Under reduced motion, remove 3D rotation, parallax, shimmer, animated number drums, large scale transitions and decorative entry effects.
- Retain state changes, completion icons, progress values and status text.
- Never communicate state solely through animation.
- Do not auto-advance the featured carousel by default.
- Do not cause vestibular discomfort through pointer-driven 3D tilt or fast perspective movement.

---

# 7. Responsive and accessibility requirements

## 7.1 Responsive layout

- Use existing breakpoints from Document 2: 640, 768, 1024, 1280 and 1536px.
- Analytical Workspace: full sidebar and contextual rail at wide desktop; collapse the rail on smaller desktop/tablet; one-column layout on mobile.
- KPI strips wrap predictably; do not make users horizontally scroll to discover the first key metrics.
- Tables may become stacked records on small screens; keep essential fields and actions visible.
- File upload actions may wrap/stack; filename and status must remain visible.
- Carousels become swipeable horizontal tracks with a clear active item; no compulsory perspective effect.
- Numbered feature cards stack vertically on small screens; maintain sequence ordering.

## 7.2 Accessibility release checks

- WCAG 2.2 AA remains the release target.
- Keyboard access for every interactive control and composite widget.
- Visible focus indicator and logical focus order.
- Text labels accompany semantic colours and icons.
- Chart data has a text summary and table/list alternative.
- File progress and state updates are announced accessibly.
- Carousel supports keyboard, touch and reduced motion; avoid unexpected focus movement.
- Feature cards use semantic headings and links/buttons, not clickable generic containers without keyboard semantics.
- Calendar uses an accessible grid or equivalent date selection pattern and announces selected date.
- Test 200% zoom, narrow viewport, high contrast and screen-reader navigation.

---

# 8. Implementation guidance for Claude and developers

## 8.1 Repository-first rule

Before implementation, record:

- Next.js and React versions.
- Tailwind version and integration mode.
- Current shadcn `components.json` style and primitive family.
- Existing Radix/Base UI packages and component usage.
- Current chart, table, editor, upload, icon and motion dependencies.
- Existing component folders and aliases.
- Current light/dark theme implementation.
- Build, lint, typecheck, test and storybook/catalogue commands.

Do not install all candidate libraries. Choose one source for each required behaviour after this audit. Preserve existing working dependencies unless replacement is justified by a documented need.

## 8.2 Tailwind rule

Tailwind CSS v4 is the styling standard.

- Tailwind Play CDN may be used for throwaway prototypes, isolated demos or exploration.
- Do not use the browser Play CDN in production Next.js.
- Production uses compiled Tailwind CSS v4 through the app's build integration.
- Keep theme values in CSS variables / semantic theme tokens and map them to Tailwind utilities.
- Do not place raw hex values in page components or individual copied library components.

## 8.3 Suggested package decision matrix

| Need | First choice | Alternative / candidate | Install rule |
|---|---|---|---|
| Shared primitives | Existing shadcn setup | Base UI or Radix, according to repo | No primitive migration without audit |
| Dashboard ready-made blocks | BoardUI or Ingot UI | Beautiful UI | Use small selected components; verify licence and dark theme |
| Specialised component | shadcn registry | Bencho / Beautiful UI | Copy and review source into repo |
| Table behaviour | TanStack Table | Existing table package | Adopt only for advanced behaviour |
| Chart rendering | Existing chart package | Recharts | Use one chart renderer, not several |
| Animation | Motion for React | CSS transitions | One runtime motion engine; CSS for simple states |
| Motion recipes | Transitions.dev | Bencho examples | Guidance/source only; no duplicate runtime |
| Rich editor | Existing editor | Tiptap | Audit schema, security, collaboration and accessibility |
| Simple drag/drop | Native input / react-dropzone | Uppy | Uppy only for resumable/complex upload needs |
| Icons | Lucide | Simple Icons for vendor marks | Keep UI icon family consistent |
| Toasts | Existing toast system | Sonner | Avoid duplicate toast providers |

## 8.4 Component acceptance definition

A component is **Approved** only when:

1. It serves a named PacketPulse use case.
2. The source, licence and attribution conditions are recorded.
3. Dependencies are justified and compatible with the repository.
4. It uses Signal Grove semantic tokens in both supported themes.
5. Comfortable/Compact/Reading density is defined where applicable.
6. Loading, empty, success, disabled and error states are documented where relevant.
7. Keyboard, focus and screen-reader behaviour are tested.
8. Mobile/tablet behaviour is reviewed.
9. Reduced-motion behaviour is tested for animated components.
10. Visual regression and functional tests cover important states.
11. It has a stable PP component ID and catalogue page.
12. The owning module and maintainer are identified.

## 8.5 Suggested component folder structure

Adapt this to the existing repository; do not restructure it blindly.

```text
src/
  components/
    ui/                    # primitive controls and wrappers
    shared/                # cross-product PacketPulse components
    workspace/             # analytical/editorial layout compositions
    community/
    learning/
    recruitment/
    payments/
    operations/
  styles/
    tokens.css
    themes.css
    motion.css
  lib/
    component-utils/
    asset-provenance/
```

A component sourced from another registry should be reviewed, adapted and placed under a PacketPulse-owned name and API. Keep a source reference in the registry; do not leave product pages coupled directly to a third-party registry import if it would make future replacement difficult.

---

# 9. Delivery sequence

## Phase 0 — Audit and setup

- Complete repository/library audit.
- Confirm theme tokens and contrast results for Soft Signal Light and Matte Black.
- Confirm primitive family and Tailwind v4 integration.
- Set up or reuse the component catalogue (Storybook or equivalent).
- Create a source/licence review checklist and asset provenance register.

## Phase 1 — Shared foundation (P0)

Build/test:

- Application shell, sidebar, utility header and page header.
- Buttons, inputs, tabs, dropdowns, popovers, dialogs, drawers and toasts.
- Metric card, featured metric, chart panel, table and filter bar.
- Status badge, alerts, empty state, skeleton and progress indicator.
- File transfer and dropzone.
- Member card, question card, answer card and code block.

Deliver one representative Analytical Workspace page and one Editorial Workspace page using the shared components.

## Phase 2 — Supplied reference compositions (P1)

- PP-DASH-001 dashboard composition (Soft Signal Light and Matte Black variants).
- Calendar + agenda panel.
- People/contributor cards and avatar groups.
- Perspective featured carousel.
- Numbered editorial feature tiles.
- Rich technical composer and file preview.

## Phase 3 — Product-specific advanced patterns

- Verification Review Panel (manual, AI-assisted and automated experiment modes with evidence, reason, audit and appeal/re-review pathways).
- Community Health Panel.
- Knowledge Explorer/tree/graph.
- Recruitment candidate pipeline and review drawer.
- Learning pathway and assessment progress compositions.

## Phase 4 — Quality, feedback and expansion

- Run accessibility, responsive, performance and visual regression checks.
- Collect member/team feedback during the agreed review window.
- Record retain/refine/restrict/disable decisions in the next build log.
- Review component reuse, duplicate patterns, licences and bundle impact.

---

# 10. Acceptance checklist for the six visual references

## REF-01 Dashboard

- [ ] Four-card KPI strip or an appropriately sized 3–5 metric set.
- [ ] One featured KPI only where the data warrants emphasis.
- [ ] Clear page header and top utility controls.
- [ ] Main analytic panel has title, period, labels, summary and accessible data alternative.
- [ ] Calendar selected date and agenda are linked.
- [ ] People cards show useful professional context, not vanity metrics.
- [ ] Light and Matte Black token variants work.
- [ ] Tablet/mobile collapse rules are implemented.
- [ ] Whitespace and reading hierarchy are preserved.

## REF-02/03/04 Upload

- [ ] Queued, uploading, paused, processing, completed, failed, canceled and rejected states.
- [ ] Percentage/byte values reflect real upload events.
- [ ] Pause/resume appears only when the transport supports it.
- [ ] Cancel and remove are different actions.
- [ ] Change and Download appear only when meaningful and authorised.
- [ ] Server-side validation and file scanning are enforced.
- [ ] Accessible progress announcements and text/glyph status.
- [ ] Mobile action layout works without overflow.

## REF-05 Carousel

- [ ] Active item clearly distinguished.
- [ ] Adjacent-card preview is an enhancement, not required information.
- [ ] Keyboard, touch and button navigation work.
- [ ] No auto-advance by default.
- [ ] Reduced motion removes perspective/3D effects.
- [ ] Cards have clear accessible names and destination semantics.

## REF-06 Feature tiles

- [ ] Number sequence and title hierarchy consistent.
- [ ] Visual zones use relevant illustration/product imagery.
- [ ] Card colour variations remain within Signal Grove tokens.
- [ ] One clear action per card.
- [ ] Hover/focus are both visible and do not shift layout.
- [ ] Tiles stack in correct sequence on mobile.
- [ ] Reduced-motion behaviour is static and equally understandable.

---

# 11. Source references checked 25 November 2026

- [The Component Gallery](https://component.gallery/) — component and design-system pattern catalogue; [design-system index](https://component.gallery/design-systems/).
- [shadcn/ui](https://ui.shadcn.com/) — source-owned React/Tailwind component foundation and registry.
- [Base UI](https://base-ui.com/) — unstyled accessible React primitives.
- [Radix UI](https://www.radix-ui.com/primitives) — accessible unstyled primitives.
- [Ingot UI docs](https://ingotui.com/docs) and [licence](https://ingotui.com/license) — dashboard design systems, React/Tailwind components and terms.
- [BoardUI](https://www.boardui.com/) and [components](https://www.boardui.com/components) — React/Tailwind dashboard patterns.
- [Beautiful UI docs](https://beautiful-ui.dev/docs), [installation](https://beautiful-ui.dev/docs/installation) and [components](https://beautiful-ui.dev/components) — shadcn-compatible Notchset components and charts.
- [Bencho](https://bencho.dev/about) — interactive React UI components and micro-interactions; read the licence for individual free/Pro blocks.
- [Transitions](https://transitions.dev/), [MCP](https://transitions.dev/mcp.html) and [skill](https://transitions.dev/skill) — transition recipes, motion checks and agent workflows.
- [Browsable](https://browsable.dev/) — owner-supplied plain-language component discovery reference; verify availability before workflow integration.
- [UI Feed](https://ui-feed.dev/) — live interface inspiration and interaction examples.
- [Polymode Sans](https://polymodesans.com/) — variable display typeface with Realness axis; confirm early-access licence.
- [Deimos](https://deimos.evilrabbit.com/) — design encyclopedia / designer reference.
- [Motion for React](https://motion.dev/docs), [Lucide](https://lucide.dev/), [Simple Icons](https://simpleicons.org/), [TanStack Table](https://tanstack.com/table/latest), [Recharts](https://recharts.org/), [Tiptap](https://tiptap.dev/), [Uppy](https://uppy.io/), [react-dropzone](https://react-dropzone.js.org/).
- [Tailwind Play CDN](https://tailwindcss.com/docs/installation/play-cdn) — prototype-only; production builds compile Tailwind CSS.
- [Unsplash licence](https://unsplash.com/license), [Pexels licence](https://www.pexels.com/license/), [unDraw licence](https://undraw.co/license), [LottieFiles licence](https://lottiefiles.com/license), [Rive terms](https://rive.app/legal/terms/).

**External details change.** Recheck current version compatibility, pricing, source availability, licence and maintenance status when a developer actually adopts a component. The repository lockfile and package docs are the final technical source of truth.

# 12. Resources, Signup, Profile and Account component specifications

**Owner disposition:** all patterns and components in this section are **Approved Prototype** for the next review build. The design team has explicit creative freedom to explore colour, composition, image treatment and microinteraction variants. The selected variants must be reviewed for contrast, accessibility, responsiveness, licensing and fit with Signal Grove before becoming production standards.

## 12.1 Resources Library composition — PP-RES-001

**Purpose:** Make Community Resources feel like a curated engineering knowledge library rather than a folder of downloads.

**Desktop composition:** grouped Community sidebar; utility header/global search; breadcrumb; Resources title and one primary Share a resource action; optional featured collection/hero; discovery tabs (For you, Featured, Recent, Popular, Staff Picks); a filter/sort row; primary resource-card grid; optional contextual rail for popular topics, recently added and continue reading. Keep 24–32 px between major groups and let the card grid breathe. A compact view may exist for power users, but Comfortable is default.

**Resource card anatomy:** format icon/thumbnail; title; concise value statement; technology/category chips; source/author; difficulty and estimated time; updated/reviewed date; save control; optional trust/review status. Do not invent ratings or review states. Show a clear external-link cue for off-platform resources.

**Creative variants approved for prototype:** featured collection with editorial illustration; photo/diagram-led collection tiles; dense list mode; resource type colour accents; soft forest/teal gradient wash on one featured surface; muted technical thumbnails. Keep type/status colours semantically clear. Avoid making every card bright or illustrated.

## 12.2 Resource detail and reader — PP-RES-002 / PP-RES-003

**Primary region:** document/PDF/video/article preview. **Left or inline rail:** thumbnails/page navigation or article table of contents. **Right contextual rail:** resource details, tags, difficulty, estimated time, version, last reviewed, source, author, licence/attribution and save/share/report actions. Related resources and community discussion sit below or in a secondary tab; do not compete with reading.

For document preview, show page number, zoom, fit-to-width, download/open and accessible text alternative where available. For video, show captions/transcript when available. For articles, use Reading density, narrow line length and section anchors. External destinations must be identified before opening. The viewer must fail gracefully when preview is unsupported and offer a safe open/download alternative if permission allows.

## 12.3 Share Resource wizard — PP-RES-004 / PP-RES-005

Use a visible three-step stepper: **Details → Content → Review & publish**. Allow Back, Save draft and resume. Details fields: title, short description, resource type (Guide, Documentation, Tool, Template, Course, Video, Cheat sheet, Lab, Repository, Article), category, canonical technology tags, difficulty, intended audience, language and estimated time (if known). Content source: upload file, paste URL or write article. Review fields: author/source, attribution, licence/usage rights, version, last reviewed, visibility and guidelines acknowledgement.

Preview the resource as a recipient will see it. Show validation inline. Upload cards use `PP-UPLOAD-001` and all real lifecycle states. Scan, link validation and rights/attribution checks must be visible. A completed upload is not the same as a published resource. If a resource requires moderation, show “Submitted for review” and let the contributor track status.

## 12.4 Saved resources and collections — PP-RES-006

Tabs: All saved, Reading list, My collections, Recently viewed. Cards may use the perspective carousel pattern only for curated featured collections; the user's full saved library should remain a sortable list/grid. Collection metadata: name, description, cover/representative resource, count, visibility, last updated. Resource status: Saved, Not started, In progress, Completed where measurable. Resume reading at last position only when the source and permissions support it. Unsave never deletes the canonical resource.

## 12.5 Signup and email verification — PP-ID-001 to PP-ID-004

**Signup composition:** split-screen on wide desktop. One side carries PacketPulse's promise, a restrained network/engineering motif and concise trust copy; the other side contains the account form. Avoid overly large marketing copy or moving decorative graphics. On mobile, use a single-column form. Support email/password or passkey as the core path. Google/GitHub buttons are prototype-approved; the real identity provider is enabled only when configured and tested. If mocked, label it as a prototype action and never create a false authenticated state.

Form components: email, password with visibility toggle, password guidance, terms/privacy consent, create account action, existing-account sign-in, provider options and recovery route. Email verification uses a 6-digit code with expiry, resend cooldown, attempt-limit feedback and change-email action. Focus moves to the code field; paste of the full code is supported; announce errors accessibly.

## 12.6 Personalised onboarding — PP-ID-005 to PP-ID-007

A progress stepper guides **Role → Interests → Goals**. Role cards: Student, Engineer, Specialist, Mentor, Recruiter. Interests use canonical skill taxonomy tokens and searchable multi-select chips; allow custom suggestions through taxonomy workflow rather than silently creating taxonomy entries. Goals: Learn, Practice, Contribute, Mentor, Find opportunities. Optional steps may be skipped. Show “You can change this later”. Completion configures starting recommendations, not permissions or recruiter visibility.

## 12.7 Professional Profile — PP-ID-008 to PP-ID-012

The profile identity hero includes avatar, name, professional headline, optional location/timezone, short introduction and Edit Profile action. Banner/cover artwork may use a subtle network motif or member-selected image; avoid decorative data panels that compete with identity. Show verification labels with explicit type. The profile uses tabs/sections: Overview, Skills, Experience, Education & Certifications, Contributions, Learning, Mentoring, Activity and Achievements, rendered only when relevant data exists.

Skills are grouped by evidence state: Self-declared; Assessment verified; Experience verified; Certification verified; PP verified. Each verified state opens an explanation of evidence, issuer/reviewer, criteria, date, expiry and appeal path where permitted. Community contribution reputation is shown separately from verified skills. Profile completeness guidance is optional, dismissible, useful and non-judgmental. An identity timeline is optional and member-controlled.

## 12.8 Visibility Preview — PP-ID-013

Preview selector: My view, Community member view, Recruiter after forwarding. The implementation must call the same audience/field-level visibility rules used by the actual backend; it must not construct a front-end-only approximation. Hidden fields show a brief “Only you can see this” reason where useful. Date of birth, compensation, private notes and resume links follow DEC-015 and consent. Public web preview remains off by default and must not be implied by Community preview.

## 12.9 Account Control Centre — PP-ACC-001 to PP-ACC-006

The Account Settings overview uses spacious grouped cards with clear category descriptions and direct edit/Manage actions. Categories: Personal Information; Profile Visibility; Notifications; Login & Security; Sessions; Connected Accounts; Privacy & Data Rights; Billing & Payments when relevant. Individual detail screens use clear sections and save feedback.

Security page: password/passkey and MFA status, recovery options, active sessions, sign out other sessions, security events. Connected Accounts: provider icon, connected identity, status, requested scopes and unlink action. Prevent unlinking the last viable recovery route; step-up where required. Privacy/Data Rights: consents, export request, erasure request, request status and retained-data explanation. Deletion belongs in a distinct danger zone with consequences, re-authentication and explicit confirmation.

## 12.10 Component registry additions

| ID | Component | Main variants / states | Source inspiration | Review-build status |
|---|---|---|---|---|
| PP-RES-001 | Resource discovery hero and featured collection | Editorial, diagram-led, compact, no-image | REF-08, Component Gallery, BoardUI/Bencho patterns | Approved Prototype |
| PP-RES-002 | Resource card | Guide, PDF, tool, video, course, repo, article; saved/unsaved; reviewed/unreviewed | shadcn, BoardUI, Beautiful UI | Approved Prototype |
| PP-RES-003 | Resource reader/detail shell | Document, article, video, external link; rails collapsed/expanded | shadcn, Base UI/Radix, existing viewer audit | Approved Prototype |
| PP-RES-004 | Resource submission stepper | Details, Content, Review; draft/error/complete | shadcn, Transitions | Approved Prototype |
| PP-RES-005 | Resource rights and attribution block | Licence, source, author, version, warning | PacketPulse-owned composition | Approved Prototype |
| PP-RES-006 | Saved collection and reading state | Private/shared, progress, recently viewed | BoardUI, Bencho | Approved Prototype |
| PP-ID-001 | Split signup layout | Desktop split, mobile single-column, light/dark | PacketPulse-owned composition | Approved Prototype |
| PP-ID-002 | Provider sign-in buttons | Google, GitHub; configured/mock/disabled | shadcn, Lucide / provider brand icons | Approved Prototype |
| PP-ID-003 | Email verification code input | Empty, partial, complete, expired, retry | shadcn, accessible input primitive | Approved Prototype |
| PP-ID-004 | Onboarding stepper | Role, Interests, Goals; skippable optional step | Transitions, shadcn | Approved Prototype |
| PP-ID-005 | Role selection cards | Single-select, selected, disabled | BoardUI, Bencho patterns | Approved Prototype |
| PP-ID-006 | Interest and taxonomy selector | Search, multi-select, selected chips, suggested tag | Bencho, shadcn | Approved Prototype |
| PP-ID-007 | Goal selector | Multi-select cards/chips | PacketPulse-owned composition | Approved Prototype |
| PP-ID-008 | Profile identity hero | Avatar, cover, headline, location, edit | BoardUI, Component Gallery | Approved Prototype |
| PP-ID-009 | Verification-aware skill group | Self-declared, assessment, experience, certification, PP verified | PacketPulse-owned semantics | Approved Prototype |
| PP-ID-010 | Contribution summary | Solved, useful answers, articles, mentoring | BoardUI, Bencho | Approved Prototype |
| PP-ID-011 | Profile visibility preview switcher | Self, Community, Recruiter-after-forwarding | PacketPulse-owned composition | Approved Prototype |
| PP-ID-012 | Profile completeness helper | Suggested actions, dismissed, completed | PacketPulse-owned composition | Approved Prototype |
| PP-ID-013 | Identity activity timeline | Verified skill, assessment, contribution, mentoring milestones | BoardUI timeline patterns | Approved Prototype |
| PP-ACC-001 | Account settings hub | Spacious category cards, status and quick actions | BoardUI, shadcn | Approved Prototype |
| PP-ACC-002 | Settings section card | Default, hover, focus, warning, disabled | shadcn, Ingot UI patterns | Approved Prototype |
| PP-ACC-003 | Notification preference matrix | Event/channel choices, quiet hours, digest | PacketPulse-owned composition | Approved Prototype |
| PP-ACC-004 | Security and session list | Current session, active/expired, revoke, step-up | shadcn, Base UI/Radix | Approved Prototype |
| PP-ACC-005 | Connected account row | Connected, unlinked, issue, unlinking, last-recovery warning | PacketPulse-owned composition | Approved Prototype |
| PP-ACC-006 | Data rights and danger zone | Export, consent, erase request, pending/completed | PacketPulse-owned composition | Approved Prototype |

## 12.11 Creative exploration board

The following variants are explicitly approved for prototype exploration; they are not all required to coexist in one final screen:

- Matte Black resource library with teal/forest hero surfaces and restrained lime actions.
- Soft Signal Light resource discovery with editorial photography or technical diagrams.
- High-contrast file-type accents with semantic text labels, not colour-only identification.
- Perspective featured carousel for selected collections, mentor spotlights or events; static list/grid remains the accessible fallback.
- Numbered feature/step cards for onboarding and learning pathways.
- More expressive display typography (including Polymode Sans experiments) for marketing/editorial headings; Inter remains the baseline for dense product UI.
- Alternate identity hero treatments, cover art and contribution layouts.
- Profile completeness and activity timeline as optional cards that can be individually disabled.

Each variant should state its user hypothesis, audience, expected benefit, risks and measurement. The team may remove a variant in the following build if it does not improve clarity, confidence, usefulness or emotional quality.


# 13. Revision history

| Date | Version | Changes |
|---|---|---|
| 25 Nov 2026 | 1.2 | Added detailed Resources, Signup, Profile and Account component specifications; creative experimentation board and Approved Prototype status for next review build |
