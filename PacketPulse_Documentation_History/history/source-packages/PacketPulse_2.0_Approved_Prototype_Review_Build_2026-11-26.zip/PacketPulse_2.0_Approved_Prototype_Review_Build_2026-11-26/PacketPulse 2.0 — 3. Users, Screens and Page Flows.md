# PacketPulse 2.0 — 3. Users, Screens and Page Flows

Version 3.6 · 26 November 2026 · Owner: product lead with design lead (to be named) · Supersedes the 17 October 2026 Users, Screens and Page Flows v2.0. Requirements are cited as PRD, decisions as DEC and OPEN (Document 1); design rules as DES (Document 2); build capabilities, tasks and tests in Document 4. **[APPROVED PROTOTYPE]** marks owner-approved scope for the next review build; it is not production approval. PV means built and tested in the reference prototype only. Proposed screens and flows in this revision are not proof of production implementation. Which routes exist in production is not known until the repository audit (OPEN-15).

## 1. Users and their main journeys

Each user has one home page, a few frequent screens and one success signal. Screens are listed by ID and described in section 4.

| User | Goal | Entry | Home screen | Frequent screens | Success signal |
| --- | --- | --- | --- | --- | --- |
| Visitor | Understand PacketPulse and decide to join | Search, referral, community link | Home (SCR-001) | Fees (SCR-002), Join (SCR-003) | Registers and verifies email |
| Fresher member | Learn, practice, get a first role | Join, invitation | Dashboard (SCR-004) | Learn, Practice, Assessments, Community, Jobs | First verified skill, first application |
| Experienced member | Grow, prove depth, change roles | Join, referral | Dashboard | Assessments, Practice, Jobs, Applications, Community | Verified skills, an interview |
| Mentor | Help others, build reputation | Invitation by admin or eligible member request | Dashboard | Community, Reviews (SCR-014), Mentoring (SCR-016), Groups and Events | Helpful answers, completed mentoring and reviews |
| Community contributor | Solve engineering problems and publish reusable knowledge | Onboarding interests or search | Community Discover (SCR-047) | Questions, Discussions, Knowledge, Resources, Groups, Events, Profile | Helpful contribution and knowledge reused by others |
| Instructor | Publish and review learning content | Invitation by admin | Dashboard | Content (SCR-017), Reviews | Published content, reviewed labs |
| Recruiter | Fill positions with good candidates | Company onboarding (SCR-033) | Recruiter dashboard (SCR-018) | Positions, Candidates, Candidate review | A hire marked Joined |
| Admin | Keep the platform safe and moving | Staff invitation | Operations (SCR-024) | Verification, Taxonomy, Payments, Analytics | Queues cleared within target times |
| SuperAdmin | Control access, policy and security | Staff invitation | Operations | Users, Roles, Policies, Security | No policy or access change without audit |

### 1.1 Journey maps

| Journey | Steps | Ends when |
| --- | --- | --- |
| Member: discovery to first value (WF-001) | Home, Fees, Join, verify email, choose Fresher or Experienced, required details, resume review, consent, Dashboard, first action (ask, enroll or start a lab) | The member completes a first action |
| Member: prove a skill (WF-002, WF-003, WF-004) | Assessments or Practice, attempt or submit, result or review, add evidence if needed, verification decision, badge | A skill shows a verified label |
| Member: get hired (WF-006, WF-007) | Jobs, Apply (consent and fee declaration), Applications timeline, interview, offer, accept, Joined, invoice | The application reaches Joined or ends with a status the member understands |
| Recruiter: fill a position (WF-006, WF-012) | Company onboarding, create position, review, publish, forwarded candidates, review with scorecard, interview, offer, Joined | The position is Closed as Fulfilled |
| Admin: handle a queue (WF-008) | Sign in with MFA, Operations queue, open item, decide with reason, notify, audit entry | The queue item is closed with a recorded decision |
| Anyone: data rights (WF-011) | Settings or Profile, Privacy, export or erase, confirmation, result | The request is completed and logged |

## 2. Information architecture

### 2.1 Structure

```
Public        Home, Fees, Sign in, Join
Onboarding    Verify email, choose Fresher or Experienced, required details, resume review, consent
Member        Dashboard, Learn, Practice, Assessments, Jobs, Applications, Community (Discover, Questions, Discussions, Knowledge, Resources, Groups, Events, Mentors, Saved), Profile, Notifications, Settings
Reviewers     Reviews (queue, detail), Mentoring, Content (instructors and admins)
Recruiter     Dashboard, Candidates (list, review), Positions (list, detail, form), Interviews
Admin         Operations (Analytical Workspace), Verification, Taxonomy, Content, Payments, Analytics, Moderation, Experiment review
SuperAdmin    Users, Roles, Policies, Security (plus all Admin areas)
```

Relationships that drive navigation: Profile and Taxonomy feed Jobs and Candidates; Assessments, Practice and Verification feed the evidence recruiters see; Jobs feed Applications; Positions feed Candidates; Payments depend on Learn (priced content) and Applications (placement fee); every area writes to the audit log in Operations.

&#91;embedded content: member sign-up path · 6 steps then 5 paths\]

Applying for jobs stays blocked until the required details are complete (PRD-003); every other path opens as soon as the member reaches the dashboard.

### 2.2 Navigation by role

| Role | Primary navigation |
| --- | --- |
| Member | Home, Learn, Practice, Assessments, Jobs, Applications, Community, Profile |
| Mentor | Member pages plus Reviews and Mentoring |
| Instructor | Member pages plus Reviews and Content |
| Recruiter | Dashboard, Candidates, Positions |
| Admin | Operations, Verification, Reviews, Taxonomy, Content, Payments, Analytics |
| SuperAdmin | Admin pages plus Users, Roles, Policies, Security |

Navigation is built from the person's permissions, and the server checks every page and action again (DEC-010). Deep links survive sign-in. A denied page shows a plain explanation and a valid destination (SCR-043). Members have eight items; the mobile bottom bar shows the five most used: Home, Learn, Practice, Community, Jobs, with the rest behind a More item **\[REVIEW\]**.

### 2.3 Visual flexibility across parent/child screens

Child workflows inherit the product's shared design language but are not forced into identical layouts. Explore drawers, sheets, split workspaces, full-page readers, responsive master-detail layouts, contextual tabs and inline expansions based on the task. Use PacketPulse brand motifs as optional transparent overlays; the current pattern work preserves existing page/card backgrounds. Colour, display type and motion can vary by context while navigation, state and accessibility remain coherent.

## 3. Page rules that apply to every screen

| Rule | Detail |
| --- | --- |
| States | Every data screen has loading, empty, error, success and, where relevant, disabled states (DES-001) |
| One primary action | At most one primary button per screen or dialog (DES-008) |
| Titles | One H1 per page; the browser tab title follows it |
| Back and deep links | Detail pages show a breadcrumb; filters and scroll position are kept when returning to a list |
| Responsive | One column below 768 px; tables become stacked cards; dialogs become full screens for long tasks |
| Keyboard | Everything reachable; focus moves to the page heading after navigation |
| Unsaved work | A warning before leaving a changed form; long forms save and resume |
| Permissions | A person never sees a control they cannot use; the server rejects it anyway |

### 3.1 Workspace layout families

| Workspace | Screens | Composition |
| --- | --- | --- |
| Editorial Workspace | Member dashboard, Community discovery, thread, article, learning and profile | Reading-led hierarchy, generous whitespace, contextual navigation, narrow reading measure where appropriate |
| Analytical Workspace | Operations, recruiter analytics, admin analytics, moderation and verification queues | Grouped sidebar, breadcrumb/header, context filters, 4–5 KPIs, primary chart/table area, collapsible contextual rail and detailed records |

The supplied Vantage Admin screenshot is an inspiration reference for the Analytical Workspace, not a pixel-perfect implementation target. Use Matte Black Edition tokens for the preferred analytics reference; support the light theme and responsive layouts. Community/learning editorial pages should not be forced into a dense admin-dashboard pattern.

## 4. Screen register

Columns: ID, screen, proposed route, audience, purpose and main actions, permission, status.

### 4.1 Screens built in the prototype (PV)

| ID | Screen | Route | Audience | Purpose and main actions | Permission | Status |
| --- | --- | --- | --- | --- | --- | --- |
| SCR-001 | Home | / | Visitors | Explain the product loop; Join, Sign in, How fees work | Public | PV |
| SCR-002 | Fees | /fees | Visitors | Free, paid and fee table; worked example | Public | PV |
| SCR-003 | Join and verify | /join | Visitors | Email, 6-digit code, Fresher or Experienced | Public | PV |
| SCR-004 | Dashboard | /dashboard | Member | Loop tracker, next step, completeness, getting-started list | Member | PV |
| SCR-005 | Learn | /learn | Member | Filter by state; enroll, start, continue; buy priced items | Member | PV |
| SCR-006 | Practice | /practice | Member | Open a lab; submit root cause, evidence, fix, prevention; resubmit | Member | PV |
| SCR-007 | Assessments and verified skills | /assessments | Member | Skills with labels; add evidence; take assessment | Member | PV (attempt is a 2-question demo) |
| SCR-008 | Jobs | /jobs | Member | Filter by work mode; apply with consent | Member | PV |
| SCR-009 | Applications | /applications | Member | Timeline; accept or decline offer; pay invoice; withdraw | Member (own) | PV |
| SCR-010 | Community | /community | Member | Search, filter by mode, ask, request a mentor | Member | PV |
| SCR-011 | Thread | /community/id | Member | Answer, vote, follow, report, accept | Member | PV |
| SCR-012 | Profile | /profile | Member | Required details, resume review, career, compensation, consent, privacy, recruiter preview, data requests | Member (own) | PV |
| SCR-013 | Notifications | /notifications | All | List, mark all read | Own | PV |
| SCR-014 | Reviews queue | /reviews | Mentor, Instructor, Admin | Awaiting and reviewed lab submissions | Reviewer | PV |
| SCR-015 | Review detail | /reviews/id | Same | Score four areas, feedback, decide | Reviewer | PV |
| SCR-016 | Mentoring | /mentoring | Mentor | Accept or decline requests | Mentor | PV |
| SCR-017 | Content | /content | Instructor, Admin | Create, submit, review, publish, unpublish | Instructor or Admin | PV |
| SCR-018 | Recruiter dashboard | /recruiter | Recruiter | Attention items, positions at a glance, agenda, activity | Recruiter | PV |
| SCR-019 | Candidates | /recruiter/candidates | Recruiter | Search, filter, sort, compare up to 3 | Recruiter (own company) | PV |
| SCR-020 | Candidate review | /recruiter/candidates/id | Recruiter, Admin | Profile, evidence, assessments, learning, resume, decide, interview, offer | Recruiter (forwarded only), Admin | PV |
| SCR-021 | Positions | /recruiter/positions | Recruiter | Filter by status; pause, close, reopen | Recruiter | PV |
| SCR-022 | Position detail | /recruiter/positions/id | Recruiter | Vacancies, dates, candidates, hiring history | Recruiter | PV |
| SCR-023 | Position form | /recruiter/positions/new | Recruiter | Create or edit; draft from pasted text; fee and experienced-only switches | Recruiter | PV |
| SCR-024 | Operations | /admin | Admin | Screening, jobs awaiting review, moderation, feature controls, audit filter | Admin | PV |
| SCR-025 | Verification | /admin/verification | Admin | Queue, review, revoke | Admin | PV |
| SCR-026 | Taxonomy | /admin/taxonomy | Admin | Tree, suggestions, automation | Admin | PV |
| SCR-027 | Payments | /admin/payments | Admin | Transactions, refunds, approve refund | Admin | PV |
| SCR-028 | Analytics | /admin/analytics | Admin | Funnel by segment | Admin | PV |
| SCR-029 | Users | /admin/users | SuperAdmin | Search, manage with step-up | SuperAdmin | PV |
| SCR-030 | Roles | /admin/roles | SuperAdmin | Permission matrix | SuperAdmin | PV |
| SCR-031 | Policies | /admin/policies | SuperAdmin | Recruiter visibility, AI policy | SuperAdmin | PV |
| SCR-032 | Security | /admin/security | SuperAdmin | Settings, sessions, access review | SuperAdmin | PV |

### 4.2 Screens approved or proposed but not built

| ID | Screen | Why it is needed | Status |
| --- | --- | --- | --- |
| SCR-033 | Company onboarding and verification | Recruiters register a company before posting (OPEN-10) | Planned |
| SCR-034 | Assessment attempt | Timed, autosaving attempts with instructions and results (PRD-017) | Planned |
| SCR-035 | Course and lesson player | Real content delivery | Planned |
| SCR-036 | Lab workspace | Topology, logs and terminal for real labs | Proposed (later) |
| SCR-037 | Notification preferences | Channels, quiet hours (PRD-041) | Planned |
| SCR-038 | Data export and erasure | DPDP rights (PRD-045) | Planned |
| SCR-039 | Billing history | Members see invoices and receipts | Planned |
| SCR-040 | Interview calendar | Scheduling with invitations | Proposed (later) |
| SCR-041 | Integrations settings | ClickUp and n8n (OPEN-12) | Planned |
| SCR-042 | Public member profile | Not at launch; profiles stay private (PRD-052, OPEN-19) | Deferred **\[REVIEW\]** |
| SCR-043 | Error pages (no access, not found, server error, maintenance) | Recovery paths | Planned |
| SCR-044 | Hide from companies | List of companies the member blocks (PRD-050) | Proposed **\[REVIEW\]** |
| SCR-045 | How verification works | Public page with the criteria for each label (Document 1, 10.1) | Proposed **\[REVIEW\]** |
| SCR-046 | Community guidelines | The moderation rules and appeals route (Document 1, 10.4) | Planned |

### 4.3 Dialogs and interaction surfaces (PV)

| ID | Surface | Purpose | Key rules |
| --- | --- | --- | --- |
| SCR-D01 | Apply | Consent to share resume; fee declaration and permission | Both fee ticks required when a fee applies; blocked if required details are missing or the role is experienced-only |
| SCR-D02 | Add evidence | Certification or experience submission | Validation per PRD-013 |
| SCR-D03 | Evidence review | Two checks, decision, reason | PRD-014 |
| SCR-D04 | Step-up confirmation | Reason and fresh code for sensitive actions | Lockout after repeated failures |
| SCR-D05 | Manage user | Reset link, MFA reset, sign out, role change, suspend | Every action audited; the user is notified |
| SCR-D06 | Checkout | Price, GST, payment, refund policy | Sandbox only; double payment prevented |
| SCR-D07 | Accept offer | Shows the exact fee; second confirmation | PRD-037 |
| SCR-D08 | Pause, close, reopen position | Reasons and dates | PRD-031 |
| SCR-D09 | Schedule interview, record outcome | Round, interviewer, IST time | PRD-034 |
| SCR-D10 | Compare candidates | Side by side, up to 3 | Respects visibility |
| SCR-D11 | Request a mentor, report, withdraw, decline | Reasons where required | Per PRD |
| SCR-D12 | Command palette | Search pages and actions by role | Keyboard first |

### 4.4 Community knowledge-network additions

| ID | Screen | Proposed route | Audience | Purpose and main actions | Permission | Status |
| --- | --- | --- | --- | --- | --- | --- |
| SCR-047 | Community Discover | /community/discover | Member | For you, Latest, Unanswered and Solved feeds; follow/mute topics; save content; discover experts | Member | Approved Prototype |
| SCR-048 | Structured post composer | /community/new | Member | Choose Question, Discussion, Case study, Knowledge article, Event/AMA or Announcement; draft, preview and publish | Member; additional content types may require moderation | Approved Prototype |
| SCR-049 | Knowledge library and search | /community/knowledge | Member | Search questions, answers, articles, members, groups, events and related learning; filters and saved search | Member | Approved Prototype |
| SCR-050 | Groups and interest spaces | /community/groups | Member, Moderator | Browse/join groups, view group feed/resources, manage membership and moderation | Member / Moderator | Approved Prototype |
| SCR-051 | Events and expert sessions | /community/events | Member, Mentor, Admin | Browse, RSVP, reminders, attendee list and post-event resources | Member / Host | Approved Prototype |
| SCR-052 | Community contribution profile | /profile/contributions | Member | Contribution history, solved questions, articles, mentoring and reputation; member-controlled visibility | Member (own); viewer-scoped | Approved Prototype |
| SCR-053 | Automated verification experiment review | /admin/verification/experiments | Admin, SuperAdmin | Configure mode, policy, thresholds, cohorts, review outcomes, appeal/escalation and rollback | Authorised Admin; policy changes SuperAdmin | Approved Prototype |

Existing screens are updated by layout family rather than duplicated: SCR-004 Member Dashboard = Editorial Workspace; SCR-018 Recruiter Dashboard = Analytical Workspace; SCR-024 Operations = Analytical Workspace; SCR-028 Analytics = Analytical Workspace; SCR-025 Verification = queue-first analytical view with member-friendly detail states.

### 4.5 Resources and identity review-build screens (Approved Prototype)

| ID | Screen | Proposed route | Audience | Purpose and main actions | Permission | Status |
|---|---|---|---|---|---|---|
| SCR-054 | Resources Library | /community/resources | Member | Discover curated resources; search; filter by category, format, technology, difficulty and audience; switch For you/Featured/Recent/Popular/Staff Picks; save and open collections | Member | Approved Prototype |
| SCR-055 | Resource Detail / Reader | /community/resources/[id] | Member | Preview/open document, video, article or external source; table of contents; view source, author, attribution, licence, version and last review; save/share/report; related resources and discussion | Member | Approved Prototype |
| SCR-056 | Share a Resource | /community/resources/share | Member, Contributor | Three-step Details → Content → Review & publish wizard; upload file, add URL or write article; choose type/category/technologies/difficulty/audience; record source and licence; preview; save draft/submit | Member; moderator review where required | Approved Prototype |
| SCR-057 | Saved Resources and Collections | /community/resources/saved | Member | All saved, Reading list, My collections, Recently viewed and Continue reading; create/rename/reorder/share/delete own collections; update reading status | Member (own) | Approved Prototype |
| SCR-058 | Resource Review Queue | /admin/resources/review | Moderator, Admin | Review submissions, scan/link status, source/rights/attribution, preview and version; approve, request changes, reject, hide or archive with reason | Moderator/Admin | Approved Prototype |
| SCR-059 | Personalised Onboarding | /onboarding/personalise | New member | Stepper for Role → Interests → Goals; choose Student/Engineer/Specialist/Mentor/Recruiter; choose taxonomy-backed interests; choose learning/community/career goals; skip optional steps and edit later | Authenticated member (own) | Approved Prototype |
| SCR-060 | Profile Visibility Preview | /profile/preview | Member | Preview self, community-member and recruiter-after-forwarding view; explain hidden fields and why; edit audience-specific visibility | Member (own) | Approved Prototype |
| SCR-061 | Account Settings Overview | /settings | Member, Recruiter, Staff | Entry point for personal information, profile visibility, notifications, security, sessions, connected accounts, privacy/data rights and billing where applicable | Own account; role-scoped | Approved Prototype |
| SCR-062 | Login, Security and Sessions | /settings/security | Member, Recruiter, Staff | Password/passkey, MFA, recovery, active sessions, sign out other sessions, security history and step-up | Own account; stronger staff controls | Approved Prototype |
| SCR-063 | Connected Accounts | /settings/connections | Member | View/link/unlink Google, GitHub and LinkedIn where configured; explain permissions and account-linking consequences | Own account; step-up to unlink last recovery method | Approved Prototype |
| SCR-064 | Recording / Media Viewer | /media/[mediaId] | Member, Learner | Play hosted recordings, direct files and approved provider embeds; show playback controls, captions, transcript, chapters, speed, quality where available, progress/resume, optional audio waveform for audio-only assets, source and related resources | Entitled audience; media visibility follows parent resource/course | Approved Prototype |
| SCR-065 | Embedded File Preview | /files/[fileId]/preview | Member, Learner, Reviewer | Render supported PDF, image, audio/video, text/Markdown/code and safe tabular previews; show unsupported/blocked format fallback and download permission | Same permission as source file; private files use short-lived access | Approved Prototype |
| SCR-066 | Upload Manager / Processing Detail | /uploads/[uploadId] (also available as a drawer) | Member, Contributor, Reviewer | Select files, upload, pause/resume/retry/cancel, view scan/transcode/thumbnail/processing states, preview, replace or remove before publication | Uploader and authorised reviewers; private object access | Approved Prototype |
| SCR-067 | Media Embed and Source Details | /community/resources/[id]/source | Member, Moderator | See source provider, embed type, original link, licence/attribution, caption/transcript availability and provider availability; report broken or unsafe source | Member; moderation fields restricted | Approved Prototype |

Existing screens are extended rather than duplicated: SCR-003 becomes the split-layout signup and email-verification entry; SCR-012 becomes the living professional profile; SCR-037 carries the expanded notification preferences; SCR-038 carries privacy, export and erasure; SCR-044 remains the hide-from-companies control. SCR-042 public web profile remains off by default and is not silently enabled by profile previews.

## 5. Detailed specs for screens not yet built

Each spec follows the handoff pattern: content, actions, rules and states, and sample copy. Sample copy uses the patterns in Document 2 section 11.

| Screen | Content and fields | Actions | Rules and states | Sample copy |
| --- | --- | --- | --- | --- |
| SCR-033 Company onboarding | Company name, website, size band, contact person (name, work email, phone), registration or GST number (optional), LinkedIn company page (optional), agency toggle with end-client name | Save draft, Submit for review | Free email domains are held for review. Status timeline: Submitted, In review, Approved or Changes requested. Positions can be drafted but not published until approved. Rejected or suspended shows the reason. See Document 1, 10.6 **\[REVIEW\]** | Your company is in review. You can draft positions while you wait. |
| SCR-034 Assessment attempt | Instructions page (time, attempts left, pass mark, validity, honesty statement tick), question view (Question 4 of 20, visible timer, flag for review, previous, next, navigator), review page listing unanswered and flagged items, result page (score, pass or not, level, weak topics, next step) | Start, Next, Flag, Submit, Leave | Autosave every answer; a reload resumes the same attempt with the remaining time; one active attempt only; attempts and retake gap enforced; the timer is announced to assistive technology at 10 minutes and 1 minute, not every second; locked state shows the next available date. Values in Document 1, 10.2 | Submit with 3 questions unanswered? You cannot change answers after submitting. Buttons: Submit now, Keep working |
| SCR-037 Notification preferences | Grid of event types by channel, quiet hours, WhatsApp opt-in with number confirmation, separate marketing opt-in, digest frequency | Save | In-app is always on; critical events are listed and cannot be switched off; every change is recorded with a time. Defaults in Document 1, 10.3 | Interview and offer messages always reach you, even in quiet hours. |
| SCR-038 Data rights | Sections: Download my data, Correct my data (link to Profile), Withdraw consent (list), Delete my account and data, Grievance contact | Request download, Withdraw, Delete account | Re-enter the password or a code before deletion; a 30-day grace period to cancel; the page lists what is kept for legal reasons and for how long; requests show Open, In progress, Done | We will email a link when your data is ready. The link works for 7 days. |
| SCR-039 Billing history | Invoices and receipts with status chips (Paid, Due, Refunded), download as PDF, placement-fee invoices show the offer they belong to | Pay now, Download | Empty state explains when invoices appear; a due invoice shows the due date and days left | No invoices yet. Paid courses and placement fees appear here. |
| SCR-043 Error pages | No access, Not found, Something went wrong, Maintenance | One next action each; a reference code to quote to support | Never show technical details | We could not find that page. Go to your dashboard, or search for what you need. |
| SCR-044 Hide from companies | List of blocked companies with remove buttons; add by company name | Add, Remove | Up to 20; matched by name and web domain; staff can still see the profile; an agency cannot be guaranteed to honor it **\[REVIEW\]** | Hidden companies will not see your profile in search or in forwarded lists. |
| SCR-045 How verification works | The five labels, what is checked, who decides, validity, appeals | Link from every badge | Public page; same wording as Document 1, 10.1 **\[REVIEW\]** | PP verified means two kinds of evidence, one of them reviewed by a person. |
| SCR-046 Community guidelines | Rules, action steps, response times, appeals route | Accept (first post), Report | Linked from every post form; acceptance recorded | Never post passwords, keys or customer data. |

### 5.1 Resource and identity screen specifications (review build)

**SCR-054 — Resources Library**
- Header: breadcrumb Community / Resources, H1 “Resources”, one-line purpose statement, primary “Share a resource” action.
- Discovery feature: optional featured collection with editorial illustration/diagram, title, short description and CTA.
- Tabs: For you, Featured, Recent, Popular, Staff Picks. Filters: Category, Format, Technology, Difficulty, Audience, Sort.
- Main content: resource cards with file/type icon or thumbnail, title, short value proposition, technology chips, author/source, difficulty/estimated time, updated/reviewed date, save control and moderation/quality label where applicable.
- Optional right rail: popular topics, recently added, curated collections and “continue reading”; collapses on tablet and becomes a sheet/stack on mobile.
- States: first-use empty, no results, loading, error/retry, saved, hidden/removed resource and restricted resource.

**SCR-055 — Resource Detail / Reader**
- Primary column: document/media/article preview with zoom/page controls where supported; article uses readable measure and section anchors; video has captions/transcript when available; external links show destination before opening.
- Secondary rail: table of contents, metadata, format, difficulty, estimated time, version, last reviewed, author/contributor, source, licence and attribution.
- Actions: Open/Download (when permitted), Save, Add to collection, Share, Report issue, Helpful/Not helpful.
- Lower section: related resources, community discussion/questions and “learn/practice this topic” cross-links.
- Do not claim a third-party resource is reviewed unless a real review event exists. Broken or expired links show an explanation and report action.

**SCR-056 — Share a Resource**
- Step 1 Details: title, short description, resource type (Guide, Documentation, Tool, Template, Course, Video, Cheat sheet, Lab, Repository, Article), category, technology tags, difficulty, intended audience and language.
- Step 2 Content: choose Upload file, Paste URL or Write article. Upload supports queued/uploading/paused/processing-scanning/complete/failed/canceled/rejected states. Pause/resume only when transport supports it. Show actual bytes transferred, filename, size and validation.
- Step 3 Review & publish: preview, source/author, attribution, licence/usage rights, optional version and review date, audience visibility, community guidelines confirmation and submission status.
- Save draft at every step. If upload or validation fails, preserve completed fields and offer retry/remove/replace. Never publish a file that has not passed the configured scan and server-side validation.

**SCR-057 — Saved Resources**
- Tabs: All saved, Reading list, My collections, Recently viewed.
- Collection cards show name, description, resource count, privacy/sharing state, cover thumbnail and last updated. Resource list shows type, title, category, reading state, saved date and actions.
- Reading state: Not started, In progress, Completed. Progress is only shown when the underlying resource supports meaningful progress; otherwise use simple saved status.
- Continue reading resumes at a stored, permission-checked location. Member can remove a save without deleting the source resource.

**SCR-058 — Resource Review Queue**
- Analytical Workspace: KPI strip (Pending review, Needs changes, Scan/link issues, Recently published); filters; submission table; contextual review rail.
- Detail pane: content preview, metadata, attribution/licence evidence, file scan, URL health and revision history.
- Actions: Approve, Request changes, Reject, Hide/Archive. Every non-approval action needs a reason; every decision is audited and author receives a status message.

**SCR-003 — Signup and verification refresh**
- Wide screen: split layout with a restrained PacketPulse brand/story panel and a focused account form. Small screens: single-column form with no decorative panel competing with inputs.
- Options: email/password or passkey; Google/GitHub provider buttons are approved for prototype display and interaction. Real provider authentication is enabled only after provider setup and security audit; otherwise show a clearly labelled demo/disabled state in prototype.
- Include password visibility, strength guidance, Terms and Privacy consent, email verification, resend cooldown, error and recovery states. Keep login and account recovery links visible.

**SCR-059 — Personalised onboarding**
- Three-step progression: Role, Interests, Goals. Selected chips/cards show a check and accessible selected state. Role is single-select; interest and goal can be multi-select. Optional fields can be skipped. A small “You can change this later” note reduces pressure.
- On completion, create editable preferences and route to a personalised Community/Resource/Learn landing. Recommendations must be explainable and hide/mute controls are available later.

**SCR-012 — Professional Profile**
- Identity hero: avatar, name, headline, location/timezone if supplied, short introduction, edit button and distinct verification label. Do not use one generic “Verified” badge for every verification type.
- Tabs/sections: Overview, Skills, Experience, Education & Certifications, Contributions, Learning, Mentoring, Activity and Achievements where data exists.
- Skills section groups Self-declared, Assessment verified, Experience verified, Certification verified and PP verified; each has a detail view showing evidence/issuer/reviewer/date/expiry as permitted.
- Contributions show solved questions, useful answers, articles, case studies and mentoring, but community reputation never substitutes for skill verification.

**SCR-060 — Profile visibility preview**
- Preview modes: “My view”, “Community member view” and “Recruiter after forwarding”. The preview is generated by the same field-level policy as actual access; it is not a cosmetic mock.
- Explain each hidden field with a short reason and an action to change the setting when allowed. Do not expose date of birth, compensation, private notes, contact data or resume links beyond DEC-015 and consent.

**SCR-061 to SCR-063 — Account Control Centre**
- Settings hub uses spacious grouped cards: Personal information, Profile visibility, Notifications, Login & security, Sessions, Connected accounts, Privacy & data rights and Billing (when applicable).
- Security/session screens show current device, last active, approximate location only if the auth provider provides it reliably, sign-out controls, MFA/passkey state and recent security events. Do not invent device details.
- Connected accounts explain provider scopes and consequences. Prevent unlinking the last viable recovery method. Account linking/unlinking requires clear confirmation and may require step-up.
- Privacy/data rights reuse SCR-038: view consent, withdraw optional consent, request export, request erasure and see request status. Deletion is separated in a danger zone and requires re-authentication and confirmation of consequences.

## 6. Workflows

Each workflow lists actors, steps, failure and recovery, and notifications and audit. State names are in section 7.

| ID | Workflow | Actors and steps | Failure and recovery | Notifications and audit |
| --- | --- | --- | --- | --- |
| WF-001 | Member: discovery to first value | Visitor reads Home and Fees, joins, verifies email, picks Fresher or Experienced, completes required details, reviews the parsed resume, sets consent, reaches the Dashboard, takes a first action | Wrong or expired code gives a clear message and a resend after a cooldown; a parse failure falls back to manual entry | Welcome email; consents recorded with times |
| WF-002 | Evidence verification | Member adds evidence and confirms accuracy; skill shows Pending; reviewer ticks two checks and decides: Approve, Need more evidence, or Reject (reason of 10 or more characters); rejected evidence can be appealed once; approved evidence can be revoked and expires on its date | A decision without both checks or a reason is refused | Member told of every decision; audit records who, when, reason, policy version |
| WF-003 | Assessment to verification (Planned) | Discover, check eligibility, read instructions, attempt, submit, see the result; a pass creates an evidence record for review; the reviewer decision issues the badge or sends the member to practice | Autosave protects answers; attempts and retake gaps enforced | Result notification; audit of the decision |
| WF-004 | Lab practice | Open lab, work through observe, hypothesize, test, collect evidence, root cause, fix, explain, prevent; submit four parts; a reviewer scores four areas 0 to 4; the member can resubmit up to three attempts | A fourth attempt is refused | Member told of the result; review recorded |
| WF-005 | Community question and moderation | Ask (mode, title, detail, sensitive-data confirmation); others answer and vote; the asker accepts one answer; anyone can report with a reason; a moderator dismisses or removes | Removal needs a reason shown to the author | Moderator action audited |
| WF-006 | Recruitment, end to end | Recruiter drafts a position and submits it; reviewer publishes or requests changes; members apply; Admin screens and shortlists; a person forwards; the recruiter reviews with a scorecard, decides, schedules interviews, records an outcome, extends an offer; the member accepts or declines; the recruiter marks Joined | A declined offer lowers the filled count and can pause a position that had closed as fulfilled | Member told at every stage; recruiter reminded after 10 working days without an update (PRD-051); every step audited |
| WF-007 | Fee consent and invoicing | Role shows the fee; apply with declaration and permission; accept the offer with the exact amount and a second confirmation; recruiter marks Joined; invoice created, due in 15 days; member pays through the checkout | No offer, a declined offer or a withdrawal owes nothing | Invoice email; payment audit |
| WF-008 | Admin action with audit | Sign in with MFA; open the queue; choose an action; sensitive actions ask for a reason and a fresh code; the action runs | A refund requested by an Admin waits for a SuperAdmin | User notified; audit entry written |
| WF-009 | Content publishing | Instructor drafts with required details; submits; reviewer publishes or requests changes with a reason; learners see it as Available; an Admin can unpublish | Publishing without required metadata is refused | Author notified |
| WF-010 | Paid service and refund | See the price and GST; pay; receive receipt and access; a refund needs a reason | Failed payment keeps the cart and says why | Receipt; refund audited |
| WF-011 | Data rights and consent (Planned) | Member views consents, withdraws one, exports data or requests erasure; the system confirms, completes within the policy period and logs it | A pending request can be canceled during the grace period | Confirmation emails; audit |
| WF-012 | Company onboarding (Planned) | Recruiter signs up with a work email; enters company details; Admin reviews; approved companies can publish; the first position is always reviewed | Changes requested shows the reason and lets the recruiter edit and resubmit | Recruiter notified of each status; audit |
| WF-013 | Hide from companies (Proposed) | Member adds company names; those companies stop seeing the profile in search and forwarded lists | A name that matches several companies asks the member to choose | Audit of changes |
| WF-014 | Community knowledge loop (Proposed) | Member discovers a topic, opens a structured post, asks/answers or publishes a case study, saves/follows it, and follows links to related knowledge, learning or practice | Draft autosave, sensitive-data warning, duplicate suggestion, report/mute controls | Contribution and content events; no public exposure beyond visibility policy |
| WF-015 | Groups, events and mentoring (Proposed) | Member joins a curated group, RSVPs to an event or requests a mentor with a goal; host/mentor accepts or declines; useful resources are attached afterward | Capacity, schedule/time-zone conflict, decline reason and cancellation paths are explicit | RSVP/reminder delivery; membership and moderation audit |
| WF-016 | Automated skill-verification experiment (Experiment candidate) | Policy selects Manual, AI-assisted or Automated mode; evidence is checked against versioned criteria; high-confidence outcomes may be decided automatically; configured uncertain/high-risk cases route to human review; member can appeal/re-request review | Feature flag off, model/policy unavailable, insufficient evidence, low confidence, conflicting signals and appeal all route to safe/manual handling | Store evidence references, decision reason, confidence band, policy/model version, timestamp and actor/system; notify member; append-only audit |


| WF-017 | Resource discovery, contribution and curation | Member discovers/searches/filters resources; opens detail; saves or adds to a collection; contributor drafts a resource, supplies content/source/licence, submits for review; moderator validates and publishes or requests changes | Broken link, unsupported file, unsafe file, missing rights/attribution, scan failure or moderation rejection preserve the draft and show a reason; member can replace/re-submit where allowed | Resource view/save/download/share events; resource version and review audit; no private file URL leakage |
| WF-018 | Signup and personalised onboarding | Visitor selects sign up; registers by email/password or passkey (optional provider sign-in when configured); verifies email; chooses role, interests and goals; completes/skip optional profile details; lands on personalised dashboard | Provider unavailable falls back to email; expired code can be resent after cooldown; onboarding can be resumed; preferences editable later | Consent timestamp/version, verification result, provider link audit and onboarding preference event |
| WF-019 | Profile and account management | Member views/edits professional profile; previews self/community/recruiter-after-forwarding views; changes visibility; opens Account Settings; manages notifications, security, sessions, connections and data rights | Sensitive fields remain hidden by policy; account-link failure does not lock member out; deletion requires re-authentication; privacy changes take effect immediately or show pending status | Visibility and consent changes audited; account security events logged; export/erasure follows WF-011 |
| WF-020 | Parent-child and nested navigation | User enters a parent section, opens child detail or workflow, moves between sibling tabs/records and returns to the parent | URL and breadcrumb reflect location; browser Back/Forward works; preserve parent query/filter/selection/scroll/focus where feasible; child route permissions are checked server-side; mobile uses an obvious full-screen child route when a split panel is unsuitable | Navigation events avoid private content in URLs; focus returns to the invoking control; no stacked modal traps |
| WF-021 | Embedded recording/media playback | User opens a resource/course recording, plays or pauses, seeks, changes speed/quality, reads transcript/chapters, resumes later and follows related content | Media source type selects the right adapter; external provider is allow-listed; captions/transcript availability is explicit; failures have retry/open-provider/fallback states; playback progress respects privacy and parent visibility | Playback progress is scoped to the member; provider events are handled safely; no autoplay with sound |
| WF-022 | File upload, processing and preview | User selects or drops media/document, validates, uploads with resumable transport where supported, scans, transcodes/generates preview and submits for review | Pause/resume/retry/cancel states are real; file signature and size/type validated server-side; scan/transcode errors do not publish; unsupported files have a safe fallback; upload ownership and signed access are enforced | Upload/process events are auditable; private URLs are short-lived; malicious files never enter preview pipeline |
| WF-023 | Resource child-view navigation | User opens resource detail, then jumps to Watch/Read, Transcript, Discussion, Versions or Source and returns | Parent resource context and selected child tab stay available; deep links open at the correct child state; mobile preserves a back path | No dead-end child panes; access rights are inherited from the resource and checked on every sub-route |
| WF-024 | Audio waveform and transcript interaction | User opens an audio-only recording, views waveform, seeks by tapping/dragging, jumps to transcript/chapters and resumes listening | Waveform is optional and source-specific; pre-decoded peaks are used for streams/large files where required; normal audio controls remain available if waveform fails or is disabled | Keyboard seek, screen-reader time controls, reduced-motion behaviour and progress privacy are tested |

## 7. State models

Each model lists states, allowed moves and moves the server must reject.

&#91;embedded content: application lifecycle · 9 steps, 3 early endings\]

| Model | States | Allowed moves | Moves to reject |
| --- | --- | --- | --- |
| Application | Received, Processing, Under review, Shortlisted, Ready to forward, Forwarded, Interview, Selected, Joined; Rejected, Withdrawn, Job closed | Forward only after screening; Interview after Forwarded; Selected after Interview; Joined after an accepted offer | Joined without an accepted offer; any change after Withdrawn |
| Recruiter decision | Under review, Shortlisted, On hold, Rejected | Any to any until a final outcome; Rejected sets the application to Not selected | A decision change after Selected or Joined |
| Position | Draft, In review, Changes requested, Published, Paused, Closed (Fulfilled or Unfulfilled) | Submit, publish, request changes; pause and resume; close; reopen | Publish without review; reopen without a future deadline or with openings not above the filled count |
| Company | Pending, Approved, Changes requested, Suspended | Admin approves or asks for changes; suspend with a reason | A position published by a Pending company |
| Evidence | Pending, Needs more evidence, Approved, Rejected, Appealed, Revoked, Expired | Decide from Pending or Appealed; resubmit from Needs more evidence; appeal once from Rejected; revoke from Approved; expire by date | Approve without both checks; a second appeal; a decision by a non-reviewer |
| Lab submission | Under review, Needs revision, Passed, Failed | Decide from Under review; resubmit from Needs revision up to attempt 3 | A fourth attempt; a pass with any area below 2 |
| Assessment attempt | In progress, Submitted, Passed, Not passed, Expired | Submit before the time ends; retake after the gap | A second active attempt; a retake inside the gap |
| Offer | Extended, Accepted, Declined, Joined | Accept or decline from Extended; Joined from Accepted | Accept after the validity date; Joined from Declined |
| Fee invoice | Due, Paid, Refunded | Created after Joined; paid; refunded | An invoice before Joined or after a declined offer |
| Badge | Earned, Displayed, Expiring, Expired or Revoked, Renewed | Expiring 60 days before expiry; renewal by new evidence | Display after Expired |
| Notification | Queued, Sent, Delivered, Read, Failed | Retry from Failed within a limit | Sending after an opt-out |
| Moderation report | Open, Dismissed, Removed | Decide from Open | Removing without a reason |
| Community content | Draft, In review (where required), Published, Hidden, Archived | Publish according to content type and permissions; hide/remove with reason; appeal/restore through policy | Publishing blocked content; silent deletion of audited records |
| Group membership | Requested, Active, Muted, Left, Removed | Join/open group according to visibility; moderators remove with reason; member may leave | Access to private group without membership |
| Event RSVP | Interested, Registered, Waitlisted, Cancelled, Attended, No-show | RSVP subject to capacity; waitlist promotion; host records attendance | Over-capacity registration without waitlist rule; time-zone ambiguity |
| Automated verification decision | Queued, Evaluating, Auto-approved, Auto-rejected, Needs human review, Appealed, Reversed, Failed | Only when experiment flag and policy active; decision records model/policy version; appeal triggers re-review | Missing evidence, missing policy version, disabled flag, out-of-range confidence or unaudited decision |

| Content | Draft, In review, Changes requested, Published, Archived | As in PRD-022 | Publish without required details |

| Resource | Draft, Submitted, In review, Changes requested, Published, Hidden, Archived, Rejected | Submit after metadata/content checks; reviewer publishes or requests changes/rejects with reason; author edits and resubmits where permitted; hide/archive preserves audit/version history | Publish before required scan/rights checks; silent deletion of published/used resource; download without permission |
| Saved resource | Not saved, Saved, In reading list, In progress, Completed, Removed | Member saves/unsaves; moves to own collections; reading progress updates only when supported | Deleting a saved pointer deletes the source resource; sharing a private collection without owner action |
| Upload item | Queued, Uploading, Paused, Processing, Scanning, Complete, Failed, Canceled, Rejected | Actual transport progress; resume only if supported; replace/retry on failure; publish only after processing and scan success | Fake progress; treating upload complete as safe/published; pause/resume when transport does not support it |
| Signup | Draft, Email pending, Verified, Onboarding, Active, Recovery required, Suspended, Closed | Verify within expiry; resend on cooldown; recover through allowed method; onboarding can resume | Active account before required verification; linking provider without ownership confirmation; bypassing age gate |

## 8. Screen-to-system traceability

Chain: screen, component, user action, workflow, capability (API in Document 4), data, permission, acceptance test (TEST in Document 4). A screen without a capability row is a demonstration, not a feature. A task is complete only when its screen, capability, data and test rows all exist and pass.

| Screen | Action | Workflow | Capability | Data | Permission | Acceptance |
| --- | --- | --- | --- | --- | --- | --- |
| SCR-D01 Apply | Submit application | WF-006, WF-007 | API-024 | Application, consent | Member | TEST-021: both fee ticks required; consent stored with a time |
| SCR-D03 Evidence review | Save decision | WF-002 | API-017 | Evidence, approval, audit | Admin, SuperAdmin | TEST-016: approval without two checks is refused |
| SCR-015 Review detail | Save review | WF-004 | API-020 | Submission, review | Reviewer | TEST-018: a pass needs every area at 2 or more |
| SCR-020 Candidate review | Save decision, schedule | WF-006 | API-027, API-028 | Application, scorecard, interview | Recruiter (forwarded) | TEST-025: an unforwarded candidate returns not available |
| SCR-009 Applications | Accept offer | WF-007 | API-030 | Offer, invoice | Member (own) | TEST-029: fee shown and confirmed before acceptance |
| SCR-029 Users | Reset link | WF-008 | API-040 | User, audit | SuperAdmin | TEST-038: step-up lockout after repeated bad codes |
| SCR-032 Security | Save limits | WF-008 | API-043 | Security settings, audit | SuperAdmin | TEST-040: out-of-range values are refused |
| SCR-033 Company onboarding | Submit for review | WF-012 | API-051 | Company, audit | Recruiter, Admin | TEST-048: an unreviewed company cannot publish |
| SCR-034 Assessment attempt | Submit attempt | WF-003 | API-052 | Attempt, result | Member | TEST-049: autosave, resume and attempt limits hold |
| SCR-044 Hide from companies | Add company | WF-013 | API-053 | Blocked company | Member (own) | TEST-046: a hidden company never sees the profile |


### 8.1 Added traceability targets

| Screen / workflow | Action | Capability | Data | Acceptance target |
| --- | --- | --- | --- | --- |
| SCR-047 / WF-014 | Change feed view, follow/mute/save topic | API-054 | Feed preference, follow, bookmark, content | TEST-052 |
| SCR-048 / WF-014 | Save/publish structured post | API-055 | Content, tags, attachment, revision | TEST-053, TEST-054 |
| SCR-049 / WF-014 | Search and open related knowledge | API-056 | Search query, taxonomy link, result | TEST-055 |
| SCR-050 / WF-015 | Join/leave group | API-057 | Group, membership, moderation event | TEST-056 |
| SCR-051 / WF-015 | RSVP/cancel/check in | API-058 | Event, RSVP, attendance | TEST-057 |
| SCR-052 | View/edit contribution visibility | API-059 | Contribution, visibility rule | TEST-058 |
| SCR-053 / WF-016 | Configure/run/review verification mode | API-060 | Verification policy, evaluation, decision, appeal, audit | TEST-059 to TEST-061 |

### 8.2 Resources and identity traceability targets

| Screen / workflow | Action | Capability | Data | Permission | Acceptance target |
|---|---|---|---|---|---|
| SCR-054 / WF-017 | Search, filter, open resource | API-061 | Resource, tags, search event | Member, visibility filtered | TEST-065 |
| SCR-055 / WF-017 | Preview, download/open, save, report | API-061, API-064 | Resource version, access event, bookmark | Member; published/allowed only | TEST-066 |
| SCR-056 / WF-017 | Upload/link/article, submit | API-062, API-063 | Resource, revision, attachment, rights | Member/Contributor | TEST-067, TEST-068 |
| SCR-057 / WF-017 | Save, collection, reading progress | API-064 | Saved resource, collection, progress | Member (own) | TEST-069 |
| SCR-058 / WF-017 | Review/publish/request changes | API-065 | Review, version, audit event | Moderator/Admin | TEST-070 |
| SCR-003 / WF-018 | Register, verify, provider sign-in | API-001, API-002, API-068 | User, consent, provider identity | Public/own account | TEST-071 |
| SCR-059 / WF-018 | Save onboarding role/interests/goals | API-066 | Onboarding preference | Member (own) | TEST-072 |
| SCR-012 / SCR-060 / WF-019 | Edit profile and preview audiences | API-005, API-067 | Profile, field visibility | Member (own); preview is policy scoped | TEST-073 |
| SCR-061 / WF-019 | Update account, notifications, privacy and security | API-005, API-009, API-038, API-039, API-040 | Account preference, session, data request, consent | Own account; step-up for sensitive actions | TEST-074, TEST-075, TEST-076 |
| SCR-063 / WF-019 | Link/unlink connected identity providers | API-068 | Connected identity, provider consent and link history | Own account; step-up when needed | TEST-075 |
| SCR-038 / WF-019 | Export or request erasure | API-009 | Data request, consent | Member (own) | TEST-076 |

### 8.3 Media and nested workflow traceability targets

| Screen / workflow | Action | Capability | Data | Permission | Acceptance target |
|---|---|---|---|---|---|
| SCR-064 / WF-021 | Open/play recording, read transcript/chapters, resume and optionally view waveform | API-069, API-070, API-075, API-077 | Media asset, playback progress, captions/transcript, waveform peaks | Parent resource/course access; member-scoped progress | TEST-077, TEST-083, TEST-084 |
| SCR-065 / WF-022 | Preview supported file or use safe fallback | API-074 | Media asset, source file and derived preview | Source file permissions preserved | TEST-080 |
| SCR-066 / WF-022 | Create upload, pause/resume/retry/cancel and process | API-072, API-073 | Upload session, processing job, media asset | Uploader/reviewer; private signed access | TEST-079 |
| SCR-067 / WF-021 | Resolve and inspect approved provider embed/source | API-071, API-075 | External media source, provider status, captions | Parent resource and provider policy | TEST-078 |
| WF-020, WF-023 | Resolve nested child state and restore parent context | API-076 | Parent/child route state | Server-side route permission | TEST-081 |

## 9. Media, embedded files and parent-child screen behaviour

### SCR-064 — Recording / Media Viewer

**Layout:** Parent resource header and breadcrumbs; primary player; optional transcript/chapter side panel; below/adjacent metadata, captions, notes, discussion and related resources. Audio-only assets may show an optional waveform timeline and region markers. On narrow screens the player remains the primary content and chapters/transcript become tabs or bottom sheets.

**Controls/states:** play/pause, seek, volume, speed, quality where available, captions, transcript, chapters, fullscreen, PiP where supported, source/provider, resume, playback error, network recovery, restricted access, unavailable provider and unsupported codec. Audio waveform, regions and timestamp markers are optional enhancements and should fail back gracefully to familiar audio controls. Keyboard controls and visible focus are essential. No autoplay with sound.

**Recording cards:** show title, thumbnail, duration, source label, caption/transcript indicators, progress and last-viewed state. Keep decorative patterns outside text and control surfaces.

### SCR-065 — Embedded File Preview

Choose a viewer by validated file type: PDF viewer; optimized image viewer; audio/video player; syntax-highlighted text/code/Markdown; virtualized CSV/table preview; supported Office preview via isolated conversion or approved editor. For unknown, unsupported or blocked formats show a clear explanation, safe download when authorised, and report/retry path. Never render raw HTML or macros.

### SCR-066 — Upload Manager / Processing Detail

Support multi-file selection, drag/drop, per-file queue, aggregate progress, pause/resume/retry/cancel, remove/replace, network interruption, duplicate warning, size/type errors, scanning, thumbnail generation, transcoding, moderation and publication. Use real server progress/status. If a prototype uses mock media processing, label it visibly as a prototype state.

### SCR-067 — Media Embed and Source Details

Show original source/provider, resource owner, licence/attribution, embed provider, caption/transcript availability, provider playback status and a report-broken-source control. Provider errors should not break the parent resource page.

### Nested-screen composition guidance

- **Parent page:** establishes section context, filters, selected record and primary task.
- **Child route:** use for substantial workflows, deep links, browser history and pages with their own meaningful state.
- **Contextual drawer/sheet:** use for quick inspection, editing a small set of fields or reviewing details without losing the parent workspace. A route-backed drawer may be used when the detail must be shareable.
- **Inline expansion:** use for small supplementary detail, not large forms or complex media readers.
- **Mobile:** convert complex child panes into full-screen routes or clearly titled sheets with a visible back/close action.
- **State restoration:** keep search, filters, sort, selected parent record and scroll position where feasible. Restore keyboard focus to the invoking control.
- **Avoid:** modal-on-modal, hidden hierarchy, changing the parent background as a navigation cue, and controls that open a child surface without announcing its title.

## 9. Revision history

| Date | Version | Change |
| --- | --- | --- |
| 26 Nov 2026 | 3.6 | Clarified nested parent-child workflows, adaptable child-surface patterns, media-resolver and embed states; aligned screen IDs with owner-supplied reference assets and review-build flow |
| 26 Nov 2026 | 3.5 | Expanded media and nested-resource UX; confirmed API mapping separation (Resources/Identity 061–068; media 069–077); added optional WaveSurfer audio waveform |
| 26 Nov 2026 | 3.4 | Corrected Resource/Identity API traceability and added media/nested traceability targets for APIs 069–077, including optional WaveSurfer waveform details |
| 26 Nov 2026 | 3.3 | Added optional WaveSurfer audio waveform interaction and accessible seeking/fallback behaviour |
| 26 Nov 2026 | 3.2 | Added SCR-064 to SCR-067 for media, previews and uploads; WF-020 to WF-023 for nested navigation, playback and upload lifecycle |
| 25 Nov 2026 | 3.1 | Added Resources screens SCR-054 to SCR-058, onboarding SCR-059, visibility preview SCR-060, Account Control Centre SCR-061 to SCR-063; expanded signup/profile flows |
| 24 Nov 2026 | 3.0 | Added Editorial/Analytical workspace mapping, Matte Black dashboard reference, Community IA and automated verification experiment flow |

## 10. Related documents
