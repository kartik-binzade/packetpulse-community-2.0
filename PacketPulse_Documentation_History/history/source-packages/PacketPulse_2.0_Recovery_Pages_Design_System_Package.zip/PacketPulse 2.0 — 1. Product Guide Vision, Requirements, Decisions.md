# PacketPulse 2.0 — 1. Product Guide: Vision, Requirements and Decisions

Version 4.2 · 21 November 2026 · Owner: product lead (to be named) · Replaces Document A (Master Product, v3.0) and Document F (Decisions, Risks, Change Log, v1.1) · Part of a four-document set: 1 Product Guide, 2 Design System and UX Guide, 3 Users, Screens and Page Flows, 4 Delivery Plan and Developer Handoff.

## 0. How to read this document

| Mark | Meaning |
| --- | --- |
| Confirmed | The owner agreed this, whether built or not |
| Planned | Approved and scheduled |
| Proposed | Recommended, awaiting approval |
| Open | An unresolved question or missing rule |
| PV | Built and tested in the reference prototype only (a single-file demo), not in production |
| **\[REVIEW\]** | A recommendation based on common industry practice. It is written so the owner can approve, change or reject it. Nothing marked \[REVIEW\] is a decision until section 9 changes its status to Confirmed |

IDs used across the set: PRD (requirement), DES (design rule), WF (workflow), SCR (screen), DB (data), API (service capability), TASK, TEST, DEC (decision), CON (contradiction), OPEN (open question), RISK. All four documents use the same IDs, so a requirement can be traced from here to its screen (Document 3), its design rules (Document 2) and its tasks and tests (Document 4).

The production codebase was not available when this set was written. Nothing here says a feature exists in production; the repository audit in Document 4 settles that.

## 1. What changed in this revision

| Change | Detail |
| --- | --- |
| Existing stack is fixed | Next.js for frontend and backend, a backend service that already exists, PostgreSQL (Supabase), Redis, hosted on Vercel and Render. No technology is replaced now (DEC-021 to DEC-023, DEC-032). A developer and an AI coding agent will handle code and versions in another workspace, so this set no longer carries code-level detail |
| Four documents instead of six | Product Guide (old A and F), Design System and UX Guide (old B), Users, Screens and Page Flows (old C), Delivery Plan and Developer Handoff (old D and E). Nothing valid was dropped; technical detail was reduced to what a developer needs to build the planned features |
| Questions now have answers | Every open question has a best-practice recommendation marked \[REVIEW\], with the reason, so the owner reviews instead of researching (section 10) |
| Focus on design, features and flows | More space for who the users are, what each screen does, how pages connect, and what the user sees when things go wrong |
| New proposals | Five requirements added from common practice in job and learning platforms (PRD-050 to PRD-054), all marked \[REVIEW\] |

## 2. Product identity

### 2.1 Mission, vision and tagline

PacketPulse is an engineering community and career platform. It connects learning, hands-on practice, verified skills, professional identity and opportunity in one product (DEC-001, DEC-002).

- **Mission:** help network, security and cloud engineers learn, prove what they can do, and be trusted for it.
- **Vision:** the place where an engineer's capability is visible, believable and connected to work, with a community that keeps people growing after they are hired.
- **Tagline, Connect, Learn & Grow Together:** Connect is the community and the bridge to employers; Learn and Practice are courses and labs; Grow is continued contribution, mentoring and new skills. Prove and Verify sit between them and make the connection credible.

### 2.2 Value proposition

| For | Value |
| --- | --- |
| Engineers | A credible, evidence-backed profile built through real practice, instead of a resume nobody can check |
| Recruiters | Pre-screened candidates with visible evidence through a trusted bridge, instead of a pile of resumes |
| The community | A technical Q&A culture that rewards usefulness over volume |
| Operations team | One place to review, moderate and audit, with every decision recorded |

What is different: skills carry visible evidence, practice is troubleshooting and not only multiple choice, and recruitment runs through PacketPulse's human review.

### 2.3 Users

About 2,000 members, 8 admins and 1 SuperAdmin today (reported by the owner, not checked against production data).

| User | Who | Main goals | Main frustrations (hypotheses to test) |
| --- | --- | --- | --- |
| Fresher member | Student or recent graduate in networking or security | Learn, practice, get a first role | Cannot show proof; unsure what to learn next |
| Experienced engineer | Working engineer, 2 or more years | Grow, change roles, be found | Resumes do not show depth; interviews repeat basics |
| Mentor or expert | Senior engineer | Share knowledge, build reputation | No structured way to help |
| Instructor | Trainer or content owner | Publish and review courses and labs | Manual review, scattered content |
| Recruiter or HR | Company hiring manager or agency | Find qualified candidates fast | Too many unfiltered resumes |
| Admin | Operations team member | Moderate, review, support | Manual queues, no audit trail |
| SuperAdmin | Platform owner | Control services, access and policy | No single control plane |

### 2.4 Product principles

1. **Every feature serves the loop:** Learn, Practice, Prove, Verify, Connect, Get hired, Grow (DEC-001). If it does not, it waits.
2. **Evidence over claims.** No verified label without an evidence record (PRD-012).
3. **People decide, systems assist.** Automation drafts and suggests; humans decide anything that affects a person's opportunity or money (DEC-019).
4. **Trust by design.** Say what is shared, with whom and why, before asking for consent.
5. **One platform.** One account, one skill model, one set of components (DEC-002).
6. **Accessible and calm.** Plain language, visible next steps, no manipulation.

### 2.5 Role of the community

Community is the reason people return when they are not job hunting. Questions, production-issue discussions and mentoring create reputation and content. Learning, labs and assessments turn participation into evidence. Recruitment turns evidence into opportunity. Jobs bring people in; community and growth keep them.

## 3. Goals, non-goals and measures

### 3.1 Goals (targets are starting points to calibrate after a baseline) **\[REVIEW\]**

| Goal | Leading indicator | Lagging indicator | Starting target |
| --- | --- | --- | --- |
| Members reach a useful profile quickly | Email verified to required details complete | Profile-ready within 7 days | 60% |
| Skills become believable | Evidence submitted per active member | Members with at least one verified skill, 90 days after Release 2 | 30% |
| Recruitment is fast and fair | Time to first status update after forwarding | Application to first recruiter decision | 10 working days or less |
| Community answers questions | Questions answered within 48 hours | Accepted-answer rate | 60% answered, 40% accepted |
| Trust holds | Consent records complete | Data shared outside consent | Zero |
| Members come back | 7-day return after first action | 30-day return rate | Baseline first, then set |

### 3.2 Non-goals for the first releases

| Not now | Why |
| --- | --- |
| Real lab environments with a runtime | High cost and security risk (RISK-11); labs use written scenarios first |
| AI that decides about people | Conflicts with DEC-019 |
| Native mobile apps | The web product must work well on phones first |
| Video interviewing and calendar integrations | Start with scheduling details and reminders |
| Third-party course marketplace | Quality and rights are unresolved |
| Candidate-paid fees before joining | Fees only follow a successful joining (DEC-016) |
| Public member profiles on the open web | Privacy first (PRD-052) |

## 4. Strategy and growth

No research, analytics or support data were in the project materials, so each row is a hypothesis to test.

| Stage | Approach | Hypothesis to validate | Measure |
| --- | --- | --- | --- |
| Acquisition | Public site, community content, fees page, referrals through members | Technical content attracts engineers more than job listings | Visitors to registrations by source |
| Registration and onboarding | Email code, progressive profile, resume-assisted entry | Resume parsing cuts profile time | Code completion, time to profile-ready |
| Profile completion | Separate completeness and recruiter readiness | A visible checklist raises completion | Completion at day 7 |
| First meaningful action | Ask or answer a question, start a lab, or enroll | One quick win in 10 minutes predicts retention | Share of new members with a first action |
| Participation | Q&A modes, mentoring, reputation | Accepted answers matter more than volume | Answers per question, acceptance rate |
| Learning | Courses, labs, career paths | Paths beat a flat catalog | Course start and completion |
| Proof | Assessments, evidence review, badges | Verified skills raise recruiter response | Verified-skill rate, recruiter response |
| Careers | Jobs, applications, human review, offers | A reviewed shortlist beats open applications | Apply to interview to offer |
| Retention and reactivation | Notifications by preference; expiring badges as a reason to return | Renewal prompts bring members back | 30-day return rate |
| Referrals | Not yet designed | Satisfied members refer peers | Referral sign-ups (OPEN-17) |
| Trust and moderation | Moderation queue, audit, visible rules | Visible rules reduce abuse | Reports resolved, time to resolve |
| Monetization | Paid advanced courses and live labs; placement fee | Members accept fees shown up front | Conversion, refunds, complaints |

Measurement events: USER\_REGISTERED, EMAIL\_VERIFIED, PROFILE\_COMPLETED, RESUME\_UPLOADED, COURSE\_COMPLETED, LAB\_SUBMITTED, ASSESSMENT\_PASSED, BADGE\_EARNED, JOB\_APPLIED, APPLICATION\_SHORTLISTED, INTERVIEW\_SCHEDULED, OFFER\_RECEIVED, PAYMENT\_COMPLETED. Events carry no personal data such as names, emails or resume text.

## 5. Module inventory

| ID | Module | Purpose | Main users | Depends on | Prototype | Release |
| --- | --- | --- | --- | --- | --- | --- |
| M-01 | Brand site and fees page | Explain the product; publish fees plainly | Visitors | none | PV | 1 |
| M-02 | Identity and onboarding | Register, verify, collect required details, consent | Members | none | PV | 1 |
| M-03 | Profiles | Reusable identity, resumes, completeness, visibility preview | Members, recruiters | M-02, M-04 | PV | 1 |
| M-04 | Skill taxonomy | Standard Major, Minor, Micro skills with automatic suggestions | All | none | PV | 1 |
| M-05 | Community | Q&A, mentoring, reputation, moderation | Members, mentors, admins | M-02 | PV | 1 |
| M-06 | Notifications | In-app, email, WhatsApp opt-in, preferences, delivery log | All | M-02 | PV (in-app only) | 1 |
| M-07 | Learn | Courses, live sessions, career paths, progress, badges | Members, instructors | M-02, M-04 | PV | 2 |
| M-08 | Practice | Labs, submissions, rubric review | Members, instructors, mentors | M-07 | PV (no runtime) | 2 |
| M-09 | Assessments | Attempts, results | Members | M-04 | PV (limited) | 2 |
| M-10 | Verification | Evidence submission, review, appeals, expiry | Members, admins | M-04, M-09 | PV | 2 |
| M-11 | Jobs and recruitment | Positions, applications, screening, forwarding, interviews, offers | Members, recruiters, admins | M-03, M-10 | PV | 3 |
| M-12 | Payments and billing | Paid services, placement fee invoices, refunds | Members, admins | M-07, M-11 | PV (sandbox) | 3 |
| M-13 | Operations | Queues, moderation, feature controls, audit, analytics | Admins, SuperAdmin | all | PV | 1 to 3 |
| M-14 | Security and policies | Roles, permissions, visibility, AI policy, admin security | SuperAdmin | M-13 | PV | 1 |
| M-15 | Integrations and automation | ClickUp, n8n, calendar, AI-assisted drafting | Operations | M-11 | Not built | 4 |

## 6. Requirements and business rules

Each requirement can be tested. Numbers marked Proposed are best-practice defaults that the owner can change **\[REVIEW\]**.

### 6.1 Identity, onboarding and profiles

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-001 | A new member registers with email and a password or passkey and verifies the email with a 6-digit code. The code expires (10 minutes), allows limited attempts (5) and limited resends; the member can change the email | Confirmed (code), Proposed (limits) |
| PRD-002 | The member chooses Fresher or Experienced; this decides which fields are required | Confirmed |
| PRD-003 | Required for everyone: name, date of birth, years of experience, domain or industry, current or target role, at least one skill, LinkedIn profile, verified email, WhatsApp number. Experienced members also give current company, current CTC and notice period. Applying is blocked until these are complete, and the screen lists what is missing | Confirmed (DEC-018) |
| PRD-004 | Members must be 18 or older; profiles for under-18s are not created | Proposed (OPEN-20) |
| PRD-005 | LinkedIn must match linkedin.com/in/name; a link is not proof of skill or experience | Confirmed |
| PRD-006 | WhatsApp number is a valid 10-digit Indian mobile number (international formats later) | Proposed |
| PRD-007 | Resume upload accepts PDF, DOC and DOCX up to 5 MB; extracted values are shown for review; nothing is saved until confirmed; a parsing failure never blocks manual entry | Confirmed, PV |
| PRD-008 | Profile completeness and recruiter readiness are shown separately; readiness is never a hiring guarantee | Confirmed, PV |
| PRD-009 | Compensation fields are private by default and shared only under DEC-015 | Confirmed |
| PRD-010 | Consent is recorded with a timestamp for terms, resume sharing, recruitment sharing, alerts and visibility; withdrawing is as easy as giving | Confirmed |

### 6.2 Skills, verification and assessments

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-011 | Skills come from the taxonomy; unknown skills enter a suggestion queue; Admins add, merge or reject; clear matches with enough sightings (default 10) merge automatically | Confirmed (DEC-014), PV |
| PRD-012 | Labels: Self declared, Assessment verified, Experience verified, Certification verified, PP verified. A verified label exists only when an evidence record exists. Self declared is never styled as verified | Confirmed |
| PRD-013 | Certification evidence needs name, issuer and credential ID (optional link and expiry); experience evidence needs company, role, start month and a description of at least 20 characters (optional referee shown to reviewers only); an optional file is a PDF or image up to 5 MB; the member confirms accuracy | Confirmed, PV |
| PRD-014 | Only an Admin or SuperAdmin decides. Approval needs two checks ticked; asking for more evidence or rejecting needs a reason of at least 10 characters; the decision records who, when and which policy version | Confirmed (DEC-012), PV |
| PRD-015 | After a rejection the member can appeal once with a reason; an approved item can be revoked with a reason; an approval past its expiry becomes Expired and the label reverts | PV, Proposed |
| PRD-016 | Badge lifecycle: Earned, Displayed, Expiring (within 60 days), then Expired or Revoked, then Renewable | Proposed |
| PRD-017 | Each assessment defines category, level, version, attempts, pass criteria, retake gap, expiry and visibility (values in section 10, OPEN-05) | Confirmed (fields), Open (values) |
| PRD-018 | A result records score, level, attempt, date, version and verification outcome; a pass does not create a verified label without an evidence record | Confirmed |

### 6.3 Learning, practice and content

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-019 | Shared learning states: Available, Enrolled, In progress, Completed, with Upcoming, Locked, Paused, Expired | Confirmed |
| PRD-020 | A lab submission has root cause, evidence, fix and optional prevention. A reviewer scores four areas from 0 to 4 and writes feedback of at least 10 characters. A pass needs every area at 2 or more and an average of 2.5 or more. A member has 3 attempts; a third Needs revision is final | PV, Proposed (numbers) |
| PRD-021 | Content records owner, source, created, updated and review dates, status, visibility, topic, skill, difficulty and attribution; resources also need source and usage rights | Confirmed, PV |
| PRD-022 | Content moves Draft, In review, Published, Archived; a reviewer who requests changes gives a reason; unpublishing hides it from learners and keeps the record | PV |
| PRD-023 | Services are Free or Paid as in DEC-017; the price and GST are shown before purchase; some roles are for experienced members only | Confirmed (principle), Open (prices) |

### 6.4 Community

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-024 | Questions have a mode: Learning, Production issue or Expert design. A question needs a title of at least 8 characters, detail of at least 20 characters, and a confirmation that credentials and customer data were removed | Confirmed, PV |
| PRD-025 | Members can answer, vote answers useful, follow a question and report it; the asker accepts one answer; reports go to the moderation queue with a reason | Confirmed, PV |
| PRD-026 | Reputation rewards helpful and accepted answers, not raw activity | Confirmed |
| PRD-027 | A member can request a mentor with a topic and a goal of at least 20 characters; a mentor accepts or declines, and a decline needs a reason shown to the member | PV, Proposed |
| PRD-028 | Moderators dismiss or remove reported posts; every action is audited; the written policy and appeals path are in section 10 (OPEN-14) | PV, Open |
| PRD-054 | A member accepts the community guidelines before the first post; the guidelines are one click away from every post form | Proposed **\[REVIEW\]** |

### 6.5 Jobs and recruitment

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-029 | Application states: Received, Processing, Under review, Shortlisted, Ready to forward, Forwarded, Interview, Selected, Joined, plus Rejected, Withdrawn, Job closed. History is never erased | Confirmed |
| PRD-030 | Automation can recommend; an authorized person confirms shortlisting and forwarding; reviewer, time and notes are logged | Confirmed |
| PRD-031 | A position moves Draft, In review, Published, Paused, Closed (Fulfilled or Unfulfilled) and can be reopened. Reopening needs a future deadline and more openings than were filled. Each position keeps vacancies filled, dates and a hiring history | PV, Proposed |
| PRD-032 | Company recruiters see only candidates forwarded to their jobs, and only the fields allowed by DEC-015; date of birth is never shown to companies; every resume open is logged | Confirmed |
| PRD-033 | A recruiter review records a decision (Under review, Shortlisted, On hold, Rejected), a scorecard of four areas from 1 to 5, an interview recommendation and a next step. On hold and Rejected need a reason of at least 10 characters; On hold needs a future revisit date | PV, Proposed |
| PRD-034 | An interview records round, format, a named interviewer and a future time in IST; the candidate is notified and gets a reminder | PV |
| PRD-035 | An offer records CTC, a future joining date and a validity date before joining. The candidate accepts, or declines with a reason; a declined offer lowers the filled count | PV |
| PRD-036 | Roles marked experienced-only block freshers with an explanation | Confirmed (DEC-017), PV |
| PRD-050 | A member can hide their profile from named companies (for example a current employer). A hidden company never sees the profile in search or in forwarded lists | Proposed **\[REVIEW\]** |
| PRD-051 | After forwarding, a recruiter is reminded when a candidate has had no status update for 10 working days; the candidate sees the last update date and a plain note that no update has been made yet | Proposed **\[REVIEW\]** |
| PRD-052 | Profiles are visible only to PacketPulse staff and, after forwarding, to the recruiter. No public web profile and no search-engine indexing at launch; a public profile is a later opt-in decision | Proposed **\[REVIEW\]** |
| PRD-053 | Every candidate always sees a status for each application. A rejection shows a reason only when the recruiter chose to share one; the candidate can ask PacketPulse for general feedback | Proposed **\[REVIEW\]** |

### 6.6 Fees, payments and billing

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-037 | The placement fee applies only to roles that carry it and is shown on the role and on the public fees page. When applying, the candidate ticks a declaration and gives explicit permission; accepting an offer shows the exact amount and needs a second confirmation | Confirmed (DEC-016), PV |
| PRD-038 | The fee is a percentage of the annual offer (default 1%, configurable from 0.1% to 5%). The invoice is created only after the candidate joins and is due in 15 days; a declined offer or a withdrawn application owes nothing | Confirmed (default), Proposed (timing) |
| PRD-039 | Refunds need a reason; a refund requested by an Admin needs a SuperAdmin's approval | PV, Confirmed by delegation |
| PRD-040 | Payments use a provider-hosted checkout; no card data is stored; provider confirmations are verified and processed once | Proposed |

### 6.7 Notifications, privacy, security and AI

| ID | Requirement | Status |
| --- | --- | --- |
| PRD-041 | A central notification service sends in-app messages, email and (opt-in) WhatsApp, respects preferences and quiet hours, logs delivery, and lets critical events (interviews, offers, security) through | Confirmed (service), values in section 10 (OPEN-04) |
| PRD-042 | Admin accounts meet DEC-020: required MFA, passkeys preferred, no SMS codes, no temporary passwords, session limits, step-up with reason and fresh code, lockout after repeated failures, break-glass with a second SuperAdmin, periodic access review | Confirmed by delegation |
| PRD-043 | The audit log is append-only and records actor, subject, reason and time for screening, moderation, settings, access, verification, practice, content and recruitment actions | Confirmed |
| PRD-044 | Only a SuperAdmin changes roles, permissions, visibility and AI policy; every change is audited | PV |
| PRD-045 | DPDP: plain notice, specific consent, easy withdrawal, export and erasure, a grievance contact, breach reporting within the required time, and processing agreements with every provider | Planned (DEC-026) |
| PRD-046 | Resumes and certificates are private, reached through short-lived links, and every open is logged | Confirmed |
| PRD-047 | AI follows DEC-019: it drafts and suggests; it has no path to decide or execute the listed actions; outputs are labelled as drafts, show what was uncertain and can be overridden | Confirmed by delegation |
| PRD-048 | English is the default; a Hindi switch is offered; dates and numbers follow the language | Proposed, PV (partial) |
| PRD-049 | The product targets WCAG 2.2 AA in light and dark themes, with keyboard access, visible focus and status never shown by color alone | Confirmed |

## 7. Roles and permissions summary

| Capability | Member | Mentor | Instructor | Recruiter | Admin | SuperAdmin |
| --- | --- | --- | --- | --- | --- | --- |
| Own profile, learning, applications | Yes | Yes | Yes | No | Yes | Yes |
| Review lab submissions | No | Yes | Yes | No | Yes | Yes |
| Author content | No | No | Yes | No | Review and publish | Yes |
| See forwarded candidates | No | No | No | Own company only | Screening view | Screening view |
| Manage positions | No | No | No | Own company | Review and publish | Yes |
| Decide verification | No | No | No | No | Yes | Yes |
| Moderate community | No | No | No | No | Yes | Yes |
| Finance and refunds | No | No | No | No | Request refunds | Approve refunds |
| Users, roles, policies, security | No | No | No | No | Limited | Yes |

Every request is checked on the server for permission (DEC-010). Roles are additive on one account (DEC-009). A review-only Hiring manager role is recommended for company pilots but not built first (OPEN-11).

## 8. Release scope (Proposed)

| Release | Scope | Why this order |
| --- | --- | --- |
| 1 Foundation | Identity, onboarding, profiles, taxonomy, community, notifications, operations, security, privacy | Everything else depends on trusted identity and consent; the 2,000 existing members need a safe move |
| 2 Prove | Learn, practice, assessments, verification | Evidence must exist before recruiters can rely on it |
| 3 Careers | Jobs, recruitment, offers, billing, placement fee | Depends on profiles, evidence and payments |
| 4 Intelligence and ecosystem | AI drafting, integrations, deeper analytics, public API | Valuable only on stable data |

MVP release blockers: consent and erasure basics, server-side permissions on every route, private file handling, the audit log, backups with a tested restore, and a staged rollout with rollback.

## 9. Decision register

The single record of what was decided and what replaced what. When a decision changes, change it here first, then the other documents.

| ID | Decision | Status |
| --- | --- | --- |
| DEC-001 | Tagline Connect, Learn & Grow Together; the loop Learn, Practice, Prove, Verify, Connect, Get Hired, Grow is the test for every feature | Confirmed |
| DEC-002 | One platform: one account, one skill model, one permission model, shared components | Confirmed |
| DEC-003 | Visual direction Signal Grove: light-first, dark as a designed alternative (replaces Network Console, Moodboard v2 and Card System v1) | Confirmed |
| DEC-004 | Inter for UI, JetBrains Mono for technical text, Noto Sans Devanagari as the Hindi fallback | Confirmed |
| DEC-005 | Module accents: Community forest, Learning indigo, Recruitment blue, Payments plum | Confirmed (blue by owner; plum by delegation) |
| DEC-006 | Information state is slate; Experience verified label uses recruitment blue | Confirmed by delegation |
| DEC-007 | Status is shown with text and a glyph, never color alone | Confirmed |
| DEC-008 | Breakpoints 640, 768, 1024, 1280, 1536 px | Confirmed |
| DEC-009 | Roles are additive on one account: Member, Mentor, Instructor, Recruiter, Admin, SuperAdmin | Confirmed |
| DEC-010 | Permissions are enforced on the server for every route, field and action; hidden screens are not security | Confirmed |
| DEC-011 | Candidate profile, job and application are separate records; job-specific status lives on the application | Confirmed |
| DEC-012 | Verification approvers: Admin or SuperAdmin | Confirmed |
| DEC-013 | Evidence model with five labels plus Pending; each decision records who, when, policy version, expiry; one appeal; revocation and expiry | Confirmed (labels), PV (appeal, revoke, expiry) |
| DEC-014 | Skill taxonomy Major, Minor, Micro owned by Admins; new skills arrive as suggestions; clear matches merge automatically | Confirmed |
| DEC-015 | Visibility: PacketPulse screening team sees the full profile before forwarding; company recruiters see the allowed fields after forwarding; date of birth stays hidden; SuperAdmin can adjust after-forwarding fields | Confirmed (principle), PV (table) |
| DEC-016 | Placement fee: candidate-paid, default 1% of annual offer, declaration and permission when applying and again when accepting, shown publicly | Confirmed (principle); safeguards in 10.5 **\[REVIEW\]** |
| DEC-017 | Free versus paid: advanced courses, live lab sessions and some placements are paid; some roles are experienced-only | Confirmed (principle); prices Open |
| DEC-018 | Required onboarding fields as in PRD-003 | Confirmed |
| DEC-019 | AI drafts and suggests; people decide. AI has no path to shortlist, reject, forward, verify, change roles or passwords, refund, change fees or prices, suspend or delete | Confirmed by delegation |
| DEC-020 | Admin security baseline: required MFA, passkeys preferred, no SMS, no temporary passwords for admins, session limits, step-up, lockout, second approval for Admin refunds, break-glass, access reviews | Confirmed by delegation |
| DEC-021 | Existing stack: Next.js for frontend and backend, an existing backend service, PostgreSQL (Supabase), Redis, hosted on Vercel and Render | Confirmed |
| DEC-022 | The system of record is PostgreSQL through Supabase | Confirmed |
| DEC-023 | No technology is replaced without a concrete requirement and owner approval | Confirmed |
| DEC-024 | New work is organised as modules with clear ownership inside the existing backend | Proposed |
| DEC-025 | The earlier proposals for a new authentication library, a new data-access library, a new job queue and a cloud move are withdrawn as defaults | Deprecated |
| DEC-026 | DPDP Act and Rules 2025 duties are product requirements; main duties apply from about 14 May 2027 | Planned |
| DEC-027 | The earlier six-document suite and ID scheme are kept as IDs | Confirmed |
| DEC-028 | English and Hindi language switch | Proposed (PV for navigation, titles, home) |
| DEC-029 | Sandbox checkout first; provider chosen later | Proposed |
| DEC-030 | ClickUp and n8n are an operations aid; the application database stays the source of truth | Planned; live status unknown |
| DEC-031 | Core application color guidance: neutral foundations, clear accents and semantic status colors, both themes, adequate contrast, and icons plus labels with color; page-specific systems may extend this baseline under DEC-035 | Confirmed; evolution permitted by DEC-035 |
| DEC-032 | Frontend and backend are both Next.js; the database is PostgreSQL; the stack stays as it is | Confirmed (owner, 17 Oct) |
| DEC-033 | The documentation set is four documents; this set covers design, features, UX and flows, while code and versions are handled by a developer and an AI coding agent in another workspace | Confirmed (owner, 17 Oct) |
| DEC-034 | Open questions get a best-practice recommendation marked \[REVIEW\] and stay Open until the owner approves | Confirmed (owner, 17 Oct) |
| DEC-035 | Creative design exploration may extend or replace existing colors, tokens, components, illustration styles and motion patterns whenever validated UX improves; selected production decisions are centralized and recorded | Confirmed by owner, 21 Nov 2026 |
| DEC-036 | System recovery pages use a human-centered Network Adventure direction grounded in network engineering, topology and operations life; the five-state family follows Document 2 section 15 | Working direction; final palette and artwork await owner approval |

### 9.1 Contradictions resolved

| ID | Conflict | Resolution |
| --- | --- | --- |
| CON-01, CON-13 | Dark-first Network Console versus light-first Signal Grove | Signal Grove (DEC-003) |
| CON-02 | Moodboard v2 and Card System v1 versus Signal Grove tokens | Signal Grove; old files are reference only |
| CON-03 | Instrument Sans, Neue Montreal, Therilo, Goodly versus Inter | Inter in the product; logotype open (OPEN-02) |
| CON-04 | Jobs orange and Payments teal versus recruitment blue and Payments plum | Latest decisions apply (DEC-005) |
| CON-05 | Information indigo equals Learning indigo | Slate for Information (DEC-006) |
| CON-06 | Forest versus blue primary actions; teal progress | Open (OPEN-01), recommendation in section 10 |
| CON-07 | Placement fee not to be hard-coded versus approved at about 1% | Owner decision applies; keep it configurable and under legal review |
| CON-08 | PP Verified and Assessment Verified overlap | Open (OPEN-03), definitions in 10.1 |
| CON-09 | Mandatory onboarding fields differ between documents | Owner's list (DEC-018) |
| CON-10 | MongoDB versus Supabase PostgreSQL | PostgreSQL (DEC-022) |
| CON-11 | New stack components proposed versus the stack that exists | Keep the stack (DEC-023, DEC-025) |
| CON-12 | Names: Education, Learning, Learn; HRMS, Operations, Recruitment | Community, Learn, Practice, Assessments, Verification, Jobs (member), Recruitment (recruiter), Operations (admin), Payments |
| CON-14 | Earlier checklist treats Terminal Green, Packet Cyan and Infrastructure Amber as status colors | The semantic table in Document 2 applies |

## 10. Open decisions with recommended answers

How to review: for each row choose Approve, Change or Reject. An approved row becomes a DEC entry and its status changes to Confirmed. Recommendations follow common industry practice and national rules as I understand them; anything legal is marked for counsel to confirm. Sections 10.1 to 10.9 give the detail for the rows that need it.

| ID | Question | Recommended answer **\[REVIEW\]** | Basis | Decider |
| --- | --- | --- | --- | --- |
| OPEN-01 | Primary action color; progress color | Forest green for primary actions; progress uses the active module's accent; blue only for Recruitment | One primary color keeps calls to action unmistakable and the brand recognisable; forest has 7.3:1 contrast with white; teal progress sits about 7 degrees of hue from forest and reads as the same color, especially to color-blind users | Owner, design lead |
| OPEN-02 | Logotype typeface | Use the name in Inter semibold now; commission one logotype later and keep it separate from the UI font | Logotypes are brand assets; supply vector lockups, minimum size, clear space and a favicon | Design lead |
| OPEN-03 | PP Verified versus Assessment Verified | See 10.1 | Digital credential practice shows issuer, criteria, evidence and validity | Product lead |
| OPEN-04 | Notification channels, frequency, quiet hours | See 10.3 | Opt-in channels, separate transactional and marketing messages, critical events exempt | Product lead |
| OPEN-05 | Assessment rules | See 10.2 | Certification programs use limited attempts with waiting periods and expiry | Product lead |
| OPEN-06 | Data retention | See 10.7 | Keep personal data only as long as the purpose needs; legal minimums for tax records | Owner, counsel |
| OPEN-07 | Placement fee legal review and safeguards | See 10.5 | International fair-recruitment guidance says workers should not bear recruitment fees; if kept, charge only after joining with clear terms and a refund window | Owner, counsel |
| OPEN-08 | Payment provider and GST invoicing | Evaluate Razorpay first, with Cashfree as the comparison; hosted checkout; GST-inclusive prices shown | Common providers in India support UPI, cards and netbanking; hosted checkout keeps card data away from PacketPulse | Owner |
| OPEN-09 | Prices | The owner sets them; recommended method in 10.8 | Show the final price including GST before purchase | Owner |
| OPEN-10 | Company onboarding and verification | See 10.6 | Marketplaces verify the employer before the first listing | Product lead |
| OPEN-11 | Hiring-manager role | Add a review-only Hiring manager role after the first company pilots; not in Release 1 | Least privilege | Product lead |
| OPEN-12 | ClickUp and n8n scope | Decide after the audit; mirror IDs and statuses only; no resumes, contact details or compensation in ClickUp; application database stays the source of truth | Keep personal data in one controlled place | Operations lead |
| OPEN-13 | Authentication policy | See 10.9 | Follow current password guidance (length over complexity, no forced rotation, breach checks) and phishing-resistant MFA for staff | Tech lead |
| OPEN-14 | Moderation policy and appeals | See 10.4 | Clear rules, graded actions, a fast response and an appeal by a different person | Community lead |
| OPEN-15 | Which routes and screens exist today | A developer task, not a product decision (Document 4, TASK-001) | Documentation is not proof of a feature | Tech lead |
| OPEN-16 | Analytics provider and events | Keep the current tool; adopt the events in section 4; no personal data in events; ask consent for non-essential tracking | Privacy by design | Product lead |
| OPEN-17 | Referral and reactivation programs | Do not build before launch; test later with rewards after a referred member completes a real action, with caps | Avoids rewarding fake sign-ups | Product lead |
| OPEN-18 | Sender identity and WhatsApp provider | Use a dedicated sending domain with email authentication; keep transactional and marketing streams apart; set up a WhatsApp Business account with approved templates now because approvals take time | Deliverability and consent | Operations lead |
| OPEN-19 | Profile visibility default and public profiles | Private by default; visible to staff and, after forwarding, to the recruiter; no public profile or search-engine indexing at launch (PRD-052) | Privacy first; members can opt in later | Owner |
| OPEN-20 | Minimum age | 18 or older at registration, checked from date of birth (PRD-004) | Processing a child's data needs verifiable parental consent under DPDP; an adult-only rule is the simplest safe default; counsel to confirm | Owner, counsel |
| OPEN-21 | Candidate protections | Adopt PRD-050 (hide from named companies), PRD-051 (response reminders) and PRD-053 (status and feedback) | Job platforms commonly let members block current employers and expect timely updates | Product lead |

### 10.1 Verification labels (OPEN-03) **\[REVIEW\]**

Every badge shows what was checked, who checked it, when, and when it expires. A public page called How verification works lists the criteria.

| Label | Meaning | Evidence needed |
| --- | --- | --- |
| Self declared | The member says they have the skill | None; shown as neutral, never as verified |
| Assessment verified | The member passed a PacketPulse assessment for that skill, within its validity | A passed result |
| Certification verified | PacketPulse checked the credential with its issuer name and credential ID | Certificate details and a reviewer decision |
| Experience verified | PacketPulse reviewed employment or project evidence | Evidence record and a reviewer decision |
| PP verified | A higher standard: at least two different evidence types for the skill, one of them reviewed by a person (for example a passed assessment plus a passed lab review, or an assessment plus verified experience) | Two evidence records and a reviewer decision |

### 10.2 Assessment rules (OPEN-05) **\[REVIEW\]**

| Rule | Recommended default |
| --- | --- |
| Attempts | 3 per assessment in any 90 days |
| Retake gap | 7 days after a failed attempt |
| Pass mark | 70%, adjustable per assessment between 60% and 80% |
| Time limit | Set per assessment and shown before starting |
| Question order | Randomized from a pool at least twice the size of one attempt |
| Result screen | Score, level and weak topics; correct answers are not revealed |
| Validity | 24 months; renewal by retake or newer evidence; a reminder 60 days before expiry |
| Honesty | The member accepts an honesty statement before starting; no outside help |
| Proctoring | None at launch; review the need if recruiters report cheating |
| Accessibility | Extra time on request, approved by an Admin |

### 10.3 Notification policy (OPEN-04) **\[REVIEW\]**

| Topic | Recommended rule |
| --- | --- |
| In-app | Every event |
| Email | Application status, interviews, offers, assessment results, security, billing; community replies as an optional daily or weekly digest |
| WhatsApp | Opt-in only, for interviews and offers, using approved templates |
| Marketing | A separate opt-in with an unsubscribe link in every message |
| Quiet hours | 21:00 to 08:00 IST for non-critical messages |
| Critical events (sent during quiet hours) | Security alerts, an interview within 24 hours, an offer expiring within 48 hours |
| Frequency cap | No more than 3 non-critical messages per member per day |
| Reminders | Interview reminders 24 hours and 1 hour before; badge expiry 60 and 14 days before |
| Privacy | No resume, compensation or private notes in previews or subject lines |

### 10.4 Moderation policy (OPEN-14) **\[REVIEW\]**

**Rules.** Be respectful. Never post passwords, keys, customer data or confidential network configurations. No job spam, solicitation or advertising in questions. Do not copy assessment answers. Credit sources. No harassment, doxxing or discrimination.

| Step | Action |
| --- | --- |
| 1 | Remove the post and tell the author the reason |
| 2 | Warning |
| 3 | Posting limit for 7 days |
| 4 | Posting limit for 30 days |
| 5 | Account suspension (needs two admins to agree) |

| Service level | Target |
| --- | --- |
| Reports acknowledged | Within 24 hours |
| Urgent reports (exposed credentials, harassment) | Within 4 hours |
| Appeals | Reviewed by a different Admin within 5 working days |

Reputation rises with accepted and useful answers and falls with removed posts. Reputation does not unlock sensitive tools at launch.

### 10.5 Placement fee safeguards (OPEN-07) **\[REVIEW\]**

The owner's decision (DEC-016) stands. Fair-recruitment guidance from the International Labour Organization says workers should not carry recruitment fees, so the following safeguards reduce risk if the fee is kept. Counsel confirms them for each region before the fee is switched on.

- Charge only after the candidate joins; never before an offer and never for screening or forwarding.
- Show the exact amount on the role, in the apply step and again when accepting the offer (already in PRD-037).
- Refund window: recommended full refund if employment ends within 30 days of joining and 50% within 90 days.
- The fee never changes screening, ranking or forwarding; staff must not see whether a candidate has agreed to a fee while screening.
- Offer employer-paid roles as the default listing type, and mark candidate-paid roles clearly.
- Cap the percentage (0.1% to 5%, already in PRD-038) and show a worked example on the fees page.
- Provide a dispute route with a reply in 5 working days and issue a GST invoice with every payment.

### 10.6 Company onboarding and verification (OPEN-10) **\[REVIEW\]**

1. The recruiter signs up with a work email; free email domains are held for review.
2. They enter the company name, website, size, contact person, and optionally the company registration or GST number and a LinkedIn company page.
3. An Admin reviews the company profile; the company stays in Pending until approved.
4. The first position is always reviewed before it is published; later positions need review only if flagged.
5. Companies that are rejected or later reported can be suspended; the reason and the reviewer are recorded.
6. Staffing agencies are labelled as agencies and must name the end client on each position.

### 10.7 Data retention (OPEN-06) **\[REVIEW, counsel to confirm\]**

| Data | Suggested keep period |
| --- | --- |
| Account and profile | While the account is active; erased within 30 days of an erasure request unless the law requires a longer record |
| Inactive accounts | Notice after 2 years of inactivity; personal data erased after 3 years (similar to a rule the DPDP Rules apply to some large platforms) |
| Resume copies shared with companies | Company access ends 90 days after the application closes |
| Verification evidence files | Delete files 12 months after the decision unless an appeal or expiry needs them; keep the decision record |
| Consent records | For the life of the account plus 3 years, as proof |
| Audit log | At least 3 years |
| Invoices and payment records | As required by Indian tax and company law (commonly 6 to 8 years); the accountant confirms |
| Community posts | Kept; the author's name is removed on erasure when others depend on the content |
| Notification and delivery logs | 12 months |
| Backups | Erased data leaves backups on the normal rotation and is never restored |

### 10.8 Payments and prices (OPEN-08, OPEN-09) **\[REVIEW\]**

- Use the provider's hosted checkout; confirm a payment from the provider's own notification, not from the browser returning to the site.
- Show prices including GST, then the breakdown on the receipt and invoice.
- Refund policy to publish: full refund within 7 days if less than 10% of a course was used; live sessions refundable up to 48 hours before the start.
- Method to set prices: list every paid item, check what comparable training sells for, start with a small number of paid items, test the price with early members, and change it only with notice. No prices are invented here.

### 10.9 Authentication and admin policy (OPEN-13) **\[REVIEW\]**

| Rule | Recommended default |
| --- | --- |
| Passwords | At least 12 characters, checked against known breached passwords, no complexity rules and no forced rotation; passkeys offered |
| Multi-factor | Required for Admin, SuperAdmin and Recruiter accounts; optional for members; authenticator app or passkey, never SMS |
| Sessions | Members: sign out after 30 days idle; staff: 30 minutes idle and 8 hours absolute |
| Sensitive actions | Ask for a reason and a fresh code (step-up) |
| Lockout | After 5 wrong codes, 15 minutes |
| Recovery | Members by email; staff only through a SuperAdmin with a second approver |
| LinkedIn | Optional sign-in with LinkedIn to prove the profile belongs to the member, using only the fields needed; otherwise syntax check only (PRD-005) |

## 11. Risk register

| ID | Risk | Impact | Likelihood | Mitigation |
| --- | --- | --- | --- | --- |
| RISK-01 | The production system differs from every assumption here | High | High | Repository audit before any build task |
| RISK-02 | DPDP duties (main phase about 14 May 2027) are missed | High | Medium | Consent, export, erasure and breach process in the first releases; counsel review |
| RISK-03 | The candidate-paid fee is restricted in some regions or draws complaints | High | Medium | Safeguards in 10.5; per-region switch; counsel review |
| RISK-04 | Permissions that exist only on screen expose data | High | Unknown | Audit; server checks on every route before new modules |
| RISK-05 | The move disrupts the 2,000 existing members | High | Medium | Additive changes, feature flags, staged rollout, tested rollback |
| RISK-06 | Hosting and database plan limits constrain growth | Medium | Medium | Review plans early; restore drill |
| RISK-07 | AI features add bias or errors to hiring | High | Medium | Draft-only policy; evaluation sets; audit trail |
| RISK-08 | Scope grows faster than the team | High | High | Fixed release order; exit criteria; feature flags |
| RISK-09 | Private documents (resumes, certificates) are exposed | High | Medium | Private storage, short-lived links, access logging, role tests |
| RISK-10 | Accessibility is untested with real assistive technology | Medium | High | Screen-reader and device checks each release |
| RISK-11 | Lab environments are costly or insecure | High | High | Written scenarios first; pilot small; cost caps |
| RISK-12 | Documents drift from the product | Medium | High | Update this decision register first; review documents with every release |

## 12. Change log

| Date | Version | Change |
| --- | --- | --- |
| 9 Oct 2026 | Handover 1.0 | Design and development handover issued |
| 13 to 15 Oct 2026 | Prototype 1.0 to 1.8 | Reference build, palette review, recruitment blue, evidence and lab review, decisions on fees, onboarding, visibility and security |
| 16 Oct 2026 | Suite 1.0 and 1.1 | Six documents A to F created; stack recorded; contradictions logged; developer-level questions added |
| 17 Oct 2026 | Set 4.0 | Four documents replace six; stack fixed (DEC-032); code-level detail removed; every open question has a recommended answer; PRD-050 to PRD-054 and OPEN-19 to OPEN-21 added; the two developer questions about framework version and where authorization runs moved to Document 4 (DEV-01, DEV-02) |
| 21 Nov 2026 | Design evolution 1.0 | Owner authorized creative exploration beyond current tokens and visual conventions when UX improves; Documents 2 to 4 updated for token evolution, richer illustration/motion, and five system recovery states; detailed record maintained in the separate PacketPulse Design Exploration Change Log |
| 21 Nov 2026 | Recovery page system 1.0 | Added DEC-036 and a dedicated Network Adventure visual system for SCR-043, including candidate light/dark tokens, five state recipes, illustration direction, motion, responsive behavior, runtime contracts and QA criteria |

## 13. Related documents

Document 2: Design System and UX Guide. Document 3: Users, Screens and Page Flows. Document 4: Delivery Plan and Developer Handoff.
