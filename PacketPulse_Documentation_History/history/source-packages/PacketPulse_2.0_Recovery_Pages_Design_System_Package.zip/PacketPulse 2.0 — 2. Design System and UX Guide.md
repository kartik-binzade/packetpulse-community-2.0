# PacketPulse 2.0 — 2. Design System and UX Guide

Version 3.2 · 21 November 2026 · Owner: design lead (to be named) · Replaces Document B (Design System, v2.0). Decisions are cited as DEC, CON, OPEN in Document 1; screens and flows are in Document 3; build tasks are in Document 4. **\[REVIEW\]** marks a recommendation based on common practice that the owner can approve, change or reject. PV means built and tested in the reference prototype only.

## 1. Philosophy and UX rules

The design system is a living set of shared foundations, quality guardrails and reusable patterns. It creates consistency without limiting useful invention. Teams may challenge or extend any visual convention, token or component when evidence shows that the change improves clarity, accessibility, usability, trust or task completion. Each rule has an ID so it can be cited in reviews and tests.

| ID | Rule | Consequence |
| --- | --- | --- |
| DES-001 | A polished screen is not a usable flow. Every flow defines its entry, next step, recovery path, and its empty and error states before visual polish | No screen ships without loading, empty, error and success states |
| DES-002 | Principles are reviewable guardrails, not unquestionable visual rules. A better UX may justify changing or extending a convention; record the reason and validate the outcome | Better outcomes without design stagnation |
| DES-003 | Automation is explainable and overridable. AI output is labelled as a draft, shows what it was unsure of, and a person can change or reject it | No unexplained scores; no automatic decisions about people |
| DES-004 | Accessibility is a speed feature. Contrast, keyboard flow and clear labels reduce errors for everyone | WCAG 2.2 AA is the release bar |
| DES-005 | Consistency scales through shared tokens and components. Reuse them by default, but evolve or add them when the experience needs a better solution | Reuse without blocking improvement |
| DES-006 | Light and dark themes are both designed and tested (DEC-003) | Dark is not an inversion of light |
| DES-007 | Color may carry brand, emotion and visual storytelling as well as meaning; functional status always has text and a glyph (DEC-007) | Expressive design without color-only states |
| DES-008 | One primary action per view. Everything else is secondary or tertiary | The next step is obvious |
| DES-009 | Always show where the user is, what changed, and what to do next | No dead ends; every empty state offers an action |
| DES-010 | Plain language, short sentences, no jargon for its own sake | Fewer support questions |
| DES-011 | Ask for information only when it is needed, and say why for sensitive fields | Higher completion, more trust |
| DES-012 | Work is recoverable: save and resume, warn before losing changes, confirm destructive actions by naming their effect | Fewer abandoned flows |
| DES-013 | Recovery pages tell a technically credible, human-centered network story; the correct state, truthful status and next action matter more than preserving an old visual convention | Helpful recovery without disguising the cause |

## 2. Color psychology applied

| UX principle | Implementation | Why it helps | Status |
| --- | --- | --- | --- |
| Reduce cognitive load | Neutral backgrounds, limited accents | Less visual competition | Confirmed |
| Establish hierarchy | One strong primary action per view; muted secondary actions | The next step is obvious | Confirmed |
| Build trust | Consistent branding, explicit transaction states | Predictable behavior | Confirmed |
| Encourage progress | Visible milestones and progress in the active module's accent | Progress is easy to read | Confirmed; the color is OPEN-01 |
| Prevent mistakes | Amber warnings, red errors, descriptive messages | Important states stand out | Confirmed |
| Improve accessibility | Contrast, icons, labels and text with every status | Works for different visual abilities | Confirmed |

**OPEN-01 recommendation \[REVIEW\].** The brief suggests blue primary actions and teal progress. Recommended: keep Brand Forest for primary actions and use the active module's accent for progress, with blue only for Recruitment. Reasons: one primary color keeps calls to action unmistakable and the brand recognisable; forest has 7.3:1 contrast with white; teal sits about 7 degrees of hue from forest green and would read as the same color. Until the owner decides, this document uses forest.

Behind the current module choices: forest green signals trust and growth (community); indigo supports focus (learning); blue signals reliability (recruitment); plum signals value and care (payments); amber means pending; green means success and verified; red means error. Lime is currently used for reward moments. These are the current system choices, not a ban on exploring additional palettes, gradients, tints or visual treatments when they improve the experience.

## 3. Brand

Name: PacketPulse. Tagline: Connect, Learn & Grow Together. Voice: plain, direct, encouraging, technical without jargon for its own sake, never urgent or manipulative. The logotype typeface is undecided (OPEN-02); until then write the name in Inter semibold. The mark is a lime dot with a forest ring (PV).

## 4. Color system

### 4.1 Tokens (light and dark)

| Token | Light | Dark | Use |
| --- | --- | --- | --- |
| Page background | #F5F8F6 | #001D21 | App background |
| Surface | #FFFFFF | #002631 | Cards, forms, dialogs |
| Surface subtle | #E8F4EF | #0C3437 | Selected rows, active navigation, tints |
| Text primary | #152025 | #F5F8F6 | Headings and body |
| Text secondary | #52615B | #B7C9C2 | Supporting text |
| Border | #DCE5DF | #33514F | Dividers and card outlines (decorative) |
| Control border | #738279 | #7D9A95 | Inputs, switches, checkboxes (3:1 required) |
| Brand | #156152 (hover #0F4D41) | #156152 | Primary buttons, links, active navigation |
| Focus ring | #156152 | #96D294 | 3 px outline, 2 px offset |
| Signal lime | #C7FE53 | #C7FE53 | Reward moments and one action on dark surfaces; text on it is #001D21 |
| Deep teal | #001D21, #002631 | same | Dark panels and hero backgrounds |

### 4.2 Module identities

| Module | Light | Dark | Soft background (light, dark) | Role |
| --- | --- | --- | --- | --- |
| Community and brand | #156152 | #96D294 | #E8F4EF, #0C3437 | Welcoming, credible |
| Learning | #635BCA | #B1ACFE | #F0EFFF, #26235A | Focus |
| Recruitment | #1D4F86 (accent #2563A6, deep #163B5C) | #8DB8E8 | #E8F0FA, #12304D | Reliability |
| Payments | #6F2A5F | #E4A8D8 | #F7EBF4, #3A1F36 | Value, care |

Module colors identify function; they do not replace the brand. Never make a whole page one module color. The shell, neutrals and primary buttons stay the same everywhere (DES-005).

### 4.3 Semantic and verification colors

| State | Strong (text) light, dark | Soft background light, dark | Glyph | Meaning |
| --- | --- | --- | --- | --- |
| Success | #176B35, #7FDC98 | #EAF7EE, #0F3A22 | check | Completed, saved, passed, verified |
| Warning or pending | #94620D, #F0C264 | #FFF4D6, #3D3010 | exclamation | Needs attention, in review |
| Danger | #B42332, #FF8A93 | #FEE4E2, #4A1A20 | cross | Failed, invalid, destructive |
| Information | #3D455C, #B4BED6 | #EDF0F5, #252B3A | info | Neutral guidance |

Verification labels: Self declared (neutral), Assessment verified and PP verified (forest), Experience verified (recruitment blue), Certification verified (indigo), Verification pending (amber), unsuccessful (red). Each label has its own wording and a detail view (DEC-013, Document 1 section 10.1).

### 4.4 Quality results

- Every text pair above is at least 4.5:1 (lowest 4.65:1); control borders are 4.04:1 on white and 5.24:1 in dark.
- Under color-blindness simulation two pairs are weak and accepted with a rule: Community green versus Success green, and Community versus Recruitment. Rule: status has text and a glyph; modules also have an icon and a name.
- Plum Payments is clearly distinct from every other module and state color under all four vision types.
- Hero gradients keep text off the pale eucalyptus end (it measured 2.1:1).
- Rule for new colors: two colors that must be told apart need a clear difference under all four vision simulations, or a label or icon with them.

## 5. Typography

| Role | Value |
| --- | --- |
| UI and body | Inter, with Noto Sans Devanagari for Hindi, then system fonts |
| Technical text and numbers | JetBrains Mono, sparingly (counts, IDs, code, ledger values) |
| Body | 16 px / 24 px, weight 400 |
| Small | 14 px / 20 px |
| Section heading | 24 px / 32 px, weight 600 |
| Card heading | 17 px / 24 px, weight 600 |
| Page heading | 30 to 48 px, weight 700, fluid |
| Metric value | JetBrains Mono, 30 px / 36 px, weight 600 |

Use sentence case, tabular numerals for money and counts, and balanced wrapping for headings. Avoid all caps and light weights for small text. Keep reading lines between 60 and 75 characters **\[REVIEW\]**. Hindi text needs a line height of at least 1.6.

## 6. Spacing, shape, elevation and states

| Aspect | Rule |
| --- | --- |
| Spacing | 4 px rhythm: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64 |
| Radius | 6 tags, 10 buttons and inputs, 14 cards and dialogs, 20 feature panels, pill for chips |
| Elevation | Borders first. Shadows only for real layers: overlay shadow 0 14px 40px at 18% deep teal; scrim 55% deep teal |
| Surface levels | Page, surface (card), raised (menu, popover), overlay (dialog, toast) |
| Hover | Subtle tint of the surface or a darker brand shade; never a layout shift |
| Focus | 3 px outline, 2 px offset, always visible; never removed |
| Active or pressed | Darker shade and a 1 px downward nudge |
| Selected | Subtle tint plus a marker (inset bar, check or filled chip), never color alone |
| Disabled | 50% opacity, not focusable, with a reason shown nearby when it blocks a task |

Button shades: primary #156152, hover #0F4D41, pressed #0B3D33; lime hover #B5EE3F, pressed #A8DE33; destructive #B42332, hover #9A1C2A, pressed #85161F.

## 7. Layout, navigation and placement

| Element | Rule | Reason |
| --- | --- | --- |
| Page container | Content up to 1160 px (1320 px at 1536 px and up); padding 16, 24, then 32 to 40 px at 1280 px and up | Readable lines; dashboards can use width, reading pages cannot |
| Grid | 12 columns, spans of 3, 4, 6, 8, 12; one column below 768 px; quarter cards two across below 768 px and one below 640 px | Hierarchy by span, not decoration |
| Breakpoints | 640, 768, 1024, 1280, 1536 | DEC-008 |
| Sidebar | Persistent left navigation 232 px from 1024 px; filtered by role; active item has a marker | Frequent destinations always visible |
| Mobile navigation | Bottom bar below 1024 px, horizontally scrollable, icon above label | Thumb reach |
| Header | Sticky; workspace label, search (Ctrl or Command K), language, theme, notifications, account | Utilities do not compete with content |
| Page header | Icon tile, one H1, short description, at most one primary action on the right | One obvious task per page |
| Breadcrumbs | On pages deeper than two levels (position detail, candidate, thread, review) | Orientation and a quick way back |
| Primary and secondary actions | Primary bottom-right in forms and dialogs, secondary to its left, destructive named by outcome | Matches reading order |
| Footer | Fees, privacy, terms, contact; not repeated inside the app | Trust links without clutter |
| Safe areas | Respect device insets for the sticky header and bottom bar | Notched phones |
| Tables on small screens | Below 768 px a table becomes stacked cards, with the key fact first | Tables do not fit phones |

## 8. Cards and surfaces

Common anatomy: surface background, 1 px border, 14 px radius, 20 px padding (16 on mobile), 10 to 12 px gap, title first, supporting text, then actions. Informational cards are not clickable and have no hover state. Interactive cards have a hover tint, a visible focus ring, one main link, and nested controls that do not conflict.

| Card | Content order | Actions | Notes |
| --- | --- | --- | --- |
| Profile card | Avatar, name, role and location, verified skills, completeness | View, message | Never shows compensation or contact details |
| Member and community card | Avatar, name, reputation, expertise | Follow, mentor request |  |
| Post (question) card | Title, mode chip, author and time, replies and useful count, status | Open | Status chip carries text and glyph |
| Job card | Title, company, location and mode, experience, required and preferred skills, fee and experienced-only chips | Apply | Fee shown before the action |
| Candidate card or row | Name, role, experience, decision and stage chips, score, waiting time | Review, compare | Date of birth never shown to companies |
| Assessment and learning card | Title, level, state chip, progress, price chip | Start, continue, buy | Locked states say how to unlock |
| Verification and achievement badge | Label, glyph, skill; evidence detail on click | Open detail | Detail shows who decided, date, expiry |
| Notification item | Title, message, time, unread marker | Open record | No sensitive data in previews |
| Stats or metric card | Label, mono value, context or period | Drill in | Every number has a definition |
| Form section | Heading, why-we-ask text, fields, errors, save | Save, cancel | Sensitive fields explain visibility |
| Dialog | Title, short body, fields, actions | Confirm, cancel | Full page for long tasks; destructive dialogs name the effect |
| Empty and error panels | Reason, one next action, retry with filters kept | Retry, clear filter, create | Never a blank screen |

## 9. Icons, imagery and placeholders

- **Icons:** one outline style (Lucide-compatible), 24 px grid, 1.8 px stroke, round caps, drawn in the current text color; 20 px in navigation, 18 px in the header, 22 px in page tiles. Functional icons have an accessible name or visible text; decorative icons are hidden from assistive technology. Do not use an icon where a clear label would do.
- **Semantic glyphs:** check, exclamation, cross and info on chips and alerts.
- **Illustration:** the current network lines, nodes and routing paths remain useful brand motifs, but illustration is not limited to them. Explore character-led scenes, 3D or dimensional art, playful objects, editorial graphics, gradients, abstract geometry, motion-led metaphors and other distinctive styles when they improve comprehension or emotional quality. Keep dense text and controls unobstructed; provide accessible text equivalents when the image carries information.
- **Avatars:** initials on a soft module tint when there is no photo; 1:1 crop; the accessible name is the person's name.
- **Skeletons:** match the final layout; static under reduced motion; announced to assistive technology with a hidden label.
- **Empty-state graphics:** choose the visual scale that best serves the task. A small line illustration is a low-cost default, not a hard limit; richer scenes are allowed when they add clarity or warmth without delaying the next action or overwhelming the content.

## 10. Interaction patterns

| Component | Behavior |
| --- | --- |
| Buttons | Variants: primary, secondary, lime (dark surfaces), destructive. States: default, hover, focus, pressed, disabled, loading (label stays, repeat clicks blocked). Minimum height 40 px on desktop, 44 px on touch screens **\[REVIEW\]** |
| Forms | Label above the field, always visible; hint text; validate when the user leaves the field or submits; errors under the field, linked to it and announced; entered data is never cleared on error; long forms show an error summary at the top |
| Multi-step flows | Step indicator with step names; save and continue later; a Back button that keeps entries; the final step shows a review before submit |
| Menus, tabs, tooltips | Keyboard operable; tooltips never hold essential information |
| Dialogs | Labelled by their title; focus moves in and returns to the trigger; Escape and outside click close non-destructive dialogs; background scroll locked; one dialog open at a time |
| Toasts | About 2.6 seconds; never the only place for required information |
| Banners and inline alerts | For persistent states; errors use an alert role |
| Tables and lists | Sortable columns with the sort stated in text; filters shown as removable chips with a Clear all; pagination states the total count; the filter state is kept when returning from a detail page |
| Charts | Title, unit, a text summary, direct labels or a legend, and a data table alternative; never color alone; series colors come from module accents, not status colors |
| States | Loading skeleton, empty with one action, error with retry, success shown on the page for high-impact changes, disabled with a reason |
| Motion | 150 to 250 ms is the default for common UI transitions, not a ceiling. Motion may be more expressive when it improves feedback or storytelling; keep it purposeful, performant and non-blocking. Reduced motion removes non-essential movement without losing information |
| Keyboard | Command palette (Ctrl or Command K); roving focus in menus; skip link; focus moves to the page heading on route change |

## 11. UX writing and content rules

### 11.1 Voice and patterns

| Pattern | Rule | Example |
| --- | --- | --- |
| Buttons | Start with a verb; say the outcome | Submit application, Save changes, Start assessment |
| Errors | What happened, why, how to fix it; no blame | Code expired. Codes last 10 minutes. Request a new code. |
| Empty states | What this is, why it is empty, how to start | No applications yet. Apply to a job and its progress will appear here. |
| Confirmations | Name the action and the effect; buttons repeat the action | Withdraw this application? The recruiter will be told. Buttons: Withdraw application, Keep application |
| Loading | Say what is happening if it takes more than 2 seconds | Reading your resume... |
| Success | Short and calm; no exclamation marks except real milestones | Skill verified |
| Sensitive fields | Say why and who sees it | Current CTC. Only recruiters you are forwarded to can see this. |
| Tooltips | Short, never obvious |  |

Tone by context: success is warm but not loud; errors are kind and specific; warnings are clear and actionable; neutral text is informative and short. Never use urgency or scarcity tricks.

### 11.2 Product vocabulary (use these words everywhere)

| Use | Not |
| --- | --- |
| Member | User, candidate (candidate is used only in recruiter screens) |
| Jobs (member) and Positions (recruiter) | Openings, requisitions |
| Application | Submission (a lab submission is a Submission) |
| Forwarded | Sent, shared |
| Verified skill | Certified skill (certification is its own label) |
| Evidence | Proof, documents |
| Placement fee | Commission, charge |

### 11.3 Formats and limits **\[REVIEW\]**

| Item | Rule |
| --- | --- |
| Dates and times | 17 Oct 2026, 3:30 pm IST; the zone is always shown on interview times |
| Money | Rupee sign with Indian digit grouping, for example 12,50,000; annual pay also as lakhs per annum (12.5 LPA) |
| Numbers | Tabular figures; large counts shortened (1.2k) with the full value on hover or focus |
| Names and titles | Names up to 60 characters; question titles 8 to 120; position titles up to 80; skill chips up to 40 |
| Truncation | Card titles stop at 2 lines; long text ends with an ellipsis and a Show more control; truncated text is available in full to assistive technology |
| Sensitive data | Masked by default in lists (for example the last 4 digits of a phone number); shown in full only where DEC-015 allows |

## 12. Edge cases every screen handles

| Case | Behavior |
| --- | --- |
| Very long names, titles and skill lists | Wrap or truncate as above; never push layout sideways |
| Hindi and longer text | Allow about 30% more length; no fixed-width buttons; Devanagari line height 1.6 |
| Slow connection | Skeletons within 100 ms; a retry message after 10 seconds; uploads show progress and can be retried |
| Missing data | Show a dash with a reason where helpful (for example Not provided), never a fake zero |
| Zero results | Say what was searched and offer Clear filters |
| No permission | Explain in plain words and give a valid destination; never a blank screen |
| Offline or failed save | Keep entries on screen; say that it was not saved; retry button |
| Session ended | Return to the same page after sign-in; keep unsent form entries where possible |
| Large lists | Paginate or load more with a count; never load everything at once |
| Duplicate actions | Disable the button while working; a second click does nothing |

## 13. Accessibility standards

Target WCAG 2.2 AA in both themes (DEC-007, PRD-049).

| Area | Standard | Test |
| --- | --- | --- |
| Contrast | Text 4.5:1; large text and controls 3:1 | Computed per token pair; automated scans |
| Keyboard | Everything operable; logical order; visible focus | Keyboard-only journeys |
| Structure | Landmarks, one H1, no skipped levels | Automated scan and manual review |
| Names and forms | Every control named; errors announced and linked | Scan plus screen reader pass |
| Targets | At least 40 px for buttons and inputs; 24 px minimum anywhere | Visual review |
| Status | Text and glyph with every color | Review checklist |
| Zoom and reflow | Usable at 200% and 320 px wide with no sideways page scroll | Manual and automated |
| Motion | Respect reduced motion | Emulated setting test |
| Real assistive technology | A screen reader pass on onboarding, apply, assessment, verification and recruiter review each release | Manual, notes kept |

The prototype's automated scans found no violations, but they cannot measure contrast or layout, and no real screen reader testing has been done (RISK-10).

## 13.1 Creative exploration and design-system evolution

PacketPulse may use a different visual language where it creates a better experience. The current Signal Grove palette, module accents, illustration rules and component treatments are a starting point, not a fence. A page may use a new palette or a richer visual treatment; a feature may justify new semantic tokens, a new component variant or a revised motion pattern. The selected solution must still work in light and dark themes, meet WCAG 2.2 AA, preserve clear semantic status cues, respect reduced motion, remain responsive and perform well on real devices.

Working sequence: explore freely in concepts; compare alternatives against user outcomes; test accessibility and responsive behavior; select a direction; promote the selected values and patterns into shared tokens/components; update this guide and the relevant handoff/SOP; record the decision and rationale in the separate design exploration change log.

## 14. Governance and use by developers

- **One source of production values.** Production color, type, spacing, radius, elevation and motion values are centralized in the project token source after the repository audit. Components consume semantic token names rather than scattered one-off literals.
- **Explore beyond the current system.** Concept work may introduce new palettes, color combinations, gradients, illustration styles, textures, motion, layouts or component patterns. Do not reject a stronger UX because it does not fit an existing token. Compare options against task clarity, accessibility, trust, performance, responsiveness and theme behavior.
- **Promote the selected direction.** Before production, move winning values into the shared token source. Define light and dark behavior, semantic roles, contrast results, interaction states and fallbacks. A one-off value may be used in a prototype; it should not remain an undocumented production value.
- **New tokens and components.** A new token needs a reason, light and dark behavior (or a documented reason why a single value is appropriate), contrast and color-vision checks, and a change-log entry. A new component is proposed with its states, accessibility notes and visual examples; an existing component can change when its impact is recorded and tested.
- **Versioning and decisions.** Record meaningful design-system changes in the separate PacketPulse Design Exploration Change Log. Update the relevant project documents and record any lasting product decision in Document 1.
- **How to build from it.** Developers map the approved token system to the existing styling setup; exact files are found in the repository audit (Document 4). Design specifications describe what should exist; only items marked PV were built, and only in the prototype.

## 15. System recovery pages — network adventure visual system (SCR-043)

**Status:** implementation design direction; exact artwork and final palette remain open for owner selection. **Scope:** 403 Access restricted, 404 Page not found, 500 Server error, 503 Maintenance, and Offline / connection lost. The page recipes below are proposals to implement and validate, not proof that application behavior or external status integrations already exist.

### 15.1 Design intent

The recovery experience should feel like PacketPulse: a welcoming community built by and for people who work with networks. These screens are not generic browser errors. Each turns a real network or operations problem into a short, understandable story. The preferred visual direction is **Network Adventure**: a polished 2.5D / isometric world with topology paths, routers, switches, firewall boundaries, racks, fiber links and recognizable network engineers. Use humor gently; never make a real incident, member or engineer feel foolish.

**Experience principles**

- **Recognizable to practitioners, understandable to newcomers.** Use technically credible objects and scenarios, then explain the problem in plain language.
- **One small story, one clear next step.** The illustration sets the scene; the heading names the problem; the primary action gives the user a way forward.
- **Optimistic, not dismissive.** Make getting lost feel like an adventure, but do not trivialize outages, access controls or lost work.
- **Different states, different causes.** A missing route, a permission denial, an internal failure, planned maintenance and a lost client connection must not look or behave as the same error.
- **Creative surface, dependable system.** New colors and illustrations are welcome. Semantics, accessibility, truthful status and safe recovery behavior remain mandatory.

### 15.2 Shared page composition

Use the same structural grammar across all five states, with enough variation to make the situation memorable.

| Layer | Desktop treatment | Small-screen treatment | Rule |
| --- | --- | --- | --- |
| Brand header | PacketPulse mark and wordmark; minimal utility navigation; theme control only if the app shell already exposes it | Compact mark; hide non-essential navigation | Do not show links that are unusable in the current state or unavailable to the role |
| Status marker | Small code/state pill with a semantic glyph (for example, 404 / Route not found) | Same marker above the H1 | Status is never communicated by color alone |
| Message | H1, 1–2 sentence explanation, one primary action and optional secondary action | Message and actions first | One H1; one primary CTA; short, plain-language copy |
| Story scene | Large 2.5D scene beside or behind the message, typically 55–60% of the visual area | Scene below the message, cropped without losing the focal object | Never put essential copy over a busy illustration |
| Recovery detail | Optional real status link, reference ID, actual maintenance window or unsaved-state notice | Stacked below actions | Only show facts supplied by a reliable runtime source |
| Footer | Small links to Home, Community, Help and Status where those destinations exist | Compact link row | No invented destinations; do not add a second primary CTA |

**Suggested layout:** content max-width 1,200 px; desktop split approximately 42% message / 58% scene; tablet 45% / 55%; below 768 px stack message first and illustration second. Keep the existing 4 px spacing rhythm and breakpoints (640, 768, 1024, 1280, 1536 px) unless testing demonstrates a better fit. The page should remain composed at 320 px width and 200% zoom.

### 15.3 Recovery palette and semantic tokens

This is a **candidate page-family palette**, not a replacement for the global Signal Grove palette. It adds a brighter, more expressive visual language for recovery pages while retaining the existing PacketPulse mark and typography. The exact palette can be tuned after comparing the concepts in both themes.

#### Shared recovery tokens

| Token | Light | Dark | Purpose |
| --- | --- | --- | --- |
| `recovery.canvas` | `#F7F6F2` | `#0C1425` | Main page background |
| `recovery.surface` | `#FFFFFF` | `#151F35` | Content panel and cards |
| `recovery.surface.raised` | `#FAFBFF` | `#1D2A46` | Raised notice or inset panel |
| `recovery.text.primary` | `#16223B` | `#F5F7FF` | H1, body and key labels |
| `recovery.text.secondary` | `#4B5870` | `#C2CCE0` | Supporting copy |
| `recovery.border` | `#D9DFE9` | `#35435F` | Card and control boundaries |
| `recovery.action.primary` | `#2453D4` | `#375DD9` | Primary action background |
| `recovery.action.on-primary` | `#FFFFFF` | `#FFFFFF` | Primary action text |
| `recovery.focus` | `#2453D4` | `#9CB5FF` | 3 px focus ring with 2 px offset |

#### State accent tokens

| State | Strong accent — light | Soft surface — light | Strong accent — dark | Soft surface — dark | Visual cue |
| --- | --- | --- | --- | --- | --- |
| 404 — Route not found | `#2453D4` | `#EAF1FF` | `#9CB5FF` | `#1E2E55` | Route trail / missing node |
| 403 — Access restricted | `#7553D8` | `#F1ECFF` | `#B6A0FF` | `#30265B` | Firewall gate / shield |
| 500 — Server error | `#B63B31` | `#FEEBE8` | `#FF9C90` | `#51242A` | Interrupted core / alert waveform |
| 503 — Maintenance | `#9C6400` | `#FFF4D6` | `#FFD36A` | `#473814` | Maintenance marker / tool |
| Offline — Connection lost | `#006B76` | `#E4F8FA` | `#6DDDE5` | `#143B47` | Broken wireless bridge / signal |

Use state accents for small status markers, illustration highlights, route lines and supporting chips. Keep the primary CTA consistent across the family unless a usability test shows that a state-specific action color is clearer. Do not use the entire page as a single state color. Decorative illustration colors may be richer than these semantic accents, but text and controls must use tested foreground/background pairs.

**Contrast reference for proposed text pairs:** the candidate light pairs measure 5.68:1 (404), 4.56:1 (403), 4.99:1 (500), 4.52:1 (503), and 5.68:1 (Offline). White text on the light and dark primary-action backgrounds measures 6.44:1 and 5.63:1 respectively. The proposed dark accent text pairs on `#0C1425` measure at least 8.28:1. These are calculations for the listed color pairs only; verify the rendered implementation, hover/pressed states, overlays, borders and any gradient combinations before release. Do not place text directly on illustration art or gradients without a separate contrast check.

### 15.4 Illustration language — Network Adventure

**Primary art direction:** cohesive 2.5D / isometric scenes with editorial clarity. Combine small human characters, recognizable network equipment and simplified topology elements. Keep the visual quality polished and warm rather than childish. Character-led illustrations may be 3D-rendered, dimensional vector, or a hybrid, provided the family has a consistent perspective, lighting, material language and scale.

**Visual ingredients**

- Network topology: connected nodes, route lines, hop markers, missing links, segmented zones and signal paths.
- Network hardware: routers, switches, firewalls, server racks, patch panels, fiber connectors, antennas and monitoring displays.
- Engineer life: laptop or field tablet, console, patch lead, cable tester, tool pouch, headset, access badge, maintenance vest and NOC screens.
- Human context: field engineer tracing a route, NOC engineer investigating an alert, engineer facing a protected segment, maintenance crew working on a rack or bridge.
- PacketPulse signature: a subtle pulse waveform or ring motif integrated into a device, map marker, link or scene—not pasted onto every object.

**Composition guardrails**

- Use one main character or focal object, one clear network problem, and two to four supporting technical cues.
- Make the failure legible at thumbnail size: missing node, locked boundary, interrupted rack waveform, maintenance tools, or broken wireless bridge.
- Let the story reward a closer look, but do not require users to inspect the illustration to understand the error.
- Keep faces, hardware and signal paths clear; avoid visual clutter, excessive floating UI panels and meaningless binary/code decoration.
- Technical details should feel credible. Do not expose real IP addresses, hostnames, credentials, logs, private topology or other user data in artwork.
- Characters should feel inclusive and capable. Avoid jokes that blame an engineer or imply incompetence.
- Provide a static optimized fallback for every animated scene. Meaningful artwork receives a concise text alternative; decorative artwork is hidden from assistive technology.

### 15.5 Page recipes

#### 404 — Page not found: “The wrong route adventure”

| Element | Specification |
| --- | --- |
| Core message | The requested page or route cannot be found. |
| Suggested H1 | **Looks like this packet took a wrong route.** |
| Supporting copy | “We couldn't find the page you were looking for. It may have moved, or the link may be out of date.” |
| Primary action | **Explore PacketPulse** for an unknown entry point, or **Back to community** when the referring context is the community. The destination must be a real route. |
| Secondary action | Search PacketPulse only if global search is available; otherwise use a valid previous-page or Home link. |
| Illustration | A network engineer with a field tablet following a topology map. A dotted packet route crosses several nodes, then ends at a missing node or a clearly disconnected link. A small “route not found” marker acts as the discovery clue. The mood is curious and adventurous, not alarming. |
| Microinteraction | The route line draws toward the missing node, pauses, then gently reveals the gap. No frantic spinning or repeated error flashes. |
| Logic | Preserve the original URL for support/debugging where appropriate, but do not expose private query values. Do not automatically redirect to an unrelated page. |

#### 403 — Access restricted: “The protected network segment”

| Element | Specification |
| --- | --- |
| Core message | The current identity does not have permission to view the requested page or action. |
| Suggested H1 | **This network segment is restricted.** |
| Supporting copy | “Your current access level can't open this page. Head back to a section you can access.” |
| Primary action | **Go to dashboard** or another destination known to be available to the current role. |
| Secondary action | **Go back**. Show **Request access** only if a real permission-request workflow exists. |
| Illustration | A network engineer at a segmented firewall gate. A shield or lock is the central symbol; a small ACL/role panel may show abstract allow/deny states, never the actual user's private permissions or internal policy configuration. |
| Microinteraction | A single soft shield highlight or gate-settle motion on entry; no repeated lock shaking. |
| Logic | The server remains the authority for every route, field and action (DEC-010). The page must not reveal whether a hidden private resource exists when the security policy intentionally conceals it. Never use the illustration or hidden navigation as an access-control mechanism. |

#### 500 — Server error: “Something is wrong in the core”

| Element | Specification |
| --- | --- |
| Core message | An unexpected server-side failure interrupted the request. |
| Suggested H1 | **Something's not right in the core.** |
| Supporting copy | “An unexpected issue interrupted this page. Try again. If it keeps happening, check service status.” |
| Primary action | **Try again** for a safe page-load retry. |
| Secondary action | **Check service status** only when a real status destination is integrated; otherwise omit it. A support reference may be shown when generated by the server. |
| Illustration | A NOC engineer inspecting a server rack or core switch. A monitoring waveform has a single interruption; a friendly diagnostic robot may be a small supporting character, not the only story. |
| Microinteraction | A short waveform interruption or one-time diagnostic scan, then a calm resting state. Do not simulate a repair or imply the incident is resolved. |
| Logic | Show a generic explanation and a safe correlation/reference ID if available. Never render stack traces, secrets, internal paths or raw error objects. Retry only the safe read/page request; do not replay a non-idempotent form submission. |

#### 503 — Maintenance / temporarily unavailable: “The network tuning crew”

| Element | Specification |
| --- | --- |
| Core message | The service is intentionally or temporarily unavailable. Planned maintenance must be distinguishable from an unplanned overload or capacity event. |
| Suggested H1 | **We're tuning the network.** |
| Supporting copy | “PacketPulse is temporarily unavailable while maintenance is underway. Please check back soon.” Use the exact reason supplied by the operations source when available. |
| Primary action | **View maintenance status** when an authoritative status page exists; otherwise **Back to Home**. |
| Secondary action | A real maintenance window with date, time and timezone, only when confirmed by operations. |
| Illustration | Network engineers in safety vests working on a server rack, patch panel or fiber bridge. Show a tool, cable and a clear work-in-progress cue. The scene should feel deliberate and reassuring, not like a crash. |
| Microinteraction | A gentle tool movement or signal pulse. A progress indicator is allowed only when backed by real progress data; never invent a percentage or countdown. |
| Logic | Distinguish planned maintenance from generic 503. Display a retry hint or `Retry-After` only when supplied by the server/operations source. Do not promise “back soon” unless the expected return time is confirmed. |

#### Offline — Connection lost: “The disconnected network islands”

| Element | Specification |
| --- | --- |
| Core message | The client cannot currently reach PacketPulse due to a network/connectivity problem. |
| Suggested H1 | **Your connection took a detour.** |
| Supporting copy | “We lost the link to PacketPulse. Check your network connection, then try again.” |
| Primary action | **Try reconnecting**. The action performs a real connectivity/health check and communicates the result. |
| Secondary action | **Keep this page open** as a low-risk instruction. Do not offer **Continue offline** unless the product has a tested offline mode. |
| Illustration | Floating islands represent network segments or sites. A dashed wireless/fiber bridge between them has a visible gap; a network engineer on one island checks a field tablet while the PacketPulse destination is visible across the gap. This preserves the liked floating-islands concept but makes the network topology explicit. |
| Microinteraction | A signal travels along the bridge and stops at the gap. On a user-triggered retry, the signal may travel again; show connection restored only after a successful real check. |
| Logic | `navigator.onLine` alone is not proof that PacketPulse is reachable. Combine browser connectivity events with an application health/request result. If work was not saved, say **“This hasn't been saved yet.”** Keep entered content visible where possible and offer a safe retry. Never claim that work is saved or persisted unless confirmed. |

### 15.6 Motion and microinteraction system

Motion should make the network story understandable, not turn an error page into a loading distraction.

| Motion token / pattern | Candidate value | Use |
| --- | --- | --- |
| `recovery.motion.ui` | 150–250 ms | Hover, focus, button press, chip and panel transitions (aligns with DES interaction guidance) |
| `recovery.motion.reveal` | 250–400 ms | One-time illustration or status-panel entrance |
| `recovery.motion.story` | 4–8 s loop, when needed | Slow route pulse, gentle floating or subtle hardware activity; never required to understand the page |
| `recovery.motion.easing` | `cubic-bezier(0.2, 0.7, 0.2, 1)` | Calm deceleration for UI and scene transitions |
| `recovery.motion.reduced` | No non-essential movement | Static art and instant state changes under `prefers-reduced-motion: reduce` |

**Rules:** no flashing, strobing, aggressive shaking, rapid particle effects or continuous parallax that competes with text. Do not animate the H1 or primary button in a way that delays interaction. The static page must communicate the full meaning. Announce dynamic retry/connectivity outcomes through a concise status region; do not announce decorative motion. Stop or freeze non-essential loops when the page is hidden or the user requests reduced motion. Do not simulate server repair, packet delivery, saved work, progress or recovery unless the application has confirmed that state.

### 15.7 Shared component family

The design should be implemented as a reusable page family rather than five unrelated one-off pages.

| Component | Responsibility | Required states / options |
| --- | --- | --- |
| `RecoveryPage` | Shared page shell and responsive split layout | `state`, `theme`, `title`, `description`, optional `statusDetail` |
| `RecoveryHeader` | Brand identity and safe navigation | Full / compact; authenticated / public navigation |
| `RecoveryStatusMarker` | Status code or connection label with glyph | 403, 404, 500, 503, Offline; text always present |
| `RecoveryStoryScene` | State-specific illustration container | Static, animated, reduced-motion fallback; decorative or meaningful alt text |
| `RecoveryActions` | One primary CTA and optional secondary link | Default, loading, disabled, success/failure feedback |
| `RecoveryStatusDetail` | Maintenance window, support reference or unsaved-state note | Hidden unless real data exists |
| `ReconnectControl` | Performs real connectivity check | Idle, checking, connected, still-offline, request-failed |

The repository audit determines the actual component folder, routing approach, styling library and animation tooling. The names above are conceptual component responsibilities, not a mandate to add a new framework or dependency.

### 15.8 Responsive behavior

- **1536 px and above:** use the page container from DES layout rules; give the illustration room to tell the story without pushing the heading below the fold.
- **1024–1535 px:** retain a two-column split where it fits; reduce decorative layers before shrinking the copy or controls.
- **768–1023 px:** use a compact two-column layout or stack if the illustration would force the text below the fold.
- **Below 768 px:** message and actions first; illustration second; reduce scene detail and crop to the main focal cue.
- **320–639 px:** stack all actions or make the primary action full width; preserve at least 24 px target spacing; no horizontal scroll.
- **All widths:** no fixed-height panel that clips Hindi or longer translated copy; test 200% zoom, 320 px reflow and text expansion of approximately 30%.

### 15.9 Accessibility and UX writing

- Meet WCAG 2.2 AA in both themes. Use text plus a glyph for every functional status; state accent colors are not the sole cue.
- Keep one H1, correct landmarks, visible focus, keyboard access and a logical reading order. Move focus to the H1 on full route navigation; keep focus stable after an inline retry.
- Maintain readable text contrast and 3:1 non-text contrast for controls, focus indicators and meaningful boundaries. Decorative art must not be mistaken for an interactive control.
- Use a text equivalent for informative illustrations. Hide purely decorative SVG/canvas art from assistive technology.
- Respect reduced motion. Do not announce each animation frame to screen readers.
- Errors must state what happened, what the user can do, and what will happen to their work. Avoid blame and unexplained network jargon.
- When a save fails, say **“This hasn't been saved yet.”** Keep the entered values visible where possible. Do not claim that the page is safe to close or that data is stored locally unless the application confirms that behavior.

### 15.10 Runtime and security contracts

| State | Source of truth | Required behavior |
| --- | --- | --- |
| 404 | Server/router response | Render only for a genuinely missing route/resource or where the security policy deliberately masks existence; offer a valid destination |
| 403 | Server-side authorization result | Respect server authorization; show a safe destination; do not reveal restricted resource details |
| 500 | Unexpected server failure | Generic message; no stack trace; safe request correlation ID if available; avoid unsafe replay |
| 503 | Maintenance/availability source | Distinguish planned maintenance from temporary unavailability; show only authoritative timing/progress |
| Offline | Client connectivity plus a real application reachability check | Keep UI responsive; distinguish local network loss from server 5xx; show unsaved-state truthfully |

**Implementation notes:**

- A page-level offline experience can be shown after the application shell has loaded. A direct navigation while fully offline requires an already available fallback asset/shell, such as a deliberate caching strategy; do not assume that a server-rendered route can load without connectivity.
- Do not infer that a request is safe to repeat. Retry a GET or an explicitly idempotent operation; protect submissions and payments from duplicate execution.
- `navigator.onLine` can be a useful signal but is not a service-health guarantee. Verify reachability using a same-origin lightweight endpoint or a real request outcome.
- The maintenance/status URL, incident reference, maintenance window and support reference are integration-dependent. Omit the UI element until the source exists.
- Respect the existing permission model (DEC-010) and security rule against exposing stack traces or internal details (TEST-011).

### 15.11 CSS token reference (candidate values)

The following snippet is a starting mapping for implementation. The developer should merge it into the existing token source after the repository audit; do not scatter raw values across components.

```css
:root,
[data-theme="light"] {
  --recovery-canvas: #F7F6F2;
  --recovery-surface: #FFFFFF;
  --recovery-surface-raised: #FAFBFF;
  --recovery-text-primary: #16223B;
  --recovery-text-secondary: #4B5870;
  --recovery-border: #D9DFE9;
  --recovery-action-primary: #2453D4;
  --recovery-action-on-primary: #FFFFFF;
  --recovery-focus: #2453D4;
  --recovery-404: #2453D4;
  --recovery-404-soft: #EAF1FF;
  --recovery-403: #7553D8;
  --recovery-403-soft: #F1ECFF;
  --recovery-500: #B63B31;
  --recovery-500-soft: #FEEBE8;
  --recovery-503: #9C6400;
  --recovery-503-soft: #FFF4D6;
  --recovery-offline: #006B76;
  --recovery-offline-soft: #E4F8FA;
}

[data-theme="dark"] {
  --recovery-canvas: #0C1425;
  --recovery-surface: #151F35;
  --recovery-surface-raised: #1D2A46;
  --recovery-text-primary: #F5F7FF;
  --recovery-text-secondary: #C2CCE0;
  --recovery-border: #35435F;
  --recovery-action-primary: #375DD9;
  --recovery-action-on-primary: #FFFFFF;
  --recovery-focus: #9CB5FF;
  --recovery-404: #9CB5FF;
  --recovery-404-soft: #1E2E55;
  --recovery-403: #B6A0FF;
  --recovery-403-soft: #30265B;
  --recovery-500: #FF9C90;
  --recovery-500-soft: #51242A;
  --recovery-503: #FFD36A;
  --recovery-503-soft: #473814;
  --recovery-offline: #6DDDE5;
  --recovery-offline-soft: #143B47;
}

.recovery-page {
  color: var(--recovery-text-primary);
  background: var(--recovery-canvas);
}

.recovery-page :focus-visible {
  outline: 3px solid var(--recovery-focus);
  outline-offset: 2px;
}

@media (prefers-reduced-motion: reduce) {
  .recovery-page *,
  .recovery-page *::before,
  .recovery-page *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

### 15.12 Acceptance and QA checklist

A recovery page is not complete until its cause, copy, destination and runtime behavior are verified—not merely its artwork.

| Check | Acceptance requirement |
| --- | --- |
| State mapping | 403, 404, 500, 503 and Offline can be triggered independently and are not confused with one another |
| Navigation | Every CTA resolves to a real destination; role-specific destinations respect server permissions |
| Retry safety | Retry does not duplicate form submissions, payments or other non-idempotent actions |
| Save honesty | Failed saves are labelled as not saved; entered content is retained where possible; no unsupported promise of local persistence |
| Maintenance truth | Time, progress, status and `Retry-After` appear only when provided by an authoritative source |
| Security | No stack traces, secrets, private paths, internal hostnames or restricted content |
| Theme | All five pages work in light and dark; contrast is tested in real rendered states |
| Responsive | 320 px, 640 px, 768 px, 1024 px and desktop; no clipped text or horizontal page scroll |
| Accessibility | Keyboard only, visible focus, screen reader, text alternatives and WCAG 2.2 AA contrast/non-text checks |
| Motion | Reduced-motion mode is static but complete; no flashes or distracting perpetual motion |
| Localization | English and Hindi copy fits; buttons do not clip; allow approximately 30% text expansion |
| Performance | Optimized responsive illustration assets; static fallback; no unnecessary new runtime dependency without repository review |
| Observability | A support/reference ID is shown only when generated; diagnostic events avoid personal data and secrets |

**Approval gate:** this design-system layer is ready for design and engineering review. The final palette, exact illustrations, CTA destinations, status integration and offline-persistence behavior still require validation and owner approval before production release.

