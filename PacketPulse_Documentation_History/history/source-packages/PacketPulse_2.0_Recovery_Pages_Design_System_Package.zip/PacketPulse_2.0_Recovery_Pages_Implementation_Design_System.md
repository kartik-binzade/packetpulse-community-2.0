# PacketPulse 2.0 — Recovery Pages Implementation Design System

**Reference:** Document 2, version 3.2, section 15 · **Screen:** SCR-043 · **Direction:** Network Adventure  
**Status:** Working design direction; final visual selection and production implementation await owner go-ahead.

## Purpose

Build a coherent five-state recovery experience for 403, 404, 500, 503 and Offline. The pages should feel grounded in the life of network engineers while remaining understandable to every PacketPulse member. The preferred visual language is a polished 2.5D/isometric network world: topology paths, missing links, firewall gates, NOC monitoring, server racks, fiber and maintenance crews.

## Shared visual system

- Use an editorial layout: brand header, status marker, one H1, short explanation, one primary action, optional secondary action and a story illustration.
- Desktop split: approximately 42% message / 58% illustration; below 768 px stack message first and art second.
- Keep the app's Inter / Noto Sans Devanagari UI typography and JetBrains Mono for short technical labels or reference IDs.
- Use the candidate light/dark recovery tokens in `PacketPulse_Recovery_Pages_Tokens.css`. Integrate them into the central token source after repository audit.
- State accents: 404 blue, 403 violet, 500 coral, 503 amber, Offline teal. The state label and glyph must remain explicit; never communicate state by color alone.
- Primary actions use the shared recovery action token by default. Keep secondary actions visually quiet.

## Page recipes

| State | H1 | Primary action | Illustration cue |
| --- | --- | --- | --- |
| 404 | Looks like this packet took a wrong route. | Explore PacketPulse / Back to community | Engineer tracing a topology map; dashed packet path ends at a missing node |
| 403 | This network segment is restricted. | Go to dashboard (or valid role-specific destination) | Engineer facing a firewall gate with shield/lock and abstract ACL cues |
| 500 | Something's not right in the core. | Try again (safe request only) | NOC engineer investigating a core rack with one interrupted waveform |
| 503 | We're tuning the network. | View maintenance status / Back to Home | Engineers repairing a rack, patch panel or fiber bridge; no fake progress |
| Offline | Your connection took a detour. | Try reconnecting | Floating network islands joined by a broken wireless/fiber bridge; engineer checking a field tablet |

## Required runtime contracts

- **404:** genuinely missing route/resource; no unrelated auto-redirect.
- **403:** server-side permission decision; never reveal restricted resource details.
- **500:** generic error; no stack trace, secrets or internal paths; retry only safe operations.
- **503:** distinguish planned maintenance from temporary unavailability; display time/progress only from an authoritative source.
- **Offline:** use browser connectivity plus an actual same-origin reachability result; `navigator.onLine` alone is insufficient. A fully offline direct navigation needs a deliberately cached fallback shell.
- If saving fails, display **“This hasn't been saved yet.”** Keep entries visible where possible. Never claim work is saved or locally persisted without confirmation.
- Do not show **Request access**, **Continue offline**, **Check service status** or a maintenance ETA unless the corresponding workflow/integration exists.

## Motion and accessibility

- UI transitions: 150–250 ms; one-time scene reveal: 250–400 ms; optional quiet story loop: 4–8 seconds.
- Reduced motion: static scene, no non-essential loops, full information retained.
- No flashing, shaking, rapid particles or movement that delays the CTA.
- WCAG 2.2 AA, text + glyph status, visible 3 px focus ring, keyboard operation, accessible alt treatment, 320 px reflow and 200% zoom.
- Test English and Hindi; allow approximately 30% text expansion.

## Acceptance checks

1. Correct HTTP/client state mapping for all five pages.
2. Valid CTA destinations for each role and authentication context.
3. Safe retry semantics; no duplicate writes, applications or payments.
4. Honest save state and preservation of entered content where possible.
5. No stack traces, private topology, hostnames, secrets or raw error payloads.
6. Both themes, responsive breakpoints, keyboard, screen reader and reduced-motion passes.
7. Status links, maintenance windows and support IDs are displayed only when real data is available.

See Document 2 section 15 for full tokens, illustration composition, copy alternatives, responsive rules, component family and QA matrix.
